import numpy as np
from sklearn.base import TransformerMixin
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
from sklearn.metrics import log_loss
from sklearn.metrics import accuracy_score, classification_report
from sklearn.metrics import precision_score
import random
import pandas as pd
from sklearn.model_selection import cross_validate
from neural_net import *



class CustomScaler(TransformerMixin):
    def __init__(self, continuous_idx, dummies_idx):
        self.continuous_idx = continuous_idx
        self.dummies_idx = dummies_idx
        self.scaler = StandardScaler()

    def fit(self, X, y=None):
        self.scaler.fit(X[:, self.continuous_idx])
        return self

    def transform(self, X, y=None, copy=None):
        X_head = self.scaler.transform(X[:, self.continuous_idx])
        return np.concatenate((X_head, X[:, self.dummies_idx]), axis=1)


### Objective Fucntions


def scores_for_table(model_instance, X_train_validate, y_train_validate, cv = 5):
    X_train_validate = X_train_validate.astype('float64', copy=False)
    y_train_validate = y_train_validate.astype('float64', copy=False)
    scoring = ['accuracy', 'precision', 'recall', 'f1_macro']
    scores = cross_validate(model_instance, X_train_validate, y_train_validate, scoring=scoring, cv=cv)
    scores_ = cross_validate(model_instance, X_train_validate, y_train_validate, scoring=ROI, cv=cv)
    #print(scores_)

    list_of_scores_tab = []
    sorted(scores.keys())
    list_of_scores_tab.append(scores['test_accuracy'].mean())
    list_of_scores_tab.append(scores['test_precision'].mean())
    list_of_scores_tab.append(scores['test_recall'].mean())
    list_of_scores_tab.append(scores['test_f1_macro'].mean())

    test_size = len(X_train_validate) / cv
    list_of_scores_tab.append(np.divide(scores_['test_score'], test_size).mean())
    #list_of_scores_tab.append(scores_['test_score'].mean())

    return list_of_scores_tab


def logLossFitness(y_test, y_pred):
    score = log_loss( y_test, y_pred)
    return score

def accFitness(y_test, y_pred):
    score = accuracy_score( y_test, y_pred)
    return score

def profitFitness(y_test, y_pred):
    cm = confusion_matrix(y_test, y_pred)
    tn, fp, fn, tp = cm.ravel()
    score = (tn * 0 + fp * (-3) + fn * 0 + tp * 8)#/len(y_test)
    #score = cm[0][0] * 0 + cm[1][1] * 8 + cm[1][0] * (-8) + cm[0][1] * (-14)
    return score

def precisionScore(y_test, y_pred):
    score=precision_score(y_test, y_pred)
    return score


def report_scores(y_test, y_pred, model_name):
    print(model_name)
    print(classification_report(y_test, y_pred))
    cm = confusion_matrix(y_test, y_pred)  # printing the confusion matrix
    print(cm)
    tn, fp, fn, tp = cm.ravel()
    sen = tp / (tp + fn)
    acc = (tp + tn) / (tp + fn + tn + fp)
    print('True positive  = ', tp)
    print('False positive = ', fp)
    print('False negative = ', fn)
    print('True negative  = ', tn)
    print('Sensitivity  = ', sen)
    print('Accuracy  = ', acc)
    print('>>>   The investment return when this model is applied is:  €{:0,.2f}'.format(
        tn * 0 + fp * (-3) + fn * 0 + tp * 8))

        #cm[0][0] * 0 + cm[1][1] * 8 + cm[1][0] * (0) + cm[0][1] * (-11)).replace('€-', '-€'))

def ROI(estimator, x, y):

    yPred = estimator.predict(x)
    cm = confusion_matrix(y, yPred)
    tn, fp, fn, tp = cm.ravel()
    ROI = (tn * 0 + fp * (-3) + fn * 0 + tp * 8)#/len(y)
    return ROI

def do_validation(model_instance, X_train_validate, y_train_validate, cv = 5):
    from sklearn.model_selection import cross_validate
    X_train_validate = X_train_validate.astype('float64', copy=False)
    y_train_validate = y_train_validate.astype('float64', copy=False)
    scoring = ['accuracy', 'precision_macro', 'recall_macro', 'f1_macro', 'roc_auc']
    scores = cross_validate(model_instance, X_train_validate, y_train_validate, scoring=scoring, cv=cv,n_jobs=-1)
    scores_ = cross_validate(model_instance, X_train_validate, y_train_validate, scoring=make_scorer(profit_share), cv=cv, n_jobs=-1)


    list_of_scores = []
    sorted(scores.keys())
    list_of_scores.append(scores['test_accuracy'].mean())
    list_of_scores.append(scores['test_precision_macro'].mean())
    list_of_scores.append(scores['test_recall_macro'].mean())
    list_of_scores.append(scores['test_f1_macro'].mean())
    list_of_scores.append(scores['test_roc_auc'].mean())

    # test_size = len(X_train_validate) / cv
    list_of_scores.append(scores_['test_score'].mean())

    print(list_of_scores)
    return list_of_scores

def do_validation2(model_instance, X_train, y_train, cv = 2):
    from sklearn.model_selection import cross_validate
    #scoring = ['profit']
    # scores = cross_validate(model_instance, X_train, y_train, scoring=scoring, cv=cv,n_jobs=-1)
    scores_ = cross_validate(model_instance, X_train, y_train, scoring=ROI, cv=cv, n_jobs=-1)


    list_of_scores = []
    # sorted(scores.keys())
    # list_of_scores.append(scores['test_accuracy'].mean())
    # list_of_scores.append(scores['test_precision_macro'].mean())
    # list_of_scores.append(scores['test_recall_macro'].mean())
    # list_of_scores.append(scores['test_f1_weighted'].mean())
    # list_of_scores.append(scores['test_roc_auc'].mean())
    list_of_scores.append(scores_['test_score'].mean()*cv)

def create_list_of_list_of_scores():
    pass

def table_comparrison(list_of_list_of_scores, list_of_models):
    models_initial = pd.DataFrame({
        'Model': list_of_models,
        'Accuracy': [LR_accuracy, dtree_accuracy, SVM_accuracy, LDA_accuracy, QDA_accuracy, forest_accuracy,
                     KNN_accuracy,
                     bayes_accuracy],
        'Precision': [LR_precision, dtree_precision, SVM_precision, LDA_precision, QDA_precision, forest_precision,
                      KNN_precision, bayes_precision],
        'Recall': [LR_recall, dtree_recall, SVM_recall, LDA_recall, QDA_recall, forest_recall, KNN_recall,
                   bayes_recall],
        'F1_score': [LR_f1, dtree_f1, SVM_f1, LDA_f1, QDA_f1, forest_f1, KNN_f1, bayes_f1],
        'AUC_ROC': [LR_roc, dtree_roc, SVM_roc, LDA_roc, QDA_roc, forest_roc, KNN_roc, bayes_roc],
    }, columns=['Model', 'Fitting time', 'Scoring time', 'Accuracy', 'Precision', 'Recall', 'F1_score', 'AUC_ROC'])

    models_initial.sort_values(by='Accuracy', ascending=False)

pddf = pd.DataFrame

def do_feature_engineering(fe):
    fe.response_rate()
    fe.total_responses()
    fe.ever_accepted()
    fe.has_child()
    fe.count_children()
    fe.avg_no_web_per_month()
    fe.web_conversion()
    fe.avg_no_store_per_month()
    fe.avg_no_cat_per_month()
    fe.avg_pur_per_month()
    # fe.percen_catalogue() # no
    # fe.percen_deals() # no
    # fe.percen_store() # no
    # fe.percen_web() # no
    # fe.percen_fish() # no
    # fe.percen_fruit() # no
    # fe.percen_gold() # no
    # fe.percen_meat() # no
    # fe.percen_sweet() # no
    # fe.percen_wine() # no
    # fe.income_num_pur() # no
    # fe.spent_income() # no
    # fe.spent_vs_gold() #no

    # PCA is good # no surprise
    fe.pca_80(['NumDealsPurchases', 'NumStorePurchases', 'NumCatalogPurchases', 'NumWebVisitsMonth', 'NumWebPurchases',
               'Year_Birth', 'Income', 'Recency', 'MntWines', 'MntFruits', 'MntMeatProducts', 'MntFishProducts',
               'MntSweetProducts', 'MntGoldProds', 'Dt_Customer'], .8)

    # Clustering on cat data is ambigious
    fe.cluster_cat(['AcceptedCmp3', 'AcceptedCmp4', 'AcceptedCmp5', 'AcceptedCmp1', 'AcceptedCmp2', 'Complain', 'PhD', 'Basic', 'Fam_kids', 'Alone_kids'])

    # LDA even better than pca eventhough not checked for assumptions :D, bot togehter even better
    fe.lda_80(['NumDealsPurchases', 'NumStorePurchases', 'NumCatalogPurchases', 'NumWebVisitsMonth', 'NumWebPurchases',
               'Year_Birth', 'Income', 'Recency', 'MntWines', 'MntFruits', 'MntMeatProducts', 'MntFishProducts',
               'MntSweetProducts', 'MntGoldProds', 'Dt_Customer'], .8)


    pass

def do_scaling(X_train, X_test):
    from sklearn.preprocessing import StandardScaler

    X_train = X_train.values
    X_test = X_test.values


    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # to df
    X_train = pd.DataFrame(data=X_train)
    X_test = pd.DataFrame(data=X_test)
    return X_train, X_test

def do_scaling_numpy(X_train, X_test):
    from sklearn.preprocessing import StandardScaler

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # to df
    X_train = pd.DataFrame(data=X_train)
    X_test = pd.DataFrame(data=X_test)
    return X_train, X_test


from sklearn.metrics import make_scorer

def roi_gridcv(y_test, y_pred):
    cm = confusion_matrix(y_test, y_pred)
    tn, fp, fn, tp = cm.ravel()
    roi = (tn * 0 + fp * (-3) + fn * 0 + tp * 8)/len(y_test)
    # print(roi)
    return roi

def profit_share(y_test, y_pred):
    cm = confusion_matrix(y_test, y_pred)
    tn, fp, fn, tp = cm.ravel()
    profit_s = (tn * 0 + fp * (-3) + fn * 0 + tp * 8)/((y_test == 1).sum()*8)
    # print(profit_s)
    return profit_s

def ROI_(estimator, x, y):

    yPred = estimator.predict(x)
    print(type(y), type(yPred))
    yPred=yPred.reshape((y.shape[0]))
    y = pd.Series(y).tolist()
    yPred = pd.Series(yPred).tolist()
    print(y)
    cm = confusion_matrix(y, yPred)
    print(cm)
    tn, fp, fn, tp = cm.ravel()
    ROI_ = (tn * 0 + fp * (-3) + fn * 0 + tp * 8)/len(y)
    return ROI_


def tab_plot(table_compare, table_compare_after):
    import matplotlib.pyplot as plt
    import matplotlib.pyplot as plt
    i=0
    fig = plt.figure(figsize=(15, 5))
    for metric in table_compare[['ROI_pc', 'f1_macro']]:
        table_compare['diff'] = table_compare_after[metric] - table_compare[metric]
        i += 1
        plt.subplot(120+i)
        idx=list(table_compare.index)
        height_0=table_compare[metric]
        height_1=table_compare['diff']
        plt.bar(idx, height_0, 0.55, color='#C90035')
        plt.bar(idx, height_1, 0.55, bottom=height_0, color='#FF5728')
        plt.title('Before and after %s' % metric, fontsize=20, fontweight='bold', color='grey')
        plt.xticks(fontsize=13, rotation=70)

    plt.show()
    plt.tight_layout()

from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
score_f1 = make_scorer(f1_score,  greater_is_better=True)


def winsorize(X_train):
    pass
