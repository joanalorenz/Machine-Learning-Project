
import sys
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from data_loader import Dataset
from data_preprocessing import Processor
from feature_engineering import FeatureEngineer
from sklearn.ensemble import AdaBoostClassifier
from single_model import *
from utils import *
from model import *
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
import xgboost
from xgboost import XGBClassifier
from sklearn_tunning import grid_tuner

from CIFO_COPYPASTED import RandomSearch, HillClimbing
from model import grid_search_MLP, assess_generalization_auprc
from CIFO_MODIFIED import *
from tunning.parameter_tuning import tuning_forest_params
from neural_net import *
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from feature_selection import *
from ensemble_modeling import *
from MLens import *

from sklearn import metrics
from sklearn.naive_bayes import BernoulliNB
from sklearn.preprocessing import MinMaxScaler
SEED = 3

def main():
    #+++++++++++++++++ 1) load and prepare the data
    file_path = r"../ml_project1_data.xlsx"
    ds = Dataset(file_path)

    #+++++++++++++++++ 2) split into train and unseen
    seed = 0
    DF_train, DF_unseen = train_test_split(ds.rm_df.copy(), test_size=0.2, stratify=ds.rm_df["Response"], random_state=seed)


    #+++++++++++++++++ 3) preprocess, based on train
    pr = Processor(DF_train, DF_unseen)

    #+++++++++++++++++ 4) feature engineering
    fe = FeatureEngineer(pr.training, pr.unseen)
    do_feature_engineering(fe)
    # print(np.sum(fe.training == 0, axis=0))

    # apply Box-Cox transformations
    # num_features = fe.training._get_numeric_data().drop(['Response'], axis=1).columns
    # fe.box_cox_transformations(num_features, target="Response")

    # rank input features according to Chi-Squared
    # continuous_flist = fe.box_cox_features
    # categorical_flist = ['DT_MS_Divorced', 'DT_MS_Widow', 'DT_E_Master', 'DT_R_5', 'DT_R_6', "Gender"]
    # fe.rank_features_chi_square(continuous_flist, categorical_flist)
    # print("Ranked input features:\n", fe._rank)

    # get top n features
    # criteria, n_top = "chisq", 9
    # DF_train_top, DF_unseen_top = fe.get_top(criteria="chisq", n_top=n_top)

    #+++++++++++++++++ 5) modelling
    # mlp_param_grid = {'mlpc__hidden_layer_sizes': [(3), (6), (3, 3), (5, 5)],
    #                   'mlpc__learning_rate_init': [0.001, 0.01]}
    #
    # mlp_gscv = grid_search_MLP(DF_train_top, mlp_param_grid, seed)
    # print("Best parameter set: ", mlp_gscv.best_params_)
    # pd.DataFrame.from_dict(mlp_gscv.cv_results_).to_excel("D:\\PipeLines\\project_directory\\data\\mlp_gscv.xlsx")

    #+++++++++++++++++ 6) retraining & assessment of generalization ability
    # auprc = assess_generalization_auprc(mlp_gscv.best_estimator_, DF_unseen_top)
    # print("AUPRC: {:.2f}".format(auprc))


    #print(fe.training.columns.values)

    #+++++++++++++++++ X, y split
    y_test = fe.unseen['Response']
    y_train = fe.training['Response']
    y_train_validate = fe.training['Response'].copy()
    X_test = fe.unseen.loc[:, fe.unseen.columns != 'Response']
    X_train = fe.training.loc[:, fe.training.columns != 'Response']
    X_train_validate = X_train.copy()
    #X_train, y_train = pr.rus_sampling(X_train,y_train)
    X_train, y_train = pr.add_syntetic_data_SMOT(X_train, y_train, ratio=0.3)

    X_test.sort_index(axis=1, inplace=True)
    X_train.sort_index(axis=1, inplace=True)

    X_train_validate.sort_index(axis=1, inplace=True)



    ################ Parameter Optimization CIFO style ############################################################
    #
    # seed = 0
    # random_state = get_random_state(seed)
    # from sklearn.ensemble import RandomForestClassifier
    # search_space, default_param_dict, list_of_param_names  = tuning_forest_params()
    #
    # modelTuner = ModelTuner(search_space, list_of_param_names , profitFitness, RandomForestClassifier, X_train, y_train, X_test, y_test, minimization = False, params=default_param_dict, seed = 0)
    #
    #     hc = HillClimbing(modelTuner, random_state, 10, getNieghbor)
    #     hc.initialize()
    #     print('After init')
    #     print(hc.best_solution.representation)
    #     print(hc.best_solution.fitness)
    #
    #     hc.search(400, report=True)
    #     print('After train')
    #     print(hc.best_solution.representation)
    #     print(hc.best_solution.fitness)
    #
    #     print(hc.df)
    #     results_df = pd.concat([results_df,hc.df])
    #     # results_df.append(hc.df,ignore_index=True)
    # print(results_df)
    # results_df.to_excel('parameter_tuning_3.xlsx')
    # print(modelTuner.df)

    # KnnClassifier(X_train, y_train, X_test, y_test, seed=0, print_score=True, feature_importance=False, validate=False, select_features=100)

#---------------------------- Grid search for simple models --------------------
##### LOGREG #####

    # grid = {"C": [0.001,.009,0.01,0.09,1,5,10,25], "penalty": ["l1", "l2"]}  # l1 lasso l2 ridge
    # best_score, best_logreg = grid_tuner(LogisticRegression(), grid, 5, X_train, y_train)
    # print('Logreg F1: ', best_score)
    # # logreg = LogisticRegression()
    # # logreg_cv = GridSearchCV(logreg, grid, cv=5, scoring=profitFitness)
    # # logreg_cv.fit(X_train, y_train)
    # # y_pred = logreg_cv.predict(X_test)
    # #
    # # print("tuned hpyerparameters :(best parameters) ", logreg_cv.best_params_)
    # # fpr, tpr, threshold = metrics.roc_curve(y_test, y_pred)
    # # roc_auc = metrics.auc(fpr, tpr)
    # # import matplotlib.pyplot as plt
    # # plt.title('Receiver Operating Characteristic')
    # # plt.plot(fpr, tpr, 'b', label='AUC = %0.2f' % roc_auc)
    # # plt.legend(loc='lower right')
    # # plt.plot([0, 1], [0, 1], 'r--')
    # # plt.xlim([0, 1])
    # # plt.ylim([0, 1])
    # # plt.ylabel('True Positive Rate')
    # # plt.xlabel('False Positive Rate')
    # # # plt.show()
    # # #print(roc)
    # # print("LogReg best profit :", logreg_cv.best_score_)
    # #
    # # best_logreg = logreg_cv.best_estimator_
    #
    #
    # ## SVC ####
    # # grid = {'C':[1,10,100,1000],'gamma':[1,0.1,0.001,0.0001], 'kernel':['linear','rbf']}
    # # best_svc = grid_tuner(SVC(), grid, 5, X_train, y_train)
    # # print(best_svc)
    #
    # ### KNN ####
    # grid = {'n_neighbors': range(1,10,1), 'weights': ['uniform', 'distance'], 'algorithm': ['auto','ball_tree','kd_tree','brute'], 'leaf_size' : [20,30,3], 'p' :[1,2]}
    # # knn = KNeighborsClassifier()
    # scaler = MinMaxScaler()
    # X_train_scaled = scaler.fit_transform(X_train)
    # best_score, best_knn = grid_tuner(KNeighborsClassifier(), grid, 5, X_train_scaled, y_train)
    # print('KNN F1: ', best_score)
    #
    # ### Naive Bayes ####
    # grid = {'alpha': [0.01,0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]}
    # best_score, best_naive_by = grid_tuner(BernoulliNB(), grid, 5, X_train, y_train)
    # print('Naive Bayes F1: ', best_score)
    #
    # ### Decision Tree ####
    # grid = {'max_depth': range(1,15,1), 'min_samples_split': [0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1], 'min_samples_leaf': range(2,20,1), 'max_features' : [5,20,5]}
    # # tree = DecisionTreeClassifier()
    # best_score, best_tree = grid_tuner(DecisionTreeClassifier(), grid, 5, X_train, y_train)
    # print('DT F1: ', best_score)


    # n_gen = 20
    # ps = 10
    # p_c = 0.8
    # pm = 0.4
    #
    # ga = GeneticAlgorithm(modelTuner, random_state, ps,
    #                       tournament_selection, one_point_crossover, p_c, random_point_mutation, pm, search_space)
    # ga.initialize()
    # print('After init')
    # print(ga.best_solution.representation)
    # print(ga.best_solution.fitness)
    # ga.search(n_gen, report=True)
    # print('After train')
    # print(ga.best_solution.representation)
    # print(ga.best_solution.fitness)



    # ############### Keras Neural Net ############################################################
    X_train, X_test = do_scaling(X_train, X_test)
    y_train_validate = np.array(y_train_validate.values)
    print(y_train_validate.shape)
    from keras.wrappers.scikit_learn import KerasClassifier
    from sklearn.model_selection import cross_val_score
    from sklearn.preprocessing import LabelEncoder
    from sklearn.model_selection import StratifiedKFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import Pipeline
    # evaluate model with standardized dataset

    estimator = KerasClassifier(build_fn=build_simple, verbose=0)
    # define the grid search parameters
    batch_size = [15]
    epochs = [6]
    optimizer = ['SGD', 'RMSprop']

    param_grid = dict(optimizer=optimizer, batch_size=batch_size, epochs=epochs)

    grid = GridSearchCV(estimator=estimator, param_grid=param_grid, n_jobs=1, cv=5, scoring=ROI_)

    grid_result = grid.fit(X_train_validate, y_train_validate)
    # summarize results
    print(grid_result.best_params_)
    estimator = KerasClassifier(build_fn=build_simple
                                ,batch_size=grid_result.best_params_['batch_size']
                                ,epochs=grid_result.best_params_['epochs']
                                ,optimizer=grid_result.best_params_['optimizer']
                                ,verbose=0)
    print(grid_result.best_params_)
    estimator.fit(X_train,y_train)



    y_pred = estimator.predict(X_test)
    model_name = 'ANN'
    report_scores(y_test, y_pred, model_name)

    return y_pred

    # ############### Modeling one model at the time with class Model ############################################################

    # rf_params = {
    #     'n_jobs': -1,
    #     'n_estimators': 500,
    #     'warm_start': True,
    #     # 'max_features': 0.2,
    #     'max_depth': 6,
    #     'min_samples_leaf': 2,
    #     'max_features': 'sqrt',
    #     'verbose': 0
    # }
    #
    # from sklearn.ensemble import RandomForestClassifier
    # model = Model(RandomForestClassifier, X_train, y_train, seed=0, params=rf_params)
    # model.train()
    # y_pred = model.predict(X_test)
    #
    # from sklearn.metrics import classification_report, confusion_matrix, accuracy_score  # importing reporting methods
    # cm = confusion_matrix(y_test, y_pred)  # printing the confusion matrix
    # print('The accuracy for bagged Forest is:', accuracy_score(y_pred, y_test))

    # balancedRandomForestClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=True, validate = True, feature_importance=False)
    # do_creazy_modeling(X_train, y_train, X_test, y_test, SEED, True)
    # do_creazy_modeling(X_train, y_train, X_test, y_test, seed = 0)

    # # ############### Visualizatino on Learning Curve and overfitting ############################################################
    # from sklearn.ensemble import AdaBoostClassifier
    #
    # rf = AdaBoostClassifier()#XGBClassifier(objective="binary:logistic")
    # ## SVC(kernel='linear', class_weight='balanced', C=1.0, random_state=0)
    # rf.fit(X_train, y_train)
    # y_pred = rf.predict(X_test)
    #
    # print(profitFitness(y_test, y_pred))

        #
    #BalancedRandomForestClassifier(replacement=True)

    from sklearn.metrics import roc_curve, auc
    # false_positive_rate, true_positive_rate, thresholds = roc_curve(y_test, y_pred)
    # roc_auc = auc(false_positive_rate, true_positive_rate)
    # roc_auc

    # n_estimators = [1, 2, 4, 8, 16, 32, 64, 100, 200]
    # train_results = []
    # test_results = []
    # for estimator in n_estimators:
    #     rf.n_estimators = estimator
    #     rf.fit(X_train, y_train)
    #     train_pred = rf.predict(X_train)
    #     false_positive_rate, true_positive_rate, thresholds = roc_curve(y_train, train_pred)
    #     roc_auc = auc(false_positive_rate, true_positive_rate)
    #     train_results.append(roc_auc)
    #     y_pred = rf.predict(X_test)
    #     false_positive_rate, true_positive_rate, thresholds = roc_curve(y_test, y_pred)
    #     roc_auc = auc(false_positive_rate, true_positive_rate)
    #     test_results.append(roc_auc)
    # from matplotlib.legend_handler import HandlerLine2D
    # line1, = plt.plot(n_estimators, train_results, 'b', label ="Train AUC")
    # line2, = plt.plot(n_estimators, test_results, 'r', label ="Test AUC")
    # plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
    # plt.ylabel('AUC score')
    # plt.xlabel('n_estimators')
    # plt.show()
    #
    #
    # # Use best n_estimator
    # rf = BalancedRandomForestClassifier(replacement=True, n_estimators=n_estimators[np.argmax(test_results)])
    # rf.fit(X_train,y_train)
    # y_pred = rf.predict(X_test)
    # print(profitFitness(y_test, y_pred))
    # classifier = SVC()
    # classifier.fit(X_train, y_train)  # using the train data to train the rfc
    # y_pred = classifier.predict(X_test)  # making predicitons on the test data


    # rf = AdaBoostClassifier(n_estimators=100, learning_rate=0.95)
    # train_score = []
    # test_score = []
    # for iter in range(10):
    #     rf.fit(X_train, y_train)
    #     y_train_predicted = rf.predict(X_train)
    #     y_test_predicted = rf.predict(X_test)
    #     acc_train = accuracy_score(y_train, y_train_predicted)
    #     train_score.append(acc_train)
    #     acc_test = accuracy_score(y_test, y_test_predicted)
    #     test_score.append(acc_test)
    #     print("Iteration: {} Train acc: {} Test acc: {}".format(iter,acc_train, acc_test))
    #     rf.n_estimators += 100
    #
    # plt.plot(train_score)
    # plt.plot(test_score)
    # plt.show()

    # auprc = assess_generalization_auprc(rf, X_test, y_test)


    # print(profitFitness(y_test, y_pred))
    #
    # print("AUPRC: {:.2f}".format(auprc))

    # decisionTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, validate = False)
    # X_train, X_test = do_generic_selection(X_train, y_train, X_test)
    #
    # kNeighborsClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, validate = False)

    # ### Feature Importance
    # # get_AVG_feature_importance(X_train, y_train, X_test, y_test, print_res = True)

    ### Feature Importance
    # get_AVG_feature_importance(X_train, y_train, X_test, y_test, print_res = True)


    #
    #
    # # Set up voting
    # eclf = VotingClassifier(estimators=[('Random Forests', rf), ('Extra Trees', et),
    #                                     ('KNeighbors', knn), ('Ridge Classifier', rg)], voting='hard')
    #
    # for clf, label in zip([rf, et, knn, rg, eclf], ['Random Forest', 'Extra Trees',
    #                                                      'KNeighbors', 'Ridge Classifier', 'Ensemble']):
    #     scores = cross_val_score(clf, X, y, cv=10, scoring=ROI)
    #     print("Mean: {0:.3f}, std: (+/-) {1:.3f} [{2}]".format(scores.mean(), scores.std(), label))
    # from mlxtend.classifier import EnsembleVoteClassifier
    # ada_boost = AdaBoostClassifier()
    # grad_boost = GradientBoostingClassifier()
    # xgb_boost = XGBClassifier()
    #
    # boost_array = [ada_boost, grad_boost, xgb_boost]
    #
    # X_test[['Education', 'AcceptedCmp3', 'AcceptedCmp4', 'AcceptedCmp5', 'AcceptedCmp1', 'AcceptedCmp2', 'Complain']] = X_test[['Education', 'AcceptedCmp3', 'AcceptedCmp4', 'AcceptedCmp5', 'AcceptedCmp1', 'AcceptedCmp2', 'Complain']].astype('int64', copy=False)
    #
    # from sklearn.ensemble import RandomForestClassifier
    # from sklearn.ensemble import ExtraTreesClassifier
    # from sklearn.ensemble import AdaBoostClassifier
    # from sklearn.ensemble import GradientBoostingClassifier
    # from sklearn.model_selection import cross_val_score
    #
    # ada_boost = AdaBoostClassifier()
    # grad_boost = GradientBoostingClassifier()
    # xgb_boost = ExtraTreesClassifier()
    # forr_boost = RandomForestClassifier()
    # X = X_train.copy()
    # y = y_train.copy()
    # from mlxtend.classifier import EnsembleVoteClassifier
    #
    # eclf = EnsembleVoteClassifier(clfs=[ada_boost, grad_boost, xgb_boost, forr_boost], voting='soft', weights=[1,1,1,1])
    #
    # labels = ['Ada Boost', 'Grad Boost', 'XG Boost', 'Forest', 'Ensemble']
    #
    # for clf, label in zip([ada_boost, grad_boost, xgb_boost, forr_boost, eclf], labels):
    #     scores = cross_val_score(clf, X, y, cv=10, scoring='accuracy')
    #     print("Mean: {0:.3f}, std: (+/-) {1:.3f} [{2}]".format(scores.mean(), scores.std(), label))
    # eclf.fit(X, y)
    # y_pred = eclf.predict(X_test)
    # model_name = 'voter'
    # report_scores(y_test, y_pred, model_name)

    # from itertools import combinations
    # from sklearn.linear_model import LogisticRegression
    # from mlens.ensemble import SuperLearner
    # lr = LogisticRegression()
    #
    # names = ['Random Forest', 'Extra Trees', 'KNeighbors', 'SVC', 'Ridge Classifier']
    #
    # def zip_stacked_classifiers(*args):
    #     to_zip = []
    #     for arg in args:
    #         combined_items = sum([map(list, combinations(arg, i)) for i in range(len(arg) + 1)], [])
    #         combined_items = filter(lambda x: len(x) > 0, combined_items)
    #         to_zip.append(combined_items)
    #
    #     return zip(to_zip[0], to_zip[1])
    #
    # stacked_clf_list = zip_stacked_classifiers(clf_array, names)
    #
    # best_combination = [0.00, ""]
    #
    # for clf in stacked_clf_list:
    #
    #     ensemble = SuperLearner(scorer=accuracy_score,
    #                             random_state=seed,
    #                             folds=10)
    #     ensemble.add(clf[0])
    #     ensemble.add_meta(lr)
    #     ensemble.fit(X_train, y_train)
    #     preds = ensemble.predict(X_test)
    #     accuracy = accuracy_score(preds, y_test)
    #
    #     if accuracy > best_combination[0]:
    #         best_combination[0] = accuracy
    #         best_combination[1] = clf[1]
    #
    #     print("Accuracy score: {:.3f} {}").format(accuracy, clf[1])
    #
    # print("\nBest stacking model is {} with accuracy of: {:.3f}").format(best_combination[1], best_combination[0])
    #
    # do_stacked_modeling(X_train, y_train, X_test, y_test, seed=111, print_score=True)
    # do_voting(X_train, y_train, X_test, y_test)
    # do_creazy_modeling(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate)
    # do_voting(X_train, y_train, X_test, y_test)
    # do_bagging(X_train, y_train, X_test, y_test)


if __name__ == "__main__":
    main()