
import sys
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from data_loader import Dataset
from data_preprocessing import Processor
from feature_engineering import FeatureEngineer
from sklearn.ensemble import AdaBoostClassifier
from single_model import *
from utils import *
from model import *
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
import xgboost
from xgboost import XGBClassifier
from sklearn_tunning import grid_tuner

from CIFO_COPYPASTED import RandomSearch, HillClimbing
from model import grid_search_MLP, assess_generalization_auprc
from CIFO_MODIFIED import *
from tunning.parameter_tuning import tuning_forest_params
from neural_net import *
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from feature_selection import *
from ensemble_modeling import *
from MLens import *

from sklearn import metrics
from sklearn.naive_bayes import BernoulliNB
from sklearn.preprocessing import MinMaxScaler
SEED = 3

def main():
    #+++++++++++++++++ 1) load and prepare the data
    file_path = r"../ml_project1_data.xlsx"
    ds = Dataset(file_path)

    #+++++++++++++++++ 2) split into train and unseen

    for seed in [0,1,2,3,4]:
        DF_train, DF_unseen = train_test_split(ds.rm_df.copy(), test_size=0.2, stratify=ds.rm_df["Response"], random_state=seed)


        #+++++++++++++++++ 3) preprocess, based on train
        pr = Processor(DF_train, DF_unseen)

        #+++++++++++++++++ 4) feature engineering
        fe = FeatureEngineer(pr.training, pr.unseen)
        do_feature_engineering(fe)
        # print(np.sum(fe.training == 0, axis=0))

        # apply Box-Cox transformations
        # num_features = fe.training._get_numeric_data().drop(['Response'], axis=1).columns
        # fe.box_cox_transformations(num_features, target="Response")

        # rank input features according to Chi-Squared
        # continuous_flist = fe.box_cox_features
        # categorical_flist = ['DT_MS_Divorced', 'DT_MS_Widow', 'DT_E_Master', 'DT_R_5', 'DT_R_6', "Gender"]
        # fe.rank_features_chi_square(continuous_flist, categorical_flist)
        # print("Ranked input features:\n", fe._rank)

        # get top n features
        # criteria, n_top = "chisq", 9
        # DF_train_top, DF_unseen_top = fe.get_top(criteria="chisq", n_top=n_top)

        #+++++++++++++++++ 5) modelling
        # mlp_param_grid = {'mlpc__hidden_layer_sizes': [(3), (6), (3, 3), (5, 5)],
        #                   'mlpc__learning_rate_init': [0.001, 0.01]}
        #
        # mlp_gscv = grid_search_MLP(DF_train_top, mlp_param_grid, seed)
        # print("Best parameter set: ", mlp_gscv.best_params_)
        # pd.DataFrame.from_dict(mlp_gscv.cv_results_).to_excel("D:\\PipeLines\\project_directory\\data\\mlp_gscv.xlsx")

        #+++++++++++++++++ 6) retraining & assessment of generalization ability
        # auprc = assess_generalization_auprc(mlp_gscv.best_estimator_, DF_unseen_top)
        # print("AUPRC: {:.2f}".format(auprc))


        #print(fe.training.columns.values)

        #+++++++++++++++++ X, y split
        y_test = fe.unseen['Response']
        y_train = fe.training['Response']
        y_train_validate = fe.training['Response'].copy()
        X_test = fe.unseen.loc[:, fe.unseen.columns != 'Response']
        X_train = fe.training.loc[:, fe.training.columns != 'Response']
        X_train_validate = X_train.copy()
        #X_train, y_train = pr.rus_sampling(X_train,y_train)
        X_train, y_train = pr.add_syntetic_data_SMOT(X_train, y_train, ratio=0.3)

        X_test.sort_index(axis=1, inplace=True)
        X_train.sort_index(axis=1, inplace=True)

        X_train_validate.sort_index(axis=1, inplace=True)




        ####all features for ANN ######

        X_train_ANN = X_train
        X_test_ANN = X_test
        X_train_validate_ANN = X_train_validate

        y_train_ANN = y_train
        y_train_validate_ANN = y_train_validate

        y_test_ANN = y_test

        #####==== onyl with  the relevant features ######

        fs = Feature_Selector(X_train,X_test,y_train,seed ,X_train_validate,y_train_validate)
        fs.select_features()

        X_train = fs.X_train
        X_test = fs.X_test
        X_train_validate = fs.X_train_validate

        y_train = fs.y_train
        y_train_validate = fs.y_train_validate

        y_test = y_test




        #
        ############### Keras Neural Net ############################################################
        X_train_ANN, X_test_ANN = do_scaling(X_train_ANN, X_test_ANN)
        y_train_validate_ANN = np.array(y_train_validate_ANN.values)

        fewNeuralNet(X_train_ANN,y_train_ANN,X_test_ANN,y_test_ANN, print_score=True)



        # ##### gridsearch #####
        # estimator = KerasClassifier(build_fn=build_simple, verbose=0)
        #
        # # define the grid search parameters
        # batch_size = [2,4]
        # epochs = [2,4]
        # optimizer = ['SGD', 'RMSprop']
        #
        # param_grid = dict(optimizer=optimizer, batch_size=batch_size, epochs=epochs)
        #
        # grid = GridSearchCV(estimator=estimator, param_grid=param_grid, n_jobs=1,cv=5)
        #
        # grid_result = grid.fit(X_train_validate_ANN, y_train_validate_ANN)
        # # summarize results
        # print(grid_result.best_params_)
        # estimator = KerasClassifier(build_fn=build_simple
        #                             ,batch_size=grid_result.best_params_['batch_size']
        #                             ,epochs=grid_result.best_params_['epochs']
        #                             ,optimizer=grid_result.best_params_['optimizer']
        #                             ,verbose=0)
        # print(grid_result.best_params_)
        # estimator.fit(X_train_ANN,y_train_ANN)
        #
        #
        #
        # y_pred = estimator.predict(X_test_ANN)
        # model_name = 'ANN'
        # report_scores(y_test_ANN, y_pred, model_name)
        #
        # return y_pred
        #


if __name__ == "__main__":
    main()