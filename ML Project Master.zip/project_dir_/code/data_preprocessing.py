import sys
import numpy as np
from sklearn.impute import SimpleImputer
from imblearn.over_sampling import SMOTE
from sklearn.utils import resample
import pandas as pd
from sklearn.preprocessing import StandardScaler
from utils import pddf
from scipy.stats.mstats import winsorize

class Processor:
    """ Performs data preprocessing

        The objective of this class is to preprocess the data based on training subset. The
        preprocessing steps focus on constant features removal, missing values treatment and
        outliers removal and imputation.

    """

    def __init__(self, training, unseen):
        """ Constructor

            It is worth to notice that both training and unseen are nothing more nothing less
            than pointers, i.e., pr.training is DF_train and pr.unseen is DF_unseen yields True.
            If you want them to be copies of respective objects, use .copy() on each parameter.

        """
        self.training = training #.copy() to mantain a copy of the object
        self.unseen = unseen #.copy() to mantain a copy of the object
        self.backwardElimination()
        # self.dbscan_outliers()
        self.remove_outliers_sigma_rule(std=3.5)
        # self.drop_outliers()
        #self.median_outlier_imputer()
        #self.knn_imputer()
        #self.manual_outlier_removal()
        self.totals()
        self._del_error_data()



    def _drop_constant_features(self):
        num_df = self.training.drop(['Response'], axis=1)
        const = num_df.columns[num_df.std() < 0.01]
        self.training.drop(labels=const, axis=1, inplace=True)
        self.unseen.drop(labels=const, axis=1, inplace=True)


    # def _filter_df_by_std(self):
        # def _filter_ser_by_std(series_, n_stdev=4.0):
        #     mean_, stdev_ = series_.mean(), series_.std()
        #     cutoff = stdev_ * n_stdev
        #     lower_bound, upper_bound = mean_ - cutoff, mean_ + cutoff
        #     return [True if i < lower_bound or i > upper_bound else False for i in series_]
        #
        # training_num = self.training._get_numeric_data().drop(["DepVar"], axis=1)
        # mask = training_num.apply(axis=0, func=_filter_ser_by_std, n_stdev=4.0)
        # training_num[mask] = np.NaN
        # self.training[training_num.columns] = training_num
        #
        # return list(training_num.columns)

    def remove_outliers_sigma_rule(self,std):  # outlier deletion

        def _filter_ser_by_std(series_, n_stdev=std, print_tresh=False):
                mean_, stdev_ = series_.mean(), series_.std()
                cutoff = stdev_ * n_stdev
                lower_bound, upper_bound = mean_ - cutoff, mean_ + cutoff
                if print_tresh:
                    return lower_bound, upper_bound
                return [True if i < lower_bound or i > upper_bound else False for i in series_]

        self._df_1 = self.training[self.training['Response']==1].select_dtypes(include='category') # for concat later
        self.df_1 = self.training[self.training['Response']==1].select_dtypes(exclude='category')
        mask = self.df_1.apply(_filter_ser_by_std)
        self.df_1[mask] = np.nan
        print('Outliers detected in Resp = 1: ', self.df_1.isnull().any(axis=1).sum())
        self.df_1 = pd.concat([self.df_1, self._df_1], axis=1)

        self._df_0 = self.training[self.training['Response'] == 0].select_dtypes(include='category') # for concat
        self.df_0 = self.training[self.training['Response'] == 0].select_dtypes(exclude='category')
        mask = self.df_0.apply(_filter_ser_by_std)
        self.df_0[mask] = np.nan
        print('Outliers detected in Resp = 0:', self.df_0.isnull().any(axis=1).sum())
        self.df_0 = pd.concat([self.df_0, self._df_0], axis=1)

        self.training = pd.concat([self.df_0,self.df_1])
        self.training = self.training.dropna(axis=0)


    def winsorize(self):
        test=winsorize(self.training, limits=0.01)
        print('Printing test data', self.training)
        print('Printing winsorized data', test)
        pass
        # self.training = winsorize(self.training, limits =
        # https: // docs.scipy.org / doc / scipy - 0.14
        # .0 / reference / generated / scipy.stats.mstats.winsorize.html

    def dbscan_outliers(self):
        from sklearn.cluster import DBSCAN
        import collections
        outlier_detection = DBSCAN(
            eps=500,
            metric="euclidean",
            min_samples=4,
            n_jobs=-1)
        clusters = outlier_detection.fit_predict(self.training)
        self.training['cluster'] = clusters
        self.training = self.training[self.training['cluster']!=-1].drop(columns=['cluster'])

        print('Outliers detected using DBScan :',collections.Counter(clusters)[-1])

    def median_outlier_imputer(self):
        self.training = self.training.fillna(self.training.median())
        # self.unseen = self.unseen.fillna(self.training.median())
        #print(self.unseen.isnull().any(axis=1).sum())

    def drop_outliers(self):
        self.training = self.training.dropna(axis=0)
        # self.unseen = self.unseen.dropna(axis=0)

    def test_knn_imputer(self):
        # delete rows with more than one null
        self.training = self.training.dropna(thresh=2)
        # select categorical variables for KNN imputing
        columns = ['Income', 'Kidhome', 'Teenhome', 'Recency', 'MntWines',
       'MntFruits', 'MntMeatProducts', 'MntFishProducts', 'MntSweetProducts',
       'MntGoldProds', 'NumDealsPurchases', 'NumWebPurchases',
       'NumCatalogPurchases', 'NumStorePurchases', 'NumWebVisitsMonth']


        for i in columns:
            print(i)
            # determine error of the model
            self.training.dropna(inplace=True)
            X = self.training.drop(columns=[i])
            y = self.training[i]

            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

            from sklearn.preprocessing import MinMaxScaler
            from sklearn.metrics import mean_squared_error
            import math

            # scaler = MinMaxScaler()
            #
            # x_train_scaled = scaler.fit_transform(X_train)
            # x_train = pd.DataFrame(x_train_scaled)
            #
            # x_test_scaled = scaler.fit_transform(X_test)
            # x_test = pd.DataFrame(x_test_scaled)

            knn = KNeighborsRegressor(n_neighbors=5, metric='minkowski', p=2)
            knn.fit(X_train, y_train)

            y_pred = knn.predict(X_test)
            error = math.sqrt(mean_squared_error(y_test, y_pred))

            print(error)

            ## accuracy scores were very low so we decided to take the median

    # def knn_imputer(self):
    #     # delete rows with more than one null
    #     self.training = self.training.dropna(thresh=2)
    #     # select categorical variables for KNN imputing
    #     columns = ['Income', 'Kidhome', 'Teenhome', 'Recency', 'MntWines',
    #    'MntFruits', 'MntMeatProducts', 'MntFishProducts', 'MntSweetProducts',
    #    'MntGoldProds', 'NumDealsPurchases', 'NumWebPurchases',
    #    'NumCatalogPurchases', 'NumStorePurchases', 'NumWebVisitsMonth']
    #
    #
    #     for i in columns:
    #         print(i)
    #
    #         X = self.training.drop(columns=[i])
    #         y = self.training[i]
    #         X_test = X['']
    #
    #         X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)
    #
    #         from sklearn.preprocessing import MinMaxScaler
    #         from sklearn.metrics import mean_squared_error
    #         import math
    #
    #         # scaler = MinMaxScaler()
    #         #
    #         # x_train_scaled = scaler.fit_transform(X_train)
    #         # x_train = pd.DataFrame(x_train_scaled)
    #         #
    #         # x_test_scaled = scaler.fit_transform(X_test)
    #         # x_test = pd.DataFrame(x_test_scaled)
    #
    #         knn = KNeighborsRegressor(n_neighbors=5, metric='minkowski', p=2)
    #         knn.fit(X_train, y_train)
    #
    #         y_pred = knn.predict(X_test)
    #         error = math.sqrt(mean_squared_error(y_test, y_pred))
    #
    #         print(error)




    def _impute_num_missings_mean(self):
        self.training['Income'].fillna((self.training['Income'].mean()), inplace=True)
        self.unseen['Income'].fillna((self.unseen['Income'].mean()), inplace=True)
        # self.training = self.training.fillna(self.training.mean())
        # self.unseen = self.unseen.fillna(self.unseen.mean())



    def manual_outlier_removal(self):
        for i in [self.training, self.unseen]:
            i = i.loc[(i['Income'] < 150000) &
                                              (i['MntMeatProducts'] < 1250)&
                                              (i['MntSweetProducts'] < 225) &
                                              (i['MntGoldProds'] < 250) &
                                              (i['NumDealsPurchases'] < 7) &
                                              (i['NumWebPurchases'] < 20) &
                                              (i['NumCatalogPurchases'] <=10) &
                                              (i['NumWebVisitsMonth'] <=14) &
                                              (i['Age'] <=100)]

    def _under_sample(self):
        pass # will generate too view datapoints to train the model hence not implemented

    def add_syntetic_data_SMOT(self, x_train, y_train, ratio):
        ''' Creatures articificical data of the minority class to overcome unbalanced data.
        Better results are expected as data is more balanced, however, it might create nonsense data.'''
        sm = SMOTE(random_state=12, ratio=ratio)
        x_train_smot, y_train_smot = sm.fit_sample(x_train, y_train)
        x_train_smot = pddf(x_train_smot, columns=x_train.columns.values)
        return x_train_smot, y_train_smot

    def rus_sampling(self,X_train,y_train):
        X_full = X_train.copy()
        X_full['target'] = y_train
        X_maj = X_full[X_full.target == 0]
        X_min = X_full[X_full.target == 1]
        X_maj_rus = resample(X_maj, replace=False, n_samples=len(X_min), random_state=44)
        X_rus = pd.concat([X_maj_rus, X_min])
        X_train_rus = X_rus.drop(['target'], axis=1)
        y_train_rus = X_rus.target
        return X_train_rus,y_train_rus
        #y_rus = adaboost(X_train_rus, X_test, y_train_rus)



    # regressor_OLS = sm.OLS(endog = target, exog = df['RM']).fit()
    # regressor_OLS.summary()

    def backwardElimination(self, sl=0.05):
        import pandas as pd
        import statsmodels.api as sm
        cont_rm = self.training[['Year_Birth', 'Income', 'Recency', 'MntWines', 'MntFruits',
                     'MntMeatProducts', 'MntFishProducts', 'MntSweetProducts',
                     'MntGoldProds', 'NumDealsPurchases', 'NumWebPurchases',
                     'NumCatalogPurchases', 'NumStorePurchases', 'NumWebVisitsMonth', 'Dt_Customer']]
        cont_rm_un = self.unseen[['Year_Birth', 'Income', 'Recency', 'MntWines', 'MntFruits',
                                 'MntMeatProducts', 'MntFishProducts', 'MntSweetProducts',
                                 'MntGoldProds', 'NumDealsPurchases', 'NumWebPurchases',
                                 'NumCatalogPurchases', 'NumStorePurchases', 'NumWebVisitsMonth', 'Dt_Customer']]

        #print(cont_rm[cont_rm.isna().any(axis=1)==False])
        x=cont_rm[cont_rm.isna().any(axis=1)==False].drop(labels=['Income'], axis=1)
        y=pd.DataFrame(cont_rm[cont_rm.isna().any(axis=1)==False]['Income'])
        numVars = np.shape(x)[1]
        for i in range(0, numVars):
            regressor_OLS = sm.OLS(y, x).fit()
            maxVar = np.array(max(regressor_OLS.pvalues)).astype(float)
            if maxVar > sl:
                for j in range(0, numVars - i):
                    if (regressor_OLS.pvalues[j].astype(float) == maxVar):
                        x.drop([x.columns[j]], axis=1, inplace=True)

        # print(regressor_OLS.summary())
        #Imputing Income for Train data
        to_pred=cont_rm[cont_rm['Income'].isna()].drop(labels=['Income'], axis=1).loc[:, regressor_OLS.params.index]
        predictions_tr=regressor_OLS.predict(to_pred)
        self.training['Income'].loc[predictions_tr.index] = predictions_tr

        #Imputing Income for Test data
        to_pred_un=cont_rm_un[cont_rm_un['Income'].isna()].drop(labels=['Income'], axis=1).loc[:, regressor_OLS.params.index]
        predictions_un=regressor_OLS.predict(to_pred_un)
        self.unseen['Income'].loc[predictions_un.index] = predictions_un

    def totals(self):#works
        '''total purchases'''
        self.training['total_pur'] = (self.training['NumWebPurchases'] + self.training['NumCatalogPurchases'] +
                                      self.training['NumStorePurchases'])

        self.unseen['total_pur'] = (self.unseen['NumWebPurchases'] + self.unseen['NumCatalogPurchases'] +
                                    self.unseen['NumStorePurchases'])

        ''' total amount spent '''

        self.training['mnt_total'] = (self.training['MntWines'] +
                                      self.training['MntFruits'] +
                                      self.training['MntMeatProducts'] +
                                      self.training['MntFishProducts'] +
                                      self.training['MntSweetProducts']
                                      )

        self.unseen['mnt_total'] = (self.unseen['MntWines'] +
                                    self.unseen['MntFruits'] +
                                    self.unseen['MntMeatProducts'] +
                                    self.unseen['MntFishProducts'] +
                                    self.unseen['MntSweetProducts']
                                    )
    def _del_error_data(self):

        self.training = self.training.drop(self.training[(self.training['total_pur'] == 0) & (self.training['mnt_total'] > 0)].index)
        self.training = self.training.drop(self.training[(self.training['NumWebVisitsMonth'] == 0) & (self.training['NumWebPurchases'] > 10)].index)

