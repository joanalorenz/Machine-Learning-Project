import pandas as pd
import numpy as np
from scipy.spatial.distance import mahalanobis
from scipy.stats import chi2
from scipy.linalg import inv
import matplotlib.pyplot as plt
from utils import pddf
import seaborn as sns
import pyprind
import sys


def mahalanobis_r_pd(X,mean,S_inv):
    data = []
    for i in range(X.shape[0]):
        data.append(mahalanobis(X.iloc[i,:],mean,S_inv) ** 2)
    ser_ = pd.Series(data, X.index.values)
    return ser_


def qqplot(data):
    '''takes continuous data as np.array and returns qq plot https://en.wikipedia.org/wiki/Q–Q_plot'''

    df = data
    n = df.shape[0]
    p = df.shape[1]

    S = np.cov(df.T)
    S_inv = inv(S)

    mean = df.mean(axis=0)

    d_squared = mahalanobis_r_pd(df, mean, S_inv)

    d_squared = d_squared.sort_values()
    quantiles = np.linspace(0.5, n - 0.5, n) / n

    x = chi2.ppf(quantiles, p)
    plt.scatter(d_squared, x)
    plt.title('QQ plot for Multivariable normality')
    plt.xlabel('Squared Mahalanobis distances')
    plt.ylabel('Chi-squared quantiles')
    plt.plot(x, x, color='r')
    plt.show()


def stal_plot(df, disp=False):
    '''The stalactite plot for the detection of multivariate outliers. Atkinson, A.C. & Mulira, HM. Stat Comput (1993) 3: 27. https://doi.org/10.1007/BF00146951'''
    '''Please rest indexes before calling the function '''
    # limitation: if the Variance covariance matrix is a singular matrix the Mahalanobis distacne cant be computet which results in failure
    # disp only True when in jupyter invironment
    n = df.shape[0]
    p = df.shape[1]
    i = np.asarray(range(0, n))

    thresh = chi2.ppf((n - 0.5)/n, p)

    ind = np.zeros((n - p, n))
    ind_1 = 0

    sample = np.random.choice(i, p + 1, replace=False)  # first randomly samle n+1 for the first sample mean

    bar = pyprind.ProgBar((n-p), stream = sys.stdout)
    x_mean = df.iloc[sample].mean()
    S = df.iloc[sample].cov()
    # print(S.shape)
    S_inv = inv(S)
    M = mahalanobis_r_pd(df, x_mean, S_inv)
    ind_2 = i[M > thresh]
    ind[ind_1, ind_2] = 1
    bar.update()

    for e in (range(p + 2, n + 1)):
        ind_1 += 1
        x_mean = df.loc[M.nlargest(e).index.values].mean()
        S = df.loc[M.nlargest(e).index.values].cov()
        S_inv = inv(S)
        M = mahalanobis_r_pd(df, x_mean, S_inv)
        ind_2 = i[M > thresh]
        ind[ind_1, ind_2] = 1
        bar.update()

    out_ind = ind_2
    plot = pd.DataFrame(ind)
    if disp:

        plot_ = plot.replace(0, ' ')
        plot_ = plot_.replace(1, '*')
        with pd.option_context('display.max_rows', None, 'display.max_columns', None):  # more options can be specified also

            display(plot_)

    format_dictionary = {'outl': int(sum(plot.iloc[-1])), 'index': out_ind}
    if sum(plot.iloc[-1]) == 0:
        print('The stalactite plot found no strange observations')
    else:
        print('The stalactite plot found {outl} strange observation(s).\nIndexes{index} are/is suspicious. '.format(
            **format_dictionary))

        return out_ind



def main():
    sns.set_style("whitegrid")

    import numpy.random as nr

    cov = np.array([[1.0, 0.1, 0.1, ],
                    [0.1, 1.0, 0.1, ],
                    [0.1, 0.1, 1.0]])
    mu = np.log([0.3, 0.4, 0.5])

    mvn = nr.multivariate_normal(mu, cov, size=400)

    mvn = pddf(mvn)
    mvn.loc[15] = [10000000, 2020323891, 347123904781]

    qqplot(mvn)
    x = stal_plot(mvn
                  #, disp=True
                  )
    print(mvn.loc[x])
    mvn.drop(x, axis=0, inplace=True)
    qqplot(mvn)


if __name__ == '__main__':
    main()