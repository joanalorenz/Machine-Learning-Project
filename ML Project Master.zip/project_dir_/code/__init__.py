
import sys
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from data_loader import Dataset
from data_preprocessing import Processor
from feature_engineering import FeatureEngineer
from sklearn.ensemble import AdaBoostClassifier
from single_model import *
from utils import *
from model import *
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
import xgboost
from xgboost import XGBClassifier
from sklearn_tunning import grid_tuner

from CIFO_COPYPASTED import RandomSearch, HillClimbing
from model import grid_search_MLP, assess_generalization_auprc
from CIFO_MODIFIED import *
from tunning.parameter_tuning import tuning_forest_params
# from neural_net import *
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from feature_selection import *
from ensemble_modeling import *
from MLens import *

from sklearn import metrics
from sklearn.naive_bayes import BernoulliNB
from sklearn.preprocessing import MinMaxScaler
SEED = 3

def main():
    #+++++++++++++++++ 1) load and prepare the data
    file_path = r"../ml_project1_data.xlsx"
    ds = Dataset(file_path)

    #+++++++++++++++++ 2) split into train and unseen
    seed = 6
    DF_train, DF_unseen = train_test_split(ds.rm_df.copy(), test_size=0.2, stratify=ds.rm_df["Response"], random_state=seed)


    #+++++++++++++++++ 3) preprocess, based on train
    pr = Processor(DF_train, DF_unseen)

    #+++++++++++++++++ 4) feature engineering
    fe = FeatureEngineer(pr.training, pr.unseen)
    do_feature_engineering(fe)
    # print(np.sum(fe.training == 0, axis=0))

    # apply Box-Cox transformations
    # num_features = fe.training._get_numeric_data().drop(['Response'], axis=1).columns
    # fe.box_cox_transformations(num_features, target="Response")

    # rank input features according to Chi-Squared
    # continuous_flist = fe.box_cox_features
    # categorical_flist = ['DT_MS_Divorced', 'DT_MS_Widow', 'DT_E_Master', 'DT_R_5', 'DT_R_6', "Gender"]
    # fe.rank_features_chi_square(continuous_flist, categorical_flist)
    # print("Ranked input features:\n", fe._rank)

    # get top n features
    # criteria, n_top = "chisq", 9
    # DF_train_top, DF_unseen_top = fe.get_top(criteria="chisq", n_top=n_top)

    #+++++++++++++++++ 5) modelling
    # mlp_param_grid = {'mlpc__hidden_layer_sizes': [(3), (6), (3, 3), (5, 5)],
    #                   'mlpc__learning_rate_init': [0.001, 0.01]}
    #
    # mlp_gscv = grid_search_MLP(DF_train_top, mlp_param_grid, seed)
    # print("Best parameter set: ", mlp_gscv.best_params_)
    # pd.DataFrame.from_dict(mlp_gscv.cv_results_).to_excel("D:\\PipeLines\\project_directory\\data\\mlp_gscv.xlsx")

    #+++++++++++++++++ 6) retraining & assessment of generalization ability
    # auprc = assess_generalization_auprc(mlp_gscv.best_estimator_, DF_unseen_top)
    # print("AUPRC: {:.2f}".format(auprc))


    #print(fe.training.columns.values)

    #+++++++++++++++++ X, y split
    y_test = fe.unseen['Response']
    y_train = fe.training['Response']
    y_train_validate = fe.training['Response'].copy()
    X_test = fe.unseen.loc[:, fe.unseen.columns != 'Response']
    X_train = fe.training.loc[:, fe.training.columns != 'Response']
    X_train_validate = X_train.copy()
    #X_train, y_train = pr.rus_sampling(X_train,y_train)
    X_train, y_train = pr.add_syntetic_data_SMOT(X_train, y_train, ratio=0.3)

    X_test.sort_index(axis=1, inplace=True)
    X_train.sort_index(axis=1, inplace=True)

    X_train_validate.sort_index(axis=1, inplace=True)



    #
    ####all features for ANN ######

    X_train_ANN = X_train
    X_test_ANN = X_test
    X_train_validate_ANN = X_train_validate

    y_train_ANN = y_train
    y_train_validate_ANN = y_train_validate

    y_test_ANN = y_test

    #####==== onyl with  the relevant features ######

    fs = Feature_Selector(X_train,X_test,y_train,seed,X_train_validate,y_train_validate)
    fs.select_features()

    X_train = fs.X_train
    X_test = fs.X_test
    X_train_validate = fs.X_train_validate

    y_train = fs.y_train
    y_train_validate = fs.y_train_validate

    y_test = y_test




    #### Baseline RFC ####

    # randomForest(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed=0, print_score=True,
    #              validate=True, feature_importance=True,)

    ################ Parameter Optimization CIFO style ############################################################
    #
    # seed = 0
    # random_state = get_random_state(seed)
    # from sklearn.ensemble import RandomForestClassifier
    # search_space, default_param_dict, list_of_param_names  = tuning_forest_params()
    #
    # modelTuner = ModelTuner(search_space, list_of_param_names , profitFitness, RandomForestClassifier, X_train, y_train, X_test, y_test, minimization = False, params=default_param_dict, seed = 0)
    #
    #     hc = HillClimbing(modelTuner, random_state, 10, getNieghbor)
    #     hc.initialize()
    #     print('After init')
    #     print(hc.best_solution.representation)
    #     print(hc.best_solution.fitness)
    #
    #     hc.search(400, report=True)
    #     print('After train')
    #     print(hc.best_solution.representation)
    #     print(hc.best_solution.fitness)
    #
    #     print(hc.df)
    #     results_df = pd.concat([results_df,hc.df])
    #     # results_df.append(hc.df,ignore_index=True)
    # print(results_df)
    # results_df.to_excel('parameter_tuning_3.xlsx')
    # print(modelTuner.df)

    # KnnClassifier(X_train, y_train, X_test, y_test, seed=0, print_score=True, feature_importance=False, validate=False, select_features=100)

#---------------------------- Grid search for simple models --------------------
    # gridsearch_results = pd.DataFrame(columns=['Model','Parameters','F1 CV','Test Profit'])

    # randomForest(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed=0, print_score=True,
    #              validate=True, feature_importance=False, select_features=100, params=None)
##### LOGREG #####
    # grid = {"C": [0.001,.009]}
    # grid = {"C": [1,2,5,10], "penalty": ["l1", "l2"], 'class_weight': ['balanced'] }  # l1 lasso l2 ridge
    # estimator, params, score, profit = grid_tuner(LogisticRegression(), grid, 5, X_train, y_train,X_test,y_test)
    # gridsearch_results.loc[len(gridsearch_results)] =(['Logistic Regression',params,score,profit])
    #change params to best_logreg

    # logreg = LogisticRegression()
    # logreg_cv = GridSearchCV(logreg, grid, cv=5, scoring=profitFitness)
    # logreg_cv.fit(X_train, y_train)
    # y_pred = logreg_cv.predict(X_test)
    #
    # print("tuned hpyerparameters :(best parameters) ", logreg_cv.best_params_)
    # fpr, tpr, threshold = metrics.roc_curve(y_test, y_pred)
    # roc_auc = metrics.auc(fpr, tpr)
    # import matplotlib.pyplot as plt
    # plt.title('Receiver Operating Characteristic')
    # plt.plot(fpr, tpr, 'b', label='AUC = %0.2f' % roc_auc)
    # plt.legend(loc='lower right')
    # plt.plot([0, 1], [0, 1], 'r--')
    # plt.xlim([0, 1])
    # plt.ylim([0, 1])
    # plt.ylabel('True Positive Rate')
    # plt.xlabel('False Positive Rate')
    # # plt.show()
    # #print(roc)
    # print("LogReg best profit :", logreg_cv.best_score_)
    #
    # best_logreg = logreg_cv.best_estimator_


    ## SVC ####
    # grid = {'C': [1, 10, 100, 1000]}
    # #grid = {'C':[1,10,100,1000],'gamma':[1,0.1,0.001,0.0001], 'kernel':['linear','rbf']}
    # estimator, params, score, profit = grid_tuner(SVC(), grid, 5, X_train, y_train, X_test,y_test)
    # gridsearch_results.loc[len(gridsearch_results)] = (['SVC', params, score, profit])
    #rename params to best_svc

    ### KNN ####
    # # grid = {'n_neighbors': [6,7]}
    # grid = {'n_neighbors': [3, 5, 7], 'weights': ['uniform', 'distance'], 'algorithm': ['kd_tree','brute'], 'leaf_size' : [5,10,25], 'p' :[1,2]}
    # knn = KNeighborsClassifier()
    # scaler = MinMaxScaler()
    # X_train_scaled = scaler.fit_transform(X_train)
    # estimator, params, score, profit = grid_tuner(KNeighborsClassifier(), grid, 5, X_train_scaled, y_train,X_test,y_test)
    # gridsearch_results.loc[len(gridsearch_results)] =(['KNN',params,score,profit])
    #rename params to best_knn
    #
    #     # ### Naive Bayes ####
    #     # grid = {'alpha': [0.01, 1]}
    #     grid = {'alpha': [0.1,0.2,0.3,0.4,0.5]}
    #     estimator, params, score, profit = grid_tuner(BernoulliNB(), grid, 5, X_train, y_train,X_test,y_test)
    #     gridsearch_results.loc[len(gridsearch_results)] =(['Naive Bayes',params,score,profit])
    #     #rename params to best_naive_by
    #
    #     # ### Decision Tree ####
    #     # grid = {'max_depth': [1,5]}
    #     grid = {'max_depth': [5,13,15,20], 'min_samples_split': [0.1,0.25,0.4,0.5], 'min_samples_leaf': [5,15,25], 'max_features' : [5,12,16,8]}
    #     estimator, params, score, profit = grid_tuner(DecisionTreeClassifier(), grid, 5, X_train, y_train,X_test,y_test)
    #     gridsearch_results.loc[len(gridsearch_results)] =(['Decision Tree',params,score,profit])
    #     #rename params to best_tree
    #
    # #DOMINIKA START UNCOMMENT 2
    #     ### RGF ####
    #     from rgf.sklearn import RGFClassifier
    #     # grid = {'max_leaf': [3000]}
    #     grid = {'max_leaf': [2000,3000,  4000], 'learning_rate': [0.05, 0.1, 0.2], 'algorithm':  [ 'RGF', 'RGF Opt','RGF Sib'], 'loss': ['Log', 'Expo'], 'n_tree_search': [200, 400, 600], 'n_iter': [20, 50, 100]}
    #     estimator, params, score, profit = grid_tuner(RGFClassifier(), grid, 5, X_train, y_train,X_test,y_test)
    #     gridsearch_results.loc[len(gridsearch_results)] =(['RGF',params,score,profit])
    #     #rename params to best_RGF
    #
    # ### Ridge ####
    # from sklearn.linear_model import RidgeClassifier
    # grid = {'alpha': [0.2,0.3,0.4,0.5,0.75,1.1]}
    # estimator, params, score, profit = grid_tuner(RidgeClassifier(), grid, 5, X_train, y_train,X_test,y_test)
    # gridsearch_results.loc[len(gridsearch_results)] =(['Ridge',params,score,profit])
    #     #rename params to best_Ridge
    #
    #     ### Random Forest ####
    #     # grid = {'max_depth': [10, 30, 60]}
    #     grid = {'max_depth' : [20,30,40,50],'min_samples_split' : [0.05,0.1,0.2,0.3], 'n_estimators' : [250,400,700,900], 'max_leaf_nodes':[80,90,120,150]}
    #     estimator, params, score, profit = grid_tuner(RandomForestClassifier(), grid, 5, X_train, y_train,X_test,y_test)
    #     gridsearch_results.loc[len(gridsearch_results)] =(['Random Forest',params,score,profit])
    #     #rename params to best_RF
    #
    #      ## Hill Climbing Results ##
    #     # best_RF = RandomForestClassifier(max_depth=60,min_samples_split=0.1,n_estimators=700,max_leaf_nodes=141, min_weight_fraction_leaf=0.27)
    #
    ## Ada Boost ###
    # grid = {'n_estimators': [10,11]}
    # grid = {'learning_rate': [0.05, 0.1,0.3,0.5, 0.7], 'n_estimators' : [100, 250,400,700,900, 1200, 1500]}
    # estimator, params, score, profit = grid_tuner(AdaBoostClassifier(), grid, 5, X_train, y_train,X_test,y_test)
    # gridsearch_results.loc[len(gridsearch_results)] =(['AdaBoost',params,score,profit])
    # rename params to best_Adaboost
#
#     ### XGB ####
#     # grid = {'n_estimators': [10, 11]}
#     grid = {'min_child_weight': [5, 10, 20],'gamma': [0.5, 0.75, 1, 2], 'colsample_bytree': [ 0.8, 1.0],'max_depth' : [20,30,40,50],'learning_rate': [0.2, 0.3, 0.4, 0.5, 0.6], 'n_estimators': [200, 300, 500, 700], 'objective': ['binary:logitraw'], 'max_delta_step': [1] }
#     estimator, params, score, profit = grid_tuner(XGBClassifier(), grid, 5, X_train, y_train,X_test,y_test)
#     gridsearch_results.loc[len(gridsearch_results)] =(['XGB',params,score,profit])
#     # rename params to best_xgb
#
#     ### Gradient Boost ####
#     grid = {'n_estimators': [10, 11]}
#     grid = {'learning_rate': [0.3,0.5, 0.7], 'subsample': [0.8, 1], 'max_depth' : [15,20,30],'min_samples_split' : [0.05,0.1,0.2,0.3], 'n_estimators' : [150,200,300], 'max_leaf_nodes':[80,90,120,150] }
#     estimator, params, score, profit = grid_tuner(GradientBoostingClassifier(), grid, 5, X_train, y_train, X_test, y_test)
#     gridsearch_results.loc[len(gridsearch_results)] = (['Gradient Boost', params, score, profit])
#     #rename params to best_GradBoost
#     parametry = {'learning_rate': 0.7, 'max_depth': 30, 'max_leaf_nodes': 90, 'min_samples_split': 0.05, 'n_estimators': 150, 'subsample': 1}
    # extraTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed=0, print_score=True,
    #             validate=True, feature_importance=False, select_features=100)

    #
#     ### Extra Trees ####
#     from sklearn.ensemble import ExtraTreesClassifier
#     # grid = {'n_estimators': [10, 11]}
#     grid = {'n_estimators': [200, 300, 500, 700],'max_depth' : [20,30,40,50], 'max_features' : [5,12,16,8], 'min_samples_leaf': [5,15,25]}
#     estimator, params, score, profit = grid_tuner(ExtraTreesClassifier(), grid, 5, X_train, y_train,X_test,y_test)
#     gridsearch_results.loc[len(gridsearch_results)] =(['Extra Trees',params,score,profit])
    # print('ExtraTrees F1: ', best_score)
#     #rename params to best_ExtraTrees
#
#
#     ### Balanced Random Forest ####
#     from imblearn.ensemble import BalancedRandomForestClassifier
#     # grid = {'n_estimators': [10, 11]}
#     grid = {'n_estimators': [200, 300, 500, 700],'max_depth' : [20,30,40], 'max_features' : [5,12,8], 'min_samples_leaf': [5,15,25]}
#     estimator, params, score, profit = grid_tuner(BalancedRandomForestClassifier(), grid, 5, X_train, y_train,X_test,y_test)
#     gridsearch_results.loc[len(gridsearch_results)] =(['Balanced RF',params,score,profit])
#     print(gridsearch_results)
#     gridsearch_results.to_excel('gridsearch_results.xlsx')
    #rename params to best_BalancedRF

    #
    #
    # # n_gen = 20
    # # ps = 10
    # # p_c = 0.8
    # # pm = 0.4
    # #
    # # ga = GeneticAlgorithm(modelTuner, random_state, ps,
    # #                       tournament_selection, one_point_crossover, p_c, random_point_mutation, pm, search_space)
    # # ga.initialize()
    # # print('After init')
    # # print(ga.best_solution.representation)
    # # print(ga.best_solution.fitness)
    # # ga.search(n_gen, report=True)
    # # print('After train')
    # # print(ga.best_solution.representation)
    # # print(ga.best_solution.fitness)
    #
    #
    #
    #
    ############### Keras Neural Net ############################################################
    # X_train_ANN, X_test_ANN = do_scaling(X_train_ANN, X_test_ANN)
    # y_train_validate_ANN = np.array(y_train_validate_ANN.values)
    #
    # from keras.wrappers.scikit_learn import KerasClassifier
    # from sklearn.model_selection import cross_val_score
    # from sklearn.preprocessing import LabelEncoder
    # from sklearn.model_selection import StratifiedKFold
    # from sklearn.preprocessing import StandardScaler
    # from sklearn.pipeline import Pipeline
    # # evaluate model with standardized dataset
    #
    #
    # estimator = KerasClassifier(build_fn=build_simple_roi('adam'), epochs=12, batch_size= 50, verbose=0)
    # estimator.fit(X_train_ANN, y_train_ANN)
    # y_pred = estimator.predict(X_test_ANN)
    # model_name = 'ANN'
    # report_scores(y_test_ANN, y_pred, model_name)


    # ##### gridsearch #####
    # estimator = KerasClassifier(build_fn=build_simple, verbose=0)
    #
    # # define the grid search parameters
    # batch_size = [2,4]
    # epochs = [2,4]
    # optimizer = ['SGD', 'RMSprop']
    #
    # param_grid = dict(optimizer=optimizer, batch_size=batch_size, epochs=epochs)
    #
    # grid = GridSearchCV(estimator=estimator, param_grid=param_grid, n_jobs=1,cv=5)
    #
    # grid_result = grid.fit(X_train_validate_ANN, y_train_validate_ANN)
    # # summarize results
    # print(grid_result.best_params_)
    # estimator = KerasClassifier(build_fn=build_simple
    #                             ,batch_size=grid_result.best_params_['batch_size']
    #                             ,epochs=grid_result.best_params_['epochs']
    #                             ,optimizer=grid_result.best_params_['optimizer']
    #                             ,verbose=0)
    # print(grid_result.best_params_)
    # estimator.fit(X_train_ANN,y_train_ANN)
    #
    #
    #
    # y_pred = estimator.predict(X_test_ANN)
    # model_name = 'ANN'
    # report_scores(y_test_ANN, y_pred, model_name)
    #
    # return y_pred
    #
    #
    #
    #
    #
    #

    # ############### Modeling one model at the time with class Model ############################################################

    # rf_params = {
    #     'n_jobs': -1,
    #     'n_estimators': 500,
    #     'warm_start': True,
    #     # 'max_features': 0.2,
    #     'max_depth': 6,
    #     'min_samples_leaf': 2,
    #     'max_features': 'sqrt',
    #     'verbose': 0
    # }
    #
    # from sklearn.ensemble import RandomForestClassifier
    # model = Model(RandomForestClassifier, X_train, y_train, seed=0, params=rf_params)
    # model.train()
    # y_pred = model.predict(X_test)
    #
    # from sklearn.metrics import classification_report, confusion_matrix, accuracy_score  # importing reporting methods
    # cm = confusion_matrix(y_test, y_pred)  # printing the confusion matrix
    # print('The accuracy for bagged Forest is:', accuracy_score(y_pred, y_test))

    # balancedRandomForestClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=True, validate = True, feature_importance=False)
    # do_creazy_modeling(X_train, y_train, X_test, y_test, SEED, True)
    # do_creazy_modeling(X_train, y_train, X_test, y_test, seed = 0)

    # # ############### Visualizatino on Learning Curve and overfitting ############################################################
    # from sklearn.ensemble import AdaBoostClassifier
    #
    # rf = AdaBoostClassifier()#XGBClassifier(objective="binary:logistic")
    # ## SVC(kernel='linear', class_weight='balanced', C=1.0, random_state=0)
    # rf.fit(X_train, y_train)
    # y_pred = rf.predict(X_test)
    #
    # print(profitFitness(y_test, y_pred))

        #
    #BalancedRandomForestClassifier(replacement=True)

    from sklearn.metrics import roc_curve, auc
    # false_positive_rate, true_positive_rate, thresholds = roc_curve(y_test, y_pred)
    # roc_auc = auc(false_positive_rate, true_positive_rate)
    # roc_auc

    # n_estimators = [1, 2, 4, 8, 16, 32, 64, 100, 200]
    # train_results = []
    # test_results = []
    # for estimator in n_estimators:
    #     rf.n_estimators = estimator
    #     rf.fit(X_train, y_train)
    #     train_pred = rf.predict(X_train)
    #     false_positive_rate, true_positive_rate, thresholds = roc_curve(y_train, train_pred)
    #     roc_auc = auc(false_positive_rate, true_positive_rate)
    #     train_results.append(roc_auc)
    #     y_pred = rf.predict(X_test)
    #     false_positive_rate, true_positive_rate, thresholds = roc_curve(y_test, y_pred)
    #     roc_auc = auc(false_positive_rate, true_positive_rate)
    #     test_results.append(roc_auc)
    # from matplotlib.legend_handler import HandlerLine2D
    # line1, = plt.plot(n_estimators, train_results, 'b', label ="Train AUC")
    # line2, = plt.plot(n_estimators, test_results, 'r', label ="Test AUC")
    # plt.legend(handler_map={line1: HandlerLine2D(numpoints=2)})
    # plt.ylabel('AUC score')
    # plt.xlabel('n_estimators')
    # plt.show()
    #
    #
    # # Use best n_estimator
    # rf = BalancedRandomForestClassifier(replacement=True, n_estimators=n_estimators[np.argmax(test_results)])
    # rf.fit(X_train,y_train)
    # y_pred = rf.predict(X_test)
    # print(profitFitness(y_test, y_pred))
    # classifier = SVC()
    # classifier.fit(X_train, y_train)  # using the train data to train the rfc
    # y_pred = classifier.predict(X_test)  # making predicitons on the test data


    # rf = AdaBoostClassifier(n_estimators=100, learning_rate=0.95)
    # train_score = []
    # test_score = []
    # for iter in range(10):
    #     rf.fit(X_train, y_train)
    #     y_train_predicted = rf.predict(X_train)
    #     y_test_predicted = rf.predict(X_test)
    #     acc_train = accuracy_score(y_train, y_train_predicted)
    #     train_score.append(acc_train)
    #     acc_test = accuracy_score(y_test, y_test_predicted)
    #     test_score.append(acc_test)
    #     print("Iteration: {} Train acc: {} Test acc: {}".format(iter,acc_train, acc_test))
    #     rf.n_estimators += 100
    #
    # plt.plot(train_score)
    # plt.plot(test_score)
    # plt.show()

    # auprc = assess_generalization_auprc(rf, X_test, y_test)


    # print(profitFitness(y_test, y_pred))
    #
    # print("AUPRC: {:.2f}".format(auprc))

    # decisionTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, validate = False)
    # X_train, X_test = do_generic_selection(X_train, y_train, X_test)
    #
    # kNeighborsClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, validate = False)

    # ### Feature Importance
    # # get_AVG_feature_importance(X_train, y_train, X_test, y_test, print_res = True)

    ### Feature Importance
    # get_AVG_feature_importance(X_train, y_train, X_test, y_test, print_res = True)


    #
    #
    # # Set up voting
    # eclf = VotingClassifier(estimators=[('Random Forests', rf), ('Extra Trees', et),
    #                                     ('KNeighbors', knn), ('Ridge Classifier', rg)], voting='hard')
    #
    # for clf, label in zip([rf, et, knn, rg, eclf], ['Random Forest', 'Extra Trees',
    #                                                      'KNeighbors', 'Ridge Classifier', 'Ensemble']):
    #     scores = cross_val_score(clf, X, y, cv=10, scoring=ROI)
    #     print("Mean: {0:.3f}, std: (+/-) {1:.3f} [{2}]".format(scores.mean(), scores.std(), label))
    # from mlxtend.classifier import EnsembleVoteClassifier
    # ada_boost = AdaBoostClassifier()
    # grad_boost = GradientBoostingClassifier()
    # xgb_boost = XGBClassifier()
    #
    # boost_array = [ada_boost, grad_boost, xgb_boost]
    #
    # X_test[['Education', 'AcceptedCmp3', 'AcceptedCmp4', 'AcceptedCmp5', 'AcceptedCmp1', 'AcceptedCmp2', 'Complain']] = X_test[['Education', 'AcceptedCmp3', 'AcceptedCmp4', 'AcceptedCmp5', 'AcceptedCmp1', 'AcceptedCmp2', 'Complain']].astype('int64', copy=False)
    #### STACKING
    #
    # from sklearn.ensemble import RandomForestClassifier
    # from sklearn.ensemble import ExtraTreesClassifier
    # from sklearn.ensemble import AdaBoostClassifier
    # from sklearn.ensemble import GradientBoostingClassifier
    # from sklearn.linear_model import LogisticRegression
    # from sklearn.svm import SVC
    # # from sklearn.model_selection import cross_val_score
    #
    # dt_p = {'max_depth': 13, 'max_features': 5, 'min_samples_leaf': 15, 'min_samples_split': 0.4}
    # rf_p = {'max_depth': 30, 'max_leaf_nodes': 90, 'min_samples_split': 0.05, 'n_estimators': 250}
    # xg_p = {'colsample_bytree': 0.8, 'gamma': 0.5, 'learning_rate': 0.4, 'max_delta_step': 1, 'max_depth': 20,
    #         'min_child_weight': 5, 'n_estimators': 700, 'objective': 'binary:logitraw'}
    # ada_p = {'learning_rate': 0.1, 'n_estimators': 1200}
    # gb_p = {'learning_rate': 0.7, 'max_depth': 30, 'max_leaf_nodes': 90, 'min_samples_split': 0.05, 'n_estimators': 150,'subsample': 1}
    # ex_p = {'max_depth': 30, 'max_features': 10, 'min_samples_leaf': 5, 'n_estimators': 500}
    # knn_p = {'algorithm': 'kd_tree', 'leaf_size': 10, 'n_neighbors': 3, 'p': 1, 'weights': 'distance'}
    # lg_p = {'C': 2, 'class_weight': 'balanced', 'penalty': 'l2'}
    # brf_p = {'max_depth': 40, 'max_features': 8, 'min_samples_leaf': 5, 'n_estimators': 500}
    #
    # #
    # DT= DecisionTreeClassifier(**dt_p)
    # RFor= RandomForestClassifier(**rf_p)
    # ADA= AdaBoostClassifier(**ada_p)
    # GBt= GradientBoostingClassifier(**gb_p)
    # ext= ExtraTreesClassifier(**ex_p)
    # nb= BernoulliNB()
    # ridge= RidgeClassifier()
    # # rgf= RGFClassifier()
    # xb= XGBClassifier(**xg_p)
    # knn= KNeighborsClassifier(**knn_p)
    # lr= LogisticRegression(**lg_p)
    # brf=BalancedRandomForestClassifier(**brf_p)
    #
    # # X = X_train.copy()
    # # y = y_train.copy()
    # # from mlxtend.classifier import EnsembleVoteClassifier
    # #
    # # eclf = EnsembleVoteClassifier(clfs=[ada_boost, grad_boost, xgb_boost, forr_boost], voting='soft', weights=[1,1,1,1])
    # #
    # # labels = ['Ada Boost', 'Grad Boost', 'XG Boost', 'Forest', 'Ensemble']
    # #
    # # for clf, label in zip([ada_boost, grad_boost, xgb_boost, forr_boost, eclf], labels):
    # #     scores = cross_val_score(clf, X, y, cv=10, scoring='accuracy')
    # #     print("Mean: {0:.3f}, std: (+/-) {1:.3f} [{2}]".format(scores.mean(), scores.std(), label))
    # # eclf.fit(X, y)
    # # y_pred = eclf.predict(X_test)
    # # model_name = 'voter'
    # # report_scores(y_test, y_pred, model_name)
    #
    # from mlens.ensemble import SuperLearner
    # from sklearn.metrics import accuracy_score
    # from sklearn.metrics import f1_score
    # # from sklearn.model_selection import train_test_split
    #
    # seed = 1075
    #
    # X = np.array(X_train_validate.values)
    # y = np.array(y_train_validate.values)
    # X_t = np.array(X_test.values)
    #
    # def build_ensemble(incl_meta, propagate_features=None):
    #     """Return an ensemble."""
    #     if propagate_features:
    #         n = len(propagate_features)
    #         propagate_features_1 = propagate_features
    #         propagate_features_2 = [i for i in range(n)]
    #     else:
    #         propagate_features_1 = propagate_features_2 = None
    #
    #     estimators = [RandomForestClassifier(random_state=seed), KNeighborsClassifier(), BernoulliNB(), AdaBoostClassifier()]
    #     # estimators2 = [LogisticRegression(), KNeighborsClassifier()]
    #
    #     ensemble = SuperLearner()
    #     ensemble.add(estimators, propagate_features=propagate_features_1)
    #     ensemble.add(estimators, propagate_features=propagate_features_2)
    #
    #     if incl_meta:
    #         ensemble.add_meta(SVC())
    #     return ensemble
    #
    # # ensemble = SuperLearner(scorer=f1_score,
    # #                         random_state=seed,
    # #                         folds=10,
    # #                         verbose=2)
    # #
    # # # Build the first layer
    # # ensemble.add([ridge, knn, lr, nb])
    # #
    # # ensemble.add([lr, brf])
    # # # Attach the final meta estimator
    # # ensemble.add_meta(SVC())
    # #
    #
    # ensemble = build_ensemble(True, [1,2,3,4,5])
    #
    #
    # # from mlens.ensemble import BlendEnsemble
    # # from sklearn.linear_model import LogisticRegression
    # # from sklearn.ensemble import RandomForestClassifier
    # # from sklearn.svm import SVC
    # #
    # # def build_ensemble(proba, **kwargs):
    # #     """Return an ensemble."""
    # #     estimators = [RandomForestClassifier(random_state=seed), KNeighborsClassifier(), BernoulliNB(), AdaBoostClassifier()]
    # #
    # #     ensemble = BlendEnsemble(**kwargs)
    # #     ensemble.add(estimators, proba=proba)  # Specify 'proba' here
    # #     ensemble.add_meta(LogisticRegression())
    # #
    # #     return ensemble
    #
    #
    # # ensemble = build_ensemble(True)
    # ensemble.fit(X, y)
    # preds = ensemble.predict(X_t)
    # accuracy = accuracy_score(preds, y_test)
    # profit = profitFitness(preds, y_test)
    # model_name = 'kjsdnfl'
    # report_scores(y_test, preds, model_name)
    #
    # print("Fit data:\n%r" % ensemble.data)
    # print(accuracy)
    # print(profit)
    #

    # from itertools import combinations
    #
    # names = ['Random Forest', 'Extra Trees', 'KNeighbors', 'SVC', 'Ridge Classifier']
    #
    # def zip_stacked_classifiers(*args):
    #     to_zip = []
    #     for arg in args:
    #         combined_items = sum([map(list, combinations(arg, i)) for i in range(len(arg) + 1)], [])
    #         combined_items = filter(lambda x: len(x) > 0, combined_items)
    #         to_zip.append(combined_items)
    #
    #     return zip(to_zip[0], to_zip[1])
    #
    # stacked_clf_list = zip_stacked_classifiers(clf_array, names)
    #
    # best_combination = [0.00, ""]
    #
    # for clf in stacked_clf_list:
    #
    #     ensemble = SuperLearner(scorer=accuracy_score,
    #                             random_state=seed,
    #                             folds=10)
    #     ensemble.add(clf[0])
    #     ensemble.add_meta(lr)
    #     ensemble.fit(X_train, y_train)
    #     preds = ensemble.predict(X_test)
    #     accuracy = accuracy_score(preds, y_test)
    #
    #     if accuracy > best_combination[0]:
    #         best_combination[0] = accuracy
    #         best_combination[1] = clf[1]
    #
    #     print("Accuracy score: {:.3f} {}").format(accuracy, clf[1])
    #
    # print("\nBest stacking model is {} with accuracy of: {:.3f}").format(best_combination[1], best_combination[0])
    # do_stacked_modeling(X_train, y_train, X_test, y_test, seed=111, print_score=True)
    # do_voting(X_train, y_train, X_test, y_test)

    # do_creazy_modeling_whole(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, SEED, return_preds=False)
    # do_voting(X_train, y_train, X_test, y_test)
    # do_bagging(X_train, y_train, X_test, y_test)

    #Compare DOMINIKA
    #class_list = [KnnClassifier, xGBoost, randomForest, decisionTrees, ridgeClassifier, rgfClassifier, adaBoost, gradBoost, extraTrees, logisticRegression, naiveBayes, balancedRandomForestClassifier]

    #extraTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed=0, print_score=False,
     #          validate=True, feature_importance=False, select_features=100, params=None)

    #ADD!!!!!!!!!!!!RIDGE, RGF,GRAD

    # preds = do_creazy_modeling(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, 4, True)
    # print(preds.head())
    # preds.to_csv('Input_to_NN.csv')

    # neuralNet(X_train, y_train, X_test, y_test, seed=0, print_score=True, validate=False)

    # do_creazy_modeling_whole(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, SEED,
    #                        return_preds=False)
    # model = load_model('my_model_2.h5')

    # preds = pd.read_csv('Input_to_NN.csv')
    # #
    # # preds = do_creazy_modeling(X_train, y_train, X_test, y_test)
    # y = preds.iloc[:, -1]
    # X = preds.iloc[:, :-1]
    # X_ar = X.values
    # y_ar = y.values
    # X_ar2 = X_ar[:, 2:]
    # X_train_NN, X_test_NN, y_train_NN, y_test_NN = train_test_split(X_ar2, y_ar, test_size=0.2, random_state=0)
    # NN_on_oredictions(X_train_NN, y_train_NN, X_test_NN, y_test_NN, print_score=True)

    # grid = {'max_depth': [1,5]}
    # #grid = {'max_depth': range(1,15,1), 'min_samples_split': [0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9], 'min_samples_leaf': range(2,20,1), 'max_features' : [5,30,8]}
    # best_score, best_tree = grid_tuner(DecisionTreeClassifier(), grid, 5, X_train, y_train)
    #
    # best_tree={'max_depth': 15, 'min_samples_split': 0.4, 'min_samples_leaf': 10, 'max_features' : 15}
    # class_list=[decisionTrees]#, adaBoost, KnnClassifier, xGBoost, randomForest, naiveBayes, balancedRandomForestClassifier, logisticRegression, extraTrees]
    # best_mods = [best_tree]#, best_Adaboost, best_knn, best_xgb, best_RF, best_naive_by, best_BalancedRF, best_logreg, best_ExtraTrees]
    # #
    # par_dict = []
    # for i in best_mods:
    #     par_dict.append(i)
    #
    # table_comp = table_compare(class_list, X_train, y_train, X_test, y_test, X_train_validate, y_train_validate,
    #                             params=None)
    # #
    # table_comp2=table_compare(class_list, X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, params=par_dict)
    # #
    # #
    # tab_plot(table_comp, table_comp2)
    #



    # y_pred = model.predict(X_test)
    # for q in range(len(y_pred)):
    #     if y_pred[q] < 0.6:
    #         y_pred[q] = 0
    #     else:
    #         y_pred[q] = 1


if __name__ == "__main__":
    main()