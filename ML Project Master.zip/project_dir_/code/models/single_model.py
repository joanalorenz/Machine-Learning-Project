import numpy as np
from utils import report_scores, do_validation, scores_for_table

import pandas as pd
from tunning.feature_selection import *



def decisionTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    from sklearn.tree import DecisionTreeClassifier  # importing the tree
    model_name = 'Decission Tree'
    parametry = {'max_depth': 13, 'max_features': 5, 'min_samples_leaf': 15, 'min_samples_split': 0.4}

    if params==None:
        classifier = DecisionTreeClassifier(**parametry)
    else:
        #classifier = DecisionTreeClassifier(random_state=seed, max_depth=params['max_depth'])
        classifier = DecisionTreeClassifier(**params)

    if select_features != 100:
        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)  # using the train data to train the tree
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list=do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_dt = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_dt

    if feature_importance:
        return classifier.feature_importances_

    return y_pred


#LUKAS FEATURE SELECTION NOW CALLED randomForest2!!!!!!
def randomForest2(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100):
    from sklearn.ensemble import RandomForestClassifier
    model_name = 'Random Forrest'
    parametry = {'max_depth': 30, 'max_leaf_nodes': 90, 'min_samples_split': 0.05, 'n_estimators': 250}
    classifier = RandomForestClassifier(**parametry)

    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)
    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        print(list)
        return list

    if feature_importance:
        return classifier.feature_importances_

    return y_pred



def randomForest(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    from sklearn.ensemble import RandomForestClassifier
    model_name = 'Random Forrest'
    parametry = {'max_depth': 30, 'max_leaf_nodes': 90, 'min_samples_split': 0.05, 'n_estimators': 250}

    if params==None:
        classifier = RandomForestClassifier(**parametry
            # n_estimators=500,
            # random_state=seed,
            # criterion="entropy",
            # max_depth=20,
            # min_samples_split=2
            # max_depth=60, min_samples_split=0.1, n_estimators=700, max_leaf_nodes=141, min_weight_fraction_leaf=0.27
        )
    else:
        classifier = RandomForestClassifier(**params
            # n_estimators=params['n_estimators'],
            # random_state=seed,
            # criterion="entropy",
            # max_depth=params['max_depth'],
            # min_samples_split=params['min_samples_split'],
            # max_leaf_nodes=params['max_leaf_nodes'],
            # min_weight_fraction_leaf=params['min_weight_fraction_leaf']
        )


    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)#10 DOM)
        scores_for_table_rfc = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_rfc

    if feature_importance:
        return classifier.feature_importances_

    return y_pred

def ridgeClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100):
    from sklearn.linear_model import RidgeClassifier
    model_name = 'Ridge'
    classifier = RidgeClassifier(
        alpha=0.75
    )
    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)
    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        #print(list)
        scores_for_table_rc = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_rc

    if feature_importance:
        return classifier.coef_

    return y_pred

def rgfClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False):
    from rgf.sklearn import RGFClassifier
    model_name = 'RGF'
    # parametry = {'max_leaf': 4000, 'learning_rate': 0.1, 'algorithm':  'RGF_Opt', 'loss': 'Log', 'n_tree_search': 400, 'n_iter': 2}

    classifier = RGFClassifier(
        # max_leaf=400,
        # algorithm="RGF_Sib",
        # test_interval=100,
        # verbose=False
    )
    #featureselection is not possible automatically

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)
    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        #print(list)
        scores_for_table_rgf = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_rgf

    if feature_importance:
        return classifier.feature_importances_

    return y_pred


def xGBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    model_name = 'XGBoost'
    from xgboost import XGBClassifier
    parametry = {'colsample_bytree': 0.8, 'gamma': 0.5, 'learning_rate': 0.4, 'max_delta_step': 1, 'max_depth': 20, 'min_child_weight': 5, 'n_estimators': 700, 'objective': 'binary:logitraw'}
    if params==None:
        classifier = XGBClassifier(**parametry
        # #     max_depth=10,
        # #     n_estimators=2000,
        # #     learning_rate=0.03,
        # #     n_jobs=-1,
        # #     seed = seed
        # # )
        # learning_rate = 0.02,
        # n_estimators = 600,
        # max_depth = 4,
        # min_child_weight = 2,
        # # gamma=1,
        # gamma = 0.9,
        # subsample = 0.8,
        # colsample_bytree = 0.8,
        # objective = 'binary:logitraw',
        # nthread = -1,
        # scale_pos_weight = 1,
        )
    else:
        classifier = XGBClassifier(**params
        #     max_depth=10,
        #     n_estimators=2000,
        #     learning_rate=0.03,
        #     n_jobs=-1,
        #     seed = seed
        # )
        # learning_rate = 0.02,
        # n_estimators = params['n_estimators'],
        # max_depth = 4,
        # min_child_weight = 2,
        # # gamma=1,
        # gamma = 0.9,
        # subsample = 0.8,
        # colsample_bytree = 0.8,
        # objective = 'binary:logitraw',
        # nthread = -1,
        # scale_pos_weight = 1,
        )

    X_test = X_test.apply(pd.to_numeric)

    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T
    seed = seed
    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_xgb = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_xgb

    if feature_importance:
        return classifier.feature_importances_

    return y_pred



def adaBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    from sklearn.ensemble import AdaBoostClassifier
    model_name = 'ADABoost'
    parammetry = {'learning_rate': 0.1, 'n_estimators': 1200}
    if params==None:
        classifier = AdaBoostClassifier(**parammetry)
    else:
        classifier = AdaBoostClassifier(**params
            # random_state=seed,
            # n_estimators = params['n_estimators'],
            # learning_rate = 0.75
        )


    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)
    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_ada = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_ada

    if feature_importance:
        return classifier.feature_importances_

    return y_pred


def gradBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params = None):
    from sklearn.ensemble import GradientBoostingClassifier
    model_name = 'GradientBoost'
    parametry = {'learning_rate': 0.7, 'max_depth': 30, 'max_leaf_nodes': 90, 'min_samples_split': 0.05, 'n_estimators': 150, 'subsample': 1}
    # parametry = {}
    classifier = GradientBoostingClassifier(learning_rate= 0.7, max_depth= 30, max_leaf_nodes= 90, min_samples_split= 0.05, n_estimators= 150, subsample= 1
    )
    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_grad = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_grad

    if feature_importance:
        return classifier.feature_importances_


    return y_pred

#(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed=0, print_score=False, validate=True, params=params[i])

def extraTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed=0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    from sklearn.ensemble import ExtraTreesClassifier
    model_name = 'ExtraTree'
    # params = {'max_depth': 30, 'max_features': 16, 'min_samples_leaf': 5, 'n_estimators': 500}
    s = seed
    if params==None:
        classifier = ExtraTreesClassifier(**params
            # n_jobs = -1,
            # n_estimators = 500,
            # # max_features = 0.5,
            # max_depth = 8,
            # min_samples_leaf = 2,
            # verbose = 0
        )
    else:
        classifier = ExtraTreesClassifier(**params
            # n_jobs = -1,
            # n_estimators = params['n_estimators'],
            # # max_features = 0.5,
            # max_depth = 8,
            # min_samples_leaf = 2,
            # verbose = 0
        )

    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_extrees = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_extrees

    if feature_importance:
        return classifier.feature_importances_

    return y_pred



def svc(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100):
    from sklearn.svm import SVC
    model_name = 'Support Vector'
    classifier = SVC(
        kernel = 'linear',
        C = 0.025,
        random_state = seed
    )
    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_svc = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_svc

    if feature_importance:
        pass

    return y_pred



def KnnClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    from sklearn.neighbors import KNeighborsClassifier
    model_name = 'KNN Classifier'
    from sklearn.neighbors import KNeighborsClassifier
    from sklearn.preprocessing import MinMaxScaler
    parametry = {'algorithm': 'kd_tree', 'leaf_size': 10, 'n_neighbors': 3, 'p': 1, 'weights': 'distance'}

    # scaler = MinMaxScaler()
    # X_train = scaler.fit_transform(X_train)
    if params==None:
        classifier = KNeighborsClassifier(**parametry)
    else:
        classifier = KNeighborsClassifier(**params
            #n_neighbors=params['n_neighbors']
        )

    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)
    y_pred = classifier.predict(X_test)

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_knn = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_knn

    if feature_importance:
        pass

    return y_pred



def logisticRegression(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    model_name = 'Logistic Regression'
    from sklearn.linear_model import LogisticRegression
    parametry = {'C': 2, 'class_weight': 'balanced', 'penalty': 'l2'}

    if params==None:
        classifier = LogisticRegression(**parametry)
    else:
        classifier = LogisticRegression(**params
            #random_state=seed, C=params['C']
        )

    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)
    y_pred = classifier.predict(X_test)
    # print(y_pred)
    # for q in range(len(y_pred)):
    #     if y_pred[q] < 0.5:
    #         y_pred[q] = 0
    #     else:
    #         y_pred[q] = 1
    # print(y_pred)

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list=do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_logreg = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_logreg

    if feature_importance:
        pass

    return y_pred



def naiveBayes(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    model_name = 'BernoulliNB'
    from sklearn.naive_bayes import BernoulliNB
    if params==None:
        classifier = BernoulliNB (alpha= 0.1
    )
    else:
        classifier = BernoulliNB(**params)
            #binarize=True, alpha=params['alpha']
        # )


    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)
    y_pred = classifier.predict(X_test)

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        scores_for_table_naiveB = scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return scores_for_table_naiveB

    if feature_importance:
        pass

    return y_pred





def balancedRandomForestClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100, params=None):
    model_name = 'BalancedRandomForestClassifier'
    from imblearn.ensemble import BalancedRandomForestClassifier
    parametry = {'max_depth': 40, 'max_features': 8, 'min_samples_leaf': 5, 'n_estimators': 500}
    if params==None:
        classifier = BalancedRandomForestClassifier(**parametry)
    else:
        #classifier = BalancedRandomForestClassifier(n_estimators=params['n_estimators'])
        classifier = BalancedRandomForestClassifier(**params)

    if select_features != 100:

        features = do_RFE_selection(classifier, X_train, y_train, select_features)
        X_train, X_test = X_train.T[features].T, X_test.T[features].T

    classifier.fit(X_train, y_train)
    y_pred = classifier.predict(X_test)

    if print_score:
        report_scores(y_test, y_pred, model_name)

    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        best_BalancedRF=scores_for_table(classifier, X_train_validate, y_train_validate, cv=10)
        return best_BalancedRF

    if feature_importance:
        pass

    return y_pred

def table_compare(classifier_list, X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, params=None):
    pd.set_option('display.max_columns', 500)
    #classifier_list=[randomForest, decisionTrees, ridgeClassifier, rgfClassifier, adaBoost, gradBoost, extraTrees, logisticRegression, naiveBayes]
    table_columns=dict()
    if params!=None:
        for i in range(len(classifier_list)):
            #print('pierwszy element listy:', params[i])
            table_columns[classifier_list[i].__name__] = classifier_list[i](X_train, y_train, X_test, y_test,
                                                                            X_train_validate, y_train_validate, seed=0,
                                                                            print_score=False, validate=True,
                                                                            params=params[i])#params[i])
    else:
        for i in range(len(classifier_list)):
            table_columns[classifier_list[i].__name__] = classifier_list[i](X_train, y_train, X_test, y_test,
                                                                            X_train_validate, y_train_validate, seed=0,
                                                                             print_score=False, validate=True,
                                                                            params=None)

    compare_table=pd.DataFrame.from_dict(table_columns, orient='index', columns=['accuracy', 'precision', 'recall', 'f1_macro','ROI_pc'])
    #compare_table=compare_table.assign(new_accuracy=1, new_precision=1, new_recall=1, new_f1=1, new_ROI_pc=1)
    print(compare_table)
    return compare_table



def randomForest_unseen(X_train, y_train, X_test, X_train_validate, y_train_validate, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100):
    from sklearn.ensemble import RandomForestClassifier
    model_name = 'Random Forrest'
    classifier = RandomForestClassifier(
        n_estimators=500,
        random_state=seed,
        criterion="entropy",
        max_depth=20,
        min_samples_split=2
    )

    classifier.fit(X_train, y_train)  # using the train data to train the rfc
    y_pred = classifier.predict(X_test)  # making predicitons on the test data

    if print_score:
        report_scores(y_test, y_pred, model_name)
    if validate:
        list = do_validation(classifier, X_train_validate, y_train_validate, cv=10)
        print(list)
        return list

    if feature_importance:
        return classifier.feature_importances_

    return y_pred
