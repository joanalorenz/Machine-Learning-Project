from utils import report_scores, do_validation
from sklearn.metrics import accuracy_score, classification_report

from mlens.ensemble import SuperLearner
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.svm import SVC

def do_stacked_modeling(X_train, y_train, X_test, y_test, seed = 6, print_score=False, validate = False, feature_importance=False, select_features = 100):
    model_name = 'stacked_modeling'

    ensemble = SuperLearner(scorer=accuracy_score, random_state=seed)

    # Build the first layer
    ensemble.add([DecisionTreeClassifier(random_state=seed), DecisionTreeClassifier()])

    # # Build the second layer
    # ensemble.add([LogisticRegression(), SVC()])

    # Attach the final meta estimator
    ensemble.add_meta(DecisionTreeClassifier())

    ensemble.fit(X_train, y_train)
    y_pred = ensemble.predict(X_test)

    if print_score:
        report_scores(y_test, y_pred, model_name)

    return y_pred

