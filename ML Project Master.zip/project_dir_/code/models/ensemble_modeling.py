from sklearn.ensemble import VotingClassifier
from sklearn import svm
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score

from plotting import compare_scores
from single_model import *
from utils import *

from sklearn.metrics import classification_report, confusion_matrix, balanced_accuracy_score  # importing reporting methods
from sklearn.ensemble import VotingClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn import svm
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import RidgeClassifier
from rgf.sklearn import RGFClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from imblearn.ensemble import BalancedRandomForestClassifier
from xgboost import XGBClassifier

# ensemble_lin_rbf=VotingClassifier(estimators=[('KNN',KNeighborsClassifier(n_neighbors=10)),
#                                               ('RBF',svm.SVC(probability=True,kernel='rbf',C=0.5,gamma=0.1)),
#                                               ('RFor',RandomForestClassifier(n_estimators=500,random_state=0)),
#                                               ('LR',LogisticRegression(C=0.05)),
#                                               ('DT',DecisionTreeClassifier(random_state=0)),
#                                               ('NB',GaussianNB()),
#                                               ('svm',svm.SVC(kernel='linear',probability=True))
#                                              ],
#                     voting='soft', # or hard
#                     # weights : array-like, shape = [n_classifiers]
#                     n_jobs = -1
#                                   ).fit(X_train,y_train)
#
#
# print('The accuracy for ensembled model is:',ensemble_lin_rbf.score(X_test,y_test))
# print(classification_report(y_test, y_pred))

############## Voting Approach ############################################################
# [0.33984776 0.33637484 0.51440306 0.48846971 0.47696048 0.58890874 0.36598699]
def do_voting(X_train, y_train, X_test, y_test):

    seed = 5
    X_test = X_test.apply(pd.to_numeric)
    ensemble_lin_rbf = VotingClassifier(estimators=[
                                                    # ('RFor', RandomForestClassifier(**rf_p)),
                                                    ('ADA', AdaBoostClassifier(**ada_p)),
                                                    ('GBt', GradientBoostingClassifier(**gb_p)),
                                                    # ('ext', ExtraTreesClassifier(**ex_p)),
                                                    # ('nb', BernoulliNB()),
                                                    # ('ridge', RidgeClassifier()),
                                                    # ('rgf', RGFClassifier()),
                                                    ('xb', XGBClassifier(**dt_p)),
                                                    # ('knn', KNeighborsClassifier()),
                                                    ('lg', LogisticRegression(**lg_p)),
                                                    ('brf', BalancedRandomForestClassifier(**brf_p))
                                                    ],
                                        voting='soft',  # or hard
                                        # weights= [1,1, 1, 1,1 ],   #array-like, shape = [n_classifiers]
                                        # weights= [1.866,
                                        #              1.866,
                                        #           1.8727,
                                        #           1.80,
                                        #              1.801], # weights determined by accuracy with each other !
                                        weights= [1.266,
                                                     1.30,
                                                  1.44,
                                                  1.51,
                                                     1.31], # weights determined by uncorrelation with each other !

        n_jobs=-1
                                        ).fit(X_train, y_train)

    print('The accuracy for ensembled model is:', ensemble_lin_rbf.score(X_test, y_test))
    y_pred = ensemble_lin_rbf.predict(X_test)
    print(classification_report(y_test, y_pred))
    print(confusion_matrix(y_test, y_pred))
    print(balanced_accuracy_score(y_test, y_pred))
    print(profitFitness(y_test, y_pred))

#
# from sklearn.ensemble import BaggingClassifier
# model = BaggingClassifier(base_estimator=RandomForestClassifier(n_estimators=500,criterion="entropy"), random_state=0, n_estimators=5)
# model.fit(X_train, y_train)
# prediction = model.predict(X_test)
# from sklearn.metrics import accuracy_score
#
# print('The accuracy for bagged Forest is:', accuracy_score(prediction, y_test))
#Bagging on DT, AdaBoost on DT, GXBoost on DT, Random Forest
#wheres XGBoost???

# ############### Modeling several model at the time ############################################################

def do_creazy_modeling(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, SEED, return_preds=False):
    dt = decisionTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    rf = randomForest(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    ada = adaBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    gb = gradBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    et = extraTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    nb = naiveBayes(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    rg = ridgeClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    rgf = rgfClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    xg = xGBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    knn = KnnClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    lr = logisticRegression(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    brf= balancedRandomForestClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)


    # DataFrame with all predictions
    all_prediction = pd.DataFrame([dt, rf, ada, gb, et, nb, rg, rgf, xg, knn, lr, brf, y_test ], index  = ['decisionTrees', 'randomForest', 'adaBoost', 'gradBoost', 'extraTrees', 'naiveBayes','ridge', 'rgf', 'xgboost', 'knn', 'logistic', 'balancedForr' ,'true_pred'])
    all_prediction2 = all_prediction.T

    if return_preds:
        return all_prediction2

    ### Calculating correlation between prediction to use uncorrelated data for better prediction
    from scipy import spatial
    corr = pd.DataFrame()
    temp_cor = []
    for column in all_prediction2:
        temp_temp_cor = []
        for column2 in all_prediction2:
            temp_temp_cor.append(1 - spatial.distance.cosine(all_prediction2[column], all_prediction2[column2]))
        temp_cor.append(temp_temp_cor)

    temp_cor_avg = np.average(temp_cor, axis=0)
    print(temp_cor_avg)

    # return all_prediction2

    test_accuracy = []
    for column in all_prediction2:
        score = np.sum((all_prediction2[column] == all_prediction2['true_pred']).astype(int))
        test_accuracy.append(np.round(score/all_prediction2.shape[0] * 100, 2))
    #
    test_accuracy = test_accuracy[:-1]
    accuracy = pd.DataFrame(test_accuracy)
    list_of_names = ['decisionTrees', 'randomForest', 'adaBoost', 'gradBoost', 'extraTrees', 'naiveBayes','ridge', 'rgf', 'xgboost', 'knn', 'logistic', 'balancedForr']
    metrics_name = 'Accuracy'
    compare_scores(accuracy, list_of_names, metrics_name)



# ############### Bagging Approach ############################################################
def do_bagging(X_train, y_train, X_test, y_test, seed = 0, print_score=False, validate = False, feature_importance=False, select_features = 100):
    model_name = 'Bagging Approach'
    X = X_train.copy()
    y = y_train.copy()
    X_test = X_test.copy()
    y_test = y_test.copy()

    DT= DecisionTreeClassifier(**dt_p)
    RFor= RandomForestClassifier(**rf_p)
    ADA= AdaBoostClassifier(**ada_p)
    GBt= GradientBoostingClassifier(**gb_p)
    ext= ExtraTreesClassifier(**ex_p)
    # nb= BernoulliNB(**dt_p)
    # ridge= RidgeClassifier(**dt_p)
    # rgf= RGFClassifier()
    xb= XGBClassifier(**dt_p)
    knn= KNeighborsClassifier(**knn_p)
    lg= LogisticRegression(**lg_p)
    brf=BalancedRandomForestClassifier(**brf_p)

    np.random.seed(seed)

    clf_array = [#DT, RFor, ADA, GBt,
                 ext, xb,knn, lg,brf]

    for clf in clf_array:
        vanilla_scores = cross_val_score(clf, X, y, cv=5, n_jobs=-1)
        bagging_clf = BaggingClassifier(clf,
                                        max_samples=0.4, max_features=10, random_state=seed)
        bagging_scores = cross_val_score(bagging_clf, X, y, cv=5,
                                         n_jobs=-1)

        print("Mean of: {1:.3f}, std: (+/-) {2:.3f} [{0}]".format(clf.__class__.__name__,
                                                            vanilla_scores.mean(), vanilla_scores.std()))
        print("Mean of: {1:.3f}, std: (+/-) {2:.3f} [Bagging {0}]".format(clf.__class__.__name__,
                                                                      bagging_scores.mean(), bagging_scores.std()))
        bagging_clf.fit(X_train, y_train)
        prof_scores  = cross_val_score(bagging_clf, X, y, cv=10, scoring=ROI, n_jobs=-1)

        print("Mean of: {1:.3f}, std: (+/-) {2:.3f} [Bagging {0}]\n".format(clf.__class__.__name__,
                                                                            prof_scores.mean(), prof_scores.std()))
from sklearn.model_selection import train_test_split
from neural_net import NN_on_oredictions
from keras.models import load_model

from sklearn.metrics import roc_curve, auc

dt_p = {'max_depth': 13, 'max_features': 5, 'min_samples_leaf': 15, 'min_samples_split': 0.4}
rf_p = {'max_depth': 30, 'max_leaf_nodes': 90, 'min_samples_split': 0.05, 'n_estimators': 250}
xg_p = {'colsample_bytree': 0.8, 'gamma': 0.5, 'learning_rate': 0.4, 'max_delta_step': 1, 'max_depth': 20, 'min_child_weight': 5, 'n_estimators': 700, 'objective': 'binary:logitraw'}
ada_p =  {'learning_rate': 0.1, 'n_estimators': 1200}
gb_p = {'learning_rate': 0.7, 'max_depth': 30, 'max_leaf_nodes': 90, 'min_samples_split': 0.05, 'n_estimators': 150, 'subsample': 1}
ex_p = {'max_depth': 30, 'max_features': 10, 'min_samples_leaf': 5, 'n_estimators': 500}
knn_p = {'algorithm': 'kd_tree', 'leaf_size': 10, 'n_neighbors': 3, 'p': 1, 'weights': 'distance'}
lg_p  = {'C': 2, 'class_weight': 'balanced', 'penalty': 'l2'}
brf_p = {'max_depth': 40, 'max_features': 8, 'min_samples_leaf': 5, 'n_estimators': 500}


def do_creazy_modeling_whole(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, SEED, return_preds=False):
    dt = decisionTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =dt_p)
    rf = randomForest(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =rf_p)
    ada = adaBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =ada_p)
    gb = gradBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =gb_p)
    et = extraTrees(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =ex_p)
    nb = naiveBayes(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True)
    # rg = ridgeClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =dt_p)
    # rgf = rgfClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =dt_p)
    xg = xGBoost(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =xg_p)
    knn = KnnClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =knn_p)
    lr = logisticRegression(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =lg_p)
    brf= balancedRandomForestClassifier(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = SEED, print_score=True, params =brf_p)

    all_prediction = pd.DataFrame([dt, rf, ada, gb, et, nb, xg, knn, lr, brf, y_test ], index  = ['decisionTrees', 'randomForest', 'adaBoost', 'gradBoost', 'extraTrees', 'naiveBayes', 'xgboost', 'knn', 'logistic', 'balancedForr' ,'true_pred'])
    all_prediction2 = all_prediction.T
    #
    # all_prediction2.to_csv('input_to_NN_2.csv')

    # all_prediction2 = pd.read_csv('Input_to_NN_2.csv')

    y = all_prediction2.iloc[:, -1]
    X = all_prediction2.iloc[:, :-1]
    X_ar = X.values
    y_ar = y.values
    X_ar2 = X_ar[:, 2:]
    print(X_ar2.shape)
    #
    X_train_NN, X_test_NN, y_train_NN, y_test_NN = train_test_split(X_ar2, y_ar, test_size=0.3, random_state=0)
    model = NN_on_oredictions(X_train_NN, y_train_NN, X_test_NN, y_test_NN, print_score=True)

    # # identical to the previous one
    # model = load_model('my_model_3.h5')
    print('iamhere')
    y_pred = model.predict(X_ar2)
    for q in range(len(y_pred)):
        if y_pred[q] < 0.6:
            y_pred[q] = 0
        else:
            y_pred[q] = 1
    model_name = 'kjsdnfl'
    report_scores(y_test, y_pred, model_name)


    # fpr, tpr, threshold = roc_curve(y_test_NN, y_pred)
    # roc_auc = auc(fpr, tpr)
    # import matplotlib.pyplot as plt
    # plt.title('Receiver Operating Characteristic')
    # plt.plot(fpr, tpr, 'b', label='AUC = %0.2f' % roc_auc)
    # plt.legend(loc='lower right')
    # plt.plot([0, 1], [0, 1], 'r--')
    # plt.xlim([0, 1])
    # plt.ylim([0, 1])
    # plt.ylabel('True Positive Rate')
    # plt.xlabel('False Positive Rate')
    # plt.show()
    # model_name = 'NN'
    # report_scores(y_test, y_pred, model_name)

