import numpy as np
import pandas as pd
import random
from utils import *
from keras import backend as K
from keras import models
from keras import layers

#### This is still not working properly

# def perceptron(X_train, y_train, X_test, y_test, seed=0, print_score=False):
#
#     import numpy as np
#     import pandas as pd
import numpy as np
import pandas as pd
import random
from utils import *
from keras import backend as K
from keras import models
from keras import layers


#### This is still not working properly

# def perceptron(X_train, y_train, X_test, y_test, seed=0, print_score=False):
#
#     import numpy as np
#     import pandas as pd
#
#     class NeuralNetwork():
#         def __init__(self):
#             np.random.seed(seed)
#             self.synaptic_weights = 2 * np.random.random((12, 1)) - 1
#
#         def sigmoid(self, x):
#             return 1 / (1 + np.exp(-x))
#
#         def sigmoid_derivative(self, x):
#             return x * (1 - x)
#
#         def train(self, training_inputs, training_outputs, training_iterations):
#             for interation in range(training_iterations):
#                 output = self.think(training_inputs)
#                 error = training_outputs - output
#                 adjustment = np.dot(training_inputs.T, error * self.sigmoid_derivative(output))
#                 # self.synaptic_weights = self.synaptic_weights + adjustment
#                 self.synaptic_weights += adjustment
#
#         def think(self, inputs):
#             inputs = inputs.astype(float)
#             output = self.sigmoid(np.dot(inputs, self.synaptic_weights))
#             return output
#
#     y_train = pd.DataFrame(y_train)
#     neural_network = NeuralNetwork()
#     training_inputs = np.array([list(l) for l in X_train])
#     training_outputs = np.array(list(np.array([list(a) for a in y_train.values]).T.tolist())).T
#     neural_network.train(training_inputs, training_outputs, 100000)
#     print("Ending Weights After Training: ")
#     print(neural_network.synaptic_weights)
#
#     y_pred = []
#     for i in range(len(X_test)):
#         y_pred.append(neural_network.think(X_test[i]))
#
#     for q in range(len(y_pred)):
#         if y_pred[q] < 0.50:
#             y_pred[q] = 0
#         else:
#             y_pred[q] = 1
#
#     from sklearn.metrics import classification_report, confusion_matrix  # importing reporting methods
#
#     if print_score:
#         print('Linear Regression Model')
#         print(classification_report(y_test, y_pred))
#         cm = confusion_matrix(y_test, y_pred)  # printing the confusion matrix
#         print(cm)
#         tn, fp, fn, tp = cm.ravel()
#         sen = tp / (tp + fn)
#         acc = (tp + tn) / (tp + fn + tn + fp)
#         print('True positive  = ', tp)
#         print('False positive = ', fp)
#         print('False negative = ', fn)
#         print('True negative  = ', tn)
#         print('Sensitivity  = ', sen)
#         print('Accuracy  = ', acc)
#         print('>>>   The investment return when this model is applied is:  €{:0,.2f}'.format(
#             cm[0][0] * 0 + cm[1][1] * 8 + cm[1][0] * (-8) + cm[0][1] * (-14)).replace('€-', '-€'))
#
#     return y_pred

############### Neural Net ############################################################

def neuralNet(X_train, y_train, X_test, y_test, seed = 0, print_score=False, validate = False):
    model_name = 'Neural Net'
    from keras import models
    from keras import layers
    from keras.optimizers import Adam, RMSprop
    X_train, X_test = do_scaling(X_train, X_test)

    model = models.Sequential()
    model.add(layers.Dense(32, activation='relu', kernel_initializer='normal', input_shape=(X_train.shape[1],)))
    model.add(layers.Dropout(0.2))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(1, activation='sigmoid'))


    #     # optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    # optimizer = RMSprop()
    model.compile(optimizer='adam', loss=f1_loss, metrics=['accuracy', f1])
    model.fit(X_train, y_train, epochs=35, batch_size=64, validation_data=(X_test, y_test))

    # loss_and_metrics = model.evaluate(X_test, y_test, batch_size=1)
    # print(loss_and_metrics)
    y_pred = model.predict(X_test, batch_size=32)
    # print(y_pred)
    for q in range(len(y_pred)):
        if y_pred[q] < 0.70:
            y_pred[q] = 0
        else:
            y_pred[q] = 1

    if print_score:
        report_scores(y_test, y_pred, model_name)


    return y_pred

############### Neural Net Ensemble ############################################################

def fewNeuralNet(X_train, y_train, X_test, y_test, seed = 0, print_score=False, validate = False):
    model_name = 'Ensemble Neural Net'
    from sklearn.metrics import classification_report, confusion_matrix
    import pandas as pd

    from keras import models
    from keras import layers
    from keras.optimizers import Adam, RMSprop
    from utils import report_scores

    model = models.Sequential()
    model.add(layers.Dense(32, activation='relu', input_shape=(X_train.shape[1],)))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(1, activation='sigmoid'))
    optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    model.compile(optimizer=optimizer, loss=f1_loss, metrics=[perc__max_prof_score])
    model.fit(X_train, y_train, epochs=50, batch_size=64, validation_data=(X_test, y_test))
    y_pred = model.predict(X_test, batch_size=16)

    for q in range(len(y_pred)):
        if y_pred[q] < 0.75:
            y_pred[q] = 0
        else:
            y_pred[q] = 1


    model2 = models.Sequential()
    model2.add(layers.Dense(64, activation='relu', input_shape=(X_train.shape[1],)))
    model2.add(layers.Dropout(0.1))
    model2.add(layers.Dense(64, activation='relu'))
    model2.add(layers.Dropout(0.1))
    model2.add(layers.Dense(64, activation='relu'))
    model2.add(layers.Dropout(0.1))
    model2.add(layers.Dense(1, activation='sigmoid'))
    optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    model2.compile(optimizer=optimizer, loss=f1_loss, metrics=[perc__max_prof_score])
    model2.fit(X_train, y_train, epochs=50, batch_size=64, validation_data=(X_test, y_test))
    y_pred2 = model2.predict(X_test, batch_size=16)

    for q in range(len(y_pred2)):
        if y_pred2[q] < 0.75:
            y_pred2[q] = 0
        else:
            y_pred2[q] = 1

    model3 = models.Sequential()
    model3.add(layers.Dense(24, activation='relu', input_shape=(X_train.shape[1],)))
    model3.add(layers.Dropout(0.1))
    model3.add(layers.Dense(20, activation='relu'))
    model3.add(layers.Dropout(0.1))
    model3.add(layers.Dense(16, activation='relu'))
    model3.add(layers.Dropout(0.1))
    model3.add(layers.Dense(1, activation='sigmoid'))
    # optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    optimizer = RMSprop()
    model3.compile(optimizer=optimizer, loss=f1_loss, metrics=[perc__max_prof_score])
    model3.fit(X_train, y_train, epochs=20, batch_size=64, validation_data=(X_test, y_test))
    y_pred3 = model3.predict(X_test, batch_size=16)

    for q in range(len(y_pred3)):
        if y_pred3[q] < 0.75:
            y_pred3[q] = 0
        else:
            y_pred3[q] = 1

    df = pd.DataFrame(y_pred, columns=['y1'])
    df['y2'] = y_pred2
    df['y3'] = y_pred3

    df['sum'] = df[['y1', 'y2', 'y3']].sum(axis=1)
    level_map = {0: 0, 1: 0, 2: 1, 3: 1}
    #print(df['sum'].head())
    # df['final'] = df['sum'].apply(lambda x: 1 if x/3 >= 0.5 else 0 )
    # df['final'] = df['final'].astype('int64')
    # print(df['final'].head())
   # df['final'].astype(int)
    df['final'] = df['sum'].map(level_map)
    df['final'].astype(int)

    y_pred = df['final']
    if print_score:
        report_scores(y_test, y_pred, model_name)
    return y_pred

def build_simple(optimizer='adam'):
    from keras import models
    from keras import layers
    model = models.Sequential()
    model.add(layers.Dense(32, activation='relu', input_shape=(50,)))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(4, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(1, activation='sigmoid'))
    model.compile(optimizer = optimizer ,loss='binary_crossentropy', metrics =['accuracy'])

    return model




def build_simple_roi(optimizer='adam'):
    from keras import models
    from keras import layers
    model = models.Sequential()
    model.add(layers.Dense(32, activation='relu', input_shape=(50,)))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(4, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(1, activation='sigmoid'))
    model.compile(optimizer = optimizer ,loss=f1_loss, metrics =[roi_pc_score])

    return model



def f1(y_true, y_pred):
    def recall(y_true, y_pred):
        """Recall metric.

        Only computes a batch-wise average of recall.

        Computes the recall, a metric for multi-label classification of
        how many relevant items are selected.
        """
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
        recall = true_positives / (possible_positives + K.epsilon())
        return recall

    def precision(y_true, y_pred):
        """Precision metric.

        Only computes a batch-wise average of precision.

        Computes the precision, a metric for multi-label classification of
        how many selected items are relevant.
        """
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
        precision = true_positives / (predicted_positives + K.epsilon())
        return precision
    precision = precision(y_true, y_pred)
    recall = recall(y_true, y_pred)
    return 2*((precision*recall)/(precision+recall+K.epsilon()))

import tensorflow as tf


def f1(y_true, y_pred):
    y_pred = K.round(y_pred)
    tp = K.sum(K.cast(y_true * y_pred, 'float'), axis=0)
    tn = K.sum(K.cast((1 - y_true) * (1 - y_pred), 'float'), axis=0)
    fp = K.sum(K.cast((1 - y_true) * y_pred, 'float'), axis=0)
    fn = K.sum(K.cast(y_true * (1 - y_pred), 'float'), axis=0)

    p = tp / (tp + fp + K.epsilon())
    r = tp / (tp + fn + K.epsilon())

    f1 = 2 * p * r / (p + r + K.epsilon())
    f1 = tf.where(tf.is_nan(f1), tf.zeros_like(f1), f1)
    return K.mean(f1)


def f1_loss(y_true, y_pred):
    tp = K.sum(K.cast(y_true * y_pred, 'float'), axis=0)
    tn = K.sum(K.cast((1 - y_true) * (1 - y_pred), 'float'), axis=0)
    fp = K.sum(K.cast((1 - y_true) * y_pred, 'float'), axis=0)
    fn = K.sum(K.cast(y_true * (1 - y_pred), 'float'), axis=0)

    p = tp / (tp + fp + K.epsilon())
    r = tp / (tp + fn + K.epsilon())

    f1 = 2 * p * r / (p + r + K.epsilon())
    f1 = tf.where(tf.is_nan(f1), tf.zeros_like(f1), f1)
    return 1 - K.mean(f1)


def NN_on_oredictions(X_train, y_train, X_test, y_test, print_score=False):
    model_name = 'superUltraPredictor'
    from keras import models
    from keras import layers

    X_train, X_test = do_scaling(X_train, X_test)
    model = models.Sequential()
    model.add(layers.Dense(8, activation='relu', input_shape=(X_train.shape[1],)))
    model.add(layers.Dropout(0.126))
    model.add(layers.Dense(4, activation='relu'))
    model.add(layers.Dropout(0.1))
    # model.add(layers.Dense(16, activation='relu'))
    # model.add(layers.Dropout(0.1))
    model.add(layers.Dense(1, activation='sigmoid'))

    model.compile(optimizer='adam', loss=f1_loss, metrics=['accuracy', f1])
    # model.compile(optimizer ='adam',loss='binary_crossentropy', metrics =['f1'])
    model.fit(X_train, y_train, epochs=120, batch_size=16, validation_data=(X_test, y_test))

    y_pred = model.predict(X_test, batch_size=8)

    for q in range(len(y_pred)):
        if y_pred[q] < 0.5:
            y_pred[q] = 0
        else:
            y_pred[q] = 1

    model.save('my_model_2.h5')  # creates a HDF5 file 'my_model.h5'

    if print_score:
        report_scores(y_test, y_pred, model_name)
    return model



def roi_pc_score(y_true, y_pred):
    tp = K.sum(K.cast(y_true * y_pred, 'float'), axis=0)
    tn = K.sum(K.cast((1 - y_true) * (1 - y_pred), 'float'), axis=0)
    fp = K.sum(K.cast((1 - y_true) * y_pred, 'float'), axis=0)
    fn = K.sum(K.cast(y_true * (1 - y_pred), 'float'), axis=0)
    roi_ = tn * 0 + fp * (-3) + fn * 0 + tp * 8
    len_ = tp + tn + fn + tn
    roi_pc = roi_ / len_
    return roi_pc

def roi_pc_loss(y_true, y_pred):
    tp = K.sum(K.cast(y_true * y_pred, 'float'), axis=0)
    tn = K.sum(K.cast((1 - y_true) * (1 - y_pred), 'float'), axis=0)
    fp = K.sum(K.cast((1 - y_true) * y_pred, 'float'), axis=0)
    fn = K.sum(K.cast(y_true * (1 - y_pred), 'float'), axis=0)
    roi_ = tn * 0 + fp * (-3) + fn * 0 + tp * 8
    len_  = tp + tn + fn + tn
    roi_pc =roi_ / len_
    return 1.2 - roi_pc



def perc__max_prof_score(y_true, y_pred):
    tp = K.sum(K.cast(y_true * y_pred, 'float'), axis=0)
    tn = K.sum(K.cast((1 - y_true) * (1 - y_pred), 'float'), axis=0)
    fp = K.sum(K.cast((1 - y_true) * y_pred, 'float'), axis=0)
    fn = K.sum(K.cast(y_true * (1 - y_pred), 'float'), axis=0)
    roi_ = tn * 0 + fp * (-3) + fn * 0 + tp * 8
    perc_prof = roi_/((tp + tn)*8)
    return perc_prof

def perc__max_prof_loss(y_true, y_pred):
    tp = K.sum(K.cast(y_true * y_pred, 'float'), axis=0)
    tn = K.sum(K.cast((1 - y_true) * (1 - y_pred), 'float'), axis=0)
    fp = K.sum(K.cast((1 - y_true) * y_pred, 'float'), axis=0)
    fn = K.sum(K.cast(y_true * (1 - y_pred), 'float'), axis=0)
    roi_ = tn * 0 + fp * (-3) + fn * 0 + tp * 8
    perc_prof = roi_/((tp + tn)*8)
    return 1-perc_prof


def build_simple_percent(optimizer='adam'):
    from keras import models
    from keras import layers
    model = models.Sequential()
    model.add(layers.Dense(32, activation='relu', input_shape=(50,)))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(4, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(1, activation='sigmoid'))
    model.compile(optimizer = optimizer ,loss=perc__max_prof_loss, metrics =[perc__max_prof_score])

    return model


def model1():
    from keras import models
    from keras import layers
    from keras.optimizers import Adam, RMSprop

    model = models.Sequential()
    model.add(layers.Dense(30, activation='relu', input_shape=(50,)))
    model.add(layers.Dropout(0.2))
    model.add(layers.Dense(15, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(7, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(1, activation='sigmoid'))
    optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    model.compile(optimizer=optimizer, loss='binary_crossentropy', metrics=[f1])
    return model


def model2():
    from keras import models
    from keras import layers
    from keras.optimizers import Adam, RMSprop

    model2 = models.Sequential()
    model2.add(layers.Dense(20, activation='relu', input_shape=(50,)))
    model2.add(layers.Dropout(0.1))
    model2.add(layers.Dense(20, activation='relu'))
    model2.add(layers.Dropout(0.1))
    model2.add(layers.Dense(1, activation='sigmoid'))
    optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    model2.compile(optimizer=optimizer, loss=perc__max_prof_loss, metrics=[perc__max_prof_score])
    return model2


def model3():
    from keras import models
    from keras import layers
    from keras.optimizers import Adam, RMSprop

    model3 = models.Sequential()
    model3.add(layers.Dense(40, activation='relu', input_shape=(50,)))
    model3.add(layers.Dropout(0.2))
    model3.add(layers.Dense(20, activation='relu'))
    model3.add(layers.Dropout(0.2))
    model3.add(layers.Dense(10, activation='relu'))
    model3.add(layers.Dropout(0.2))
    model3.add(layers.Dense(1, activation='sigmoid'))
    # optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    optimizer = RMSprop()
    model3.compile(optimizer=optimizer, loss=perc__max_prof_loss, metrics=[perc__max_prof_score])

    return model3




def fewNeuralNet_unseen(X_train, y_train, X_test, seed = 0, print_score=False, validate = False):
    model_name = 'Ensemble Neural Net'
    from sklearn.metrics import classification_report, confusion_matrix
    import pandas as pd

    from keras import models
    from keras import layers
    from keras.optimizers import Adam, RMSprop
    from utils import report_scores

    model = models.Sequential()
    model.add(layers.Dense(32, activation='relu', input_shape=(X_train.shape[1],)))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(16, activation='relu'))
    model.add(layers.Dropout(0.1))
    model.add(layers.Dense(1, activation='sigmoid'))
    optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    model.compile(optimizer=optimizer, loss=f1_loss, metrics=[perc__max_prof_score])
    model.fit(X_train, y_train, epochs=50, batch_size=64)
    y_pred = model.predict(X_test, batch_size=16)

    for q in range(len(y_pred)):
        if y_pred[q] < 0.75:
            y_pred[q] = 0
        else:
            y_pred[q] = 1


    model2 = models.Sequential()
    model2.add(layers.Dense(64, activation='relu', input_shape=(X_train.shape[1],)))
    model2.add(layers.Dropout(0.1))
    model2.add(layers.Dense(64, activation='relu'))
    model2.add(layers.Dropout(0.1))
    model2.add(layers.Dense(64, activation='relu'))
    model2.add(layers.Dropout(0.1))
    model2.add(layers.Dense(1, activation='sigmoid'))
    optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    model2.compile(optimizer=optimizer, loss=f1_loss, metrics=[perc__max_prof_score])
    model2.fit(X_train, y_train, epochs=50, batch_size=64)
    y_pred2 = model2.predict(X_test, batch_size=16)

    for q in range(len(y_pred2)):
        if y_pred2[q] < 0.75:
            y_pred2[q] = 0
        else:
            y_pred2[q] = 1

    model3 = models.Sequential()
    model3.add(layers.Dense(24, activation='relu', input_shape=(X_train.shape[1],)))
    model3.add(layers.Dropout(0.1))
    model3.add(layers.Dense(20, activation='relu'))
    model3.add(layers.Dropout(0.1))
    model3.add(layers.Dense(16, activation='relu'))
    model3.add(layers.Dropout(0.1))
    model3.add(layers.Dense(1, activation='sigmoid'))
    # optimizer = Adam(lr=0.002, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.0, amsgrad=False)
    optimizer = RMSprop()
    model3.compile(optimizer=optimizer, loss=f1_loss, metrics=[perc__max_prof_score])
    model3.fit(X_train, y_train, epochs=20, batch_size=64)
    y_pred3 = model3.predict(X_test, batch_size=16)

    for q in range(len(y_pred3)):
        if y_pred3[q] < 0.75:
            y_pred3[q] = 0
        else:
            y_pred3[q] = 1

    df = pd.DataFrame(y_pred, columns=['y1'])
    df['y2'] = y_pred2
    df['y3'] = y_pred3

    df['sum'] = df[['y1', 'y2', 'y3']].sum(axis=1)
    level_map = {0: 0, 1: 0, 2: 1, 3: 1}
    #print(df['sum'].head())
    # df['final'] = df['sum'].apply(lambda x: 1 if x/3 >= 0.5 else 0 )
    # df['final'] = df['final'].astype('int64')
    # print(df['final'].head())
   # df['final'].astype(int)
    df['final'] = df['sum'].map(level_map)
    df['final'].astype(int)

    y_pred = df['final']
    # if print_score:
    #     report_scores(y_test, y_pred, model_name)
    return y_pred




