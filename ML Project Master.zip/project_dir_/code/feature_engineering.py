
import sys
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import KBinsDiscretizer
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.decomposition import PCA
from utils import pddf
from kmodes.kmodes import KModes


class FeatureEngineer:
    def __init__(self, training, unseen):
        self._rank = {}
        self.training = training
        self.unseen = unseen

        self.has_child()
        self._merge_marital()
        self.edu_phd()
        self.edu_basic()
        self.family_status()
        #self._generate_dummies()
        #self.scale_variables(MinMaxScaler)

    def scale_variables(self, method):#works
        if method == 'Standard':
            scaler = StandardScaler()
        else:
            scaler = MinMaxScaler()

        columns = [ 'Income', 'Dt_Customer', 'Recency', 'MntWines', 'MntFruits',
       'MntMeatProducts', 'MntFishProducts', 'MntSweetProducts',
       'MntGoldProds', 'NumDealsPurchases', 'NumWebPurchases',
       'NumCatalogPurchases', 'NumStorePurchases', 'NumWebVisitsMonth','Age']

        self.training[columns] = scaler.fit_transform(self.training[columns])
        self.unseen[columns] = scaler.fit_transform(self.unseen[columns])


    def response_rate(self):#works
        '''rate of response from the previous campains'''
        for i in [self.training, self.unseen]:
            i['response_rate'] = (i['AcceptedCmp1'].astype(int) +
                                             i['AcceptedCmp2'].astype(int) +
                                             i['AcceptedCmp3'].astype(int) +
                                             i['AcceptedCmp4'].astype(int) +
                                             i['AcceptedCmp5'].astype(int))/5

    def total_responses(self):#works
        '''all responses from the previous campains'''
        for i in [self.training, self.unseen]:
            i['total_response '] = (i['AcceptedCmp1'].astype(int) +
                                             i['AcceptedCmp2'].astype(int) +
                                             i['AcceptedCmp3'].astype(int) +
                                             i['AcceptedCmp4'].astype(int) +
                                             i['AcceptedCmp5'].astype(int))

    def ever_accepted(self): # works
        ''' binary has a child'''
        for index, row in self.unseen.iterrows():
            if row['response_rate'] > 0:
                self.unseen.loc[index, 'ever_accep'] = 1
            else:
                self.unseen.loc[index, 'ever_accep'] = 0

        for index, row in self.training.iterrows():
            if row['response_rate'] > 0:
                self.training.loc[index, 'ever_accep'] = 1
            else:
                self.training.loc[index, 'ever_accep'] = 0

    def has_child(self):#works
        ''' binary has a child'''
        for index, row in self.unseen.iterrows():
            if row['Kidhome'] >= 1 or row['Teenhome'] >= 1:
                self.unseen.loc[index, 'Child_home'] = 1
            else:
                self.unseen.loc[index, 'Child_home'] = 0


        for index, row in self.training.iterrows():
            if row['Kidhome'] >= 1 or row['Teenhome'] >= 1:
                self.training.loc[index, 'Child_home'] = 1
            else:
                self.training.loc[index, 'Child_home'] = 0

    def count_children(self):
        ''' amount of children'''
        self.unseen['TotalChildren'] = self.unseen['Kidhome'] + self.unseen['Teenhome']
        self.training['TotalChildren'] = self.training['Kidhome'] + self.training['Teenhome']

    def family_status(self):#needs to check
        '''the type of family single kid singe not kid together no kid and together kid as dummies'''
        for index, row in self.unseen.iterrows():
            if row['Child_home'] == 1 and row['Marital_Status'] == 0:
                self.unseen.loc[index, 'Fam_kids'] = 1

            else:
                self.unseen.loc[index, 'Fam_kids'] = 0

            if row['Child_home'] == 1 and row['Marital_Status'] == 1:
                self.unseen.loc[index, 'Alone_kids'] = 1

            else:
                self.unseen.loc[index, 'Alone_kids'] = 0

        for index, row in self.training.iterrows():

            if row['Child_home'] == 1 and row['Marital_Status'] == 0:
                self.training.loc[index, 'Fam_kids'] = 1

            else:
                self.training.loc[index, 'Fam_kids'] = 0

            if row['Child_home'] == 1 and row['Marital_Status'] == 1:
                self.training.loc[index, 'Alone_kids'] = 1

            else:
                self.training.loc[index, 'Alone_kids'] = 0

    def edu_phd(self):#works
        ''' indicates if a customer has a phd education as significatnly higher dicriminability'''
        for index, row in self.unseen.iterrows():

            if row['Education'] in ['PhD']:
                self.unseen.loc[index, 'PhD'] = 1

            else:
                self.unseen.loc[index, 'PhD'] = 0

        for index, row in self.training.iterrows():

            if row['Education'] in ['PhD']:
                self.training.loc[index, 'PhD'] = 1

            else:
                self.training.loc[index, 'PhD'] = 0

    def edu_basic(self):#works
        ''' indicates if a customer has a basic education or not as significatnly higher discriminability here the
        other are left out as no value added  '''
        for index, row in self.unseen.iterrows():

            if row['Education'] in ['Basic']:
                self.unseen.loc[index, 'Basic'] = 1

            else:
                self.unseen.loc[index, 'Basic'] = 0

        for index, row in self.training.iterrows():

            if row['Education'] in ['Basic']:
                self.training.loc[index, 'Basic'] = 1

            else:
                self.training.loc[index, 'Basic'] = 0



    def avg_no_store_per_month(self):#works
        '''Avenge number of web purchases per month'''
        self.training['avg_no_store_per_month'] = self.training['NumStorePurchases'] / (self.training['Dt_Customer'] / 30)
        self.unseen['avg_no_store_per_month'] = self.unseen['NumStorePurchases'] / (self.unseen['Dt_Customer'] / 30)

    def avg_no_cat_per_month(self):#works
        '''Avenge number of catalogue purchases per month'''
        self.training['avg_no_cat_per_month'] = self.training['NumCatalogPurchases'] / (self.training['Dt_Customer'] / 30)
        self.unseen['avg_no_cat_per_month'] = self.unseen['NumCatalogPurchases'] / (self.unseen['Dt_Customer'] / 30)

    def avg_pur_per_month(self):#works
        '''Avenge number of total purchases per month'''
        self.training['avg_pur_per_month'] = self.training['total_pur']  / (self.training['Dt_Customer'] / 30)
        self.unseen['avg_pur_per_month'] = self.unseen['total_pur']  / (self.unseen['Dt_Customer'] / 30)

    def avg_no_web_per_month(self):#works
        '''Avenge number of web purchases per month'''
        self.training['avg_no_web_per_month'] = self.training['NumWebPurchases'] / (self.training['Dt_Customer'] / 30)
        self.unseen['avg_no_web_per_month'] = self.unseen['NumWebPurchases'] / (self.unseen['Dt_Customer'] / 30)

    def web_conversion(self):#works
        ''' indicates if a customer has a basic education or not as significatnly higher discriminability here the
        other are left out as no value added  '''
        for index, row in self.unseen.iterrows():

            if row['NumWebVisitsMonth'] == 0:
                self.unseen.loc[index, 'Web_conversion'] = 0

            else:
                self.unseen.loc[index, 'Web_conversion'] = row['NumWebPurchases'] / (row['Dt_Customer'] / 30) / row['NumWebVisitsMonth']

        for index, row in self.training.iterrows():

            if row['NumWebVisitsMonth'] == 0:
                self.training.loc[index, 'Web_conversion'] = 0

            else:
                self.training.loc[index, 'Web_conversion'] = row['NumWebPurchases'] / (row['Dt_Customer'] / 30) / row[
                    'NumWebVisitsMonth']

    def percen_catalogue(self):
        '''percentage of catalogue purchases of all purchases'''
        self.training['percen_catalogue'] = self.training['NumCatalogPurchases'] / self.training['total_pur']

        for index, row in self.unseen.iterrows():

            if (row['total_pur'] == 0) & (row['mnt_total'] > 0):
                self.unseen.loc[index, 'percen_catalogue'] = 0

            else:
                self.unseen.loc[index, 'percen_catalogue'] = row['NumCatalogPurchases'] / row['total_pur']


    def percen_web(self):
        '''percentage of web purchases of all purchases'''
        self.training['percen_web'] = self.training['NumWebPurchases'] / self.training['total_pur']

        for index, row in self.unseen.iterrows():

            if (row['total_pur'] == 0) & (row['mnt_total'] > 0):
                self.unseen.loc[index, 'percen_web'] = 0

            else:
                self.unseen.loc[index, 'percen_web'] = row['NumWebPurchases'] / row['total_pur']

    def percen_store(self):
        '''percentage of store purchases of all purchases'''
        self.training['percen_store'] = self.training['NumStorePurchases'] / self.training['total_pur']

        for index, row in self.unseen.iterrows():

            if (row['total_pur'] == 0) & (row['mnt_total'] > 0):
                self.unseen.loc[index, 'percen_store'] = 0

            else:
                self.unseen.loc[index, 'percen_store'] = row['NumStorePurchases'] / row['total_pur']

    def percen_deals(self):
        '''percentage of deals purchases of all purchases'''
        self.training['percen_deals'] = self.training['NumDealsPurchases'] / self.training['total_pur']

        for index, row in self.unseen.iterrows():

            if (row['total_pur'] == 0) & (row['mnt_total'] > 0):
                self.unseen.loc[index, 'percen_deals'] = 0

            else:
                self.unseen.loc[index, 'percen_deals'] = row['NumDealsPurchases'] / row['total_pur']

    def percen_wine(self):#works
        '''percentage of wine purchases of all purchases'''
        self.training['percen_wine'] = self.training['MntWines'] / self.training['mnt_total']
        self.unseen['percen_wine'] = self.unseen['MntWines'] / self.unseen['mnt_total']

    def percen_fruit(self):#works
        '''percentage of fruit purchases of all purchases'''
        self.training['percen_fruit'] = self.training['MntFruits'] / self.training['mnt_total']
        self.unseen['percen_fruit'] = self.unseen['MntFruits'] / self.unseen['mnt_total']

    def percen_meat(self):#works
        '''percentage of meat purchases of all purchases'''
        self.training['percen_meat'] = self.training['MntMeatProducts'] / self.training['mnt_total']
        self.unseen['percen_meat'] = self.unseen['MntMeatProducts'] / self.unseen['mnt_total']

    def percen_fish(self):#works
        '''percentage of fish purchases of all purchases'''
        self.training['percen_fish'] = self.training['MntFishProducts'] / self.training['mnt_total']
        self.unseen['percen_fish'] = self.unseen['MntFishProducts'] / self.unseen['mnt_total']

    def percen_sweet(self):#works
        '''percentage of sweet purchases of all purchases'''
        self.training['percen_sweet'] = self.training['MntSweetProducts'] / self.training['mnt_total']
        self.unseen['percen_sweet'] = self.unseen['MntSweetProducts'] / self.unseen['mnt_total']

    def percen_gold(self):#works
        '''percentage of gold purchases of all purchases'''
        self.training['percen_gold'] = self.training['MntGoldProds'] / self.training['mnt_total']
        self.unseen['percen_gold'] = self.unseen['MntGoldProds'] / self.unseen['mnt_total']

    def income_num_pur(self):
        '''total items purchased divided by income'''
        self.training['income_num_pur'] = self.training['total_pur'] / self.training['Income']
        self.unseen['income_num_pur'] = self.unseen['total_pur'] / self.unseen['Income']

    def spent_income(self):
        '''percentage of income spent in the store'''
        self.training['spent_income'] = (self.training['mnt_total'] /2) / self.training['Income']
        self.unseen['spent_income'] = (self.unseen['mnt_total'] /2) / self.unseen['Income']

    def spent_vs_gold(self):#works
        ''' indicates the relation ship of spent income and percent of money spent on gold products  '''
        for index, row in self.unseen.iterrows():

            if row['percen_gold'] == 0:
                self.unseen.loc[index, 'spent_vs_gold'] = 0

            else:
                self.unseen.loc[index, 'spent_vs_gold'] = row['spent_income'] / row['percen_gold']

        for index, row in self.training.iterrows():

            if row['percen_gold'] == 0:
                self.training.loc[index, 'spent_vs_gold'] = 0

            else:
                self.training.loc[index, 'spent_vs_gold'] = row['spent_income'] / row['percen_gold']

    def _extract_business_features(self):#illya
        self.dict_bt = {"BT_MntIncome": lambda df: df["Mnt"].divide(df["Income"], fill_value=0).multiply(100),
                        "BT_MntFrq": lambda df: df["Mnt"].divide(df["Frq"], fill_value=0).multiply(100)}

        for key, value in self.dict_bt.items():
            self.training[key] = value(self.training)
            self.unseen[key] = value(self.unseen)

    def _merge_marital(self):
        self.dict_merge_cat = {"Marital_Status": lambda x: 1 if x in ["Widow", 'Alone', 'Single', 'Divorced'] else 0}

        for key, value in self.dict_merge_cat.items():
            self.training[key] = self.training[key].apply(value)
            self.unseen[key] = self.unseen[key].apply(value)

     # def _generate_dummies(self):
     #     self.unseen = pd.get_dummies(self.unseen, drop_first=True, columns=['Marital_Status', 'Education'])
     #     self.training = pd.get_dummies(self.training, drop_first=True, columns=['Marital_Status', 'Education'])

    def box_cox_transformations(self, num_features, target):
        # 1) perform feature scaling, using MinMaxScaler from sklearn
        bx_cx_scaler = MinMaxScaler(feature_range=(0, 1), copy=False)
        X_tr_01 = bx_cx_scaler.fit_transform(self.training[num_features].values)
        X_un_01 = bx_cx_scaler.transform(self.unseen[num_features].values)
        num_features_BxCx = ["BxCxT_" + s for s in num_features]
        self.training = pd.concat([self.training.loc[:, self.training.columns != target],
                                   pd.DataFrame(X_tr_01, index=self.training.index, columns=num_features_BxCx),
                                   self.training[target]], axis=1)
        self.unseen = pd.concat([self.unseen.loc[:, self.unseen.columns != target],
                                   pd.DataFrame(X_un_01, index=self.unseen.index, columns=num_features_BxCx),
                                   self.unseen[target]], axis=1)
        # 2) define a set of transformations
        self._bx_cx_trans_dict = {"x": lambda x: x, "log": np.log, "sqrt": np.sqrt,
                      "exp": np.exp, "**1/4": lambda x: np.power(x, 0.25),
                      "**2": lambda x: np.power(x, 2), "**4": lambda x: np.power(x, 4)}
        # 3) perform power transformations on scaled features and select the best
        self.best_bx_cx_dict = {}
        for feature in num_features_BxCx:
            best_test_value, best_trans_label, best_power_trans = 0, "", None
            for trans_key, trans_value in self._bx_cx_trans_dict.items():
                # 3) 1) 1) apply transformation on training data
                feature_trans = np.round(trans_value(self.training[feature]), 4)
                if trans_key == "log":
                    feature_trans.loc[np.isfinite(feature_trans) == False] = -50
                # 3) 1) 2) bin transformed feature (required to perform Chi-Squared test)
                bindisc = KBinsDiscretizer(n_bins=10, encode="ordinal", strategy="uniform")
                feature_bin = bindisc.fit_transform(feature_trans.values.reshape(-1, 1))
                feature_bin = pd.Series(feature_bin[:, 0], index=self.training.index)
                # 3) 1) 3) obtain contingency table
                cont_tab = pd.crosstab(feature_bin, self.training[target], margins=False)
                # 3) 1) 4) compute Chi-Squared test
                chi_test_value = stats.chi2_contingency(cont_tab)[0]
                # 3) 1) 5) choose the best so far Box-Cox transformation based on Chi-Squared test
                if chi_test_value > best_test_value:
                    best_test_value, best_trans_label, best_power_trans = chi_test_value, trans_key, feature_trans
            self.best_bx_cx_dict[feature] = (best_trans_label, best_power_trans)
            # 3) 2) append transformed feature to the data frame
            self.training[feature] = best_power_trans
            # 3) 3) apply the best Box-Cox transformation, determined on training data, on unseen data
            self.unseen[feature] = np.round(self._bx_cx_trans_dict[best_trans_label](self.unseen[feature]), 4)
        self.box_cox_features = num_features_BxCx

    def rank_features_chi_square(self, continuous_flist, categorical_flist):
        chisq_dict = {}
        if continuous_flist:
            bindisc = KBinsDiscretizer(n_bins=10, encode='ordinal', strategy="uniform")
            for feature in continuous_flist:
                feature_bin = bindisc.fit_transform(self.training[feature].values[:, np.newaxis])
                feature_bin = pd.Series(feature_bin[:, 0], index=self.training.index)
                cont_tab = pd.crosstab(feature_bin, self.training["DepVar"], margins=False)
                chisq_dict[feature] = stats.chi2_contingency(cont_tab.values)[0:2]
        if categorical_flist:
            for feature in categorical_flist:
                cont_tab = pd.crosstab(self.training[feature], self.training["DepVar"], margins=False)
                chisq_dict[feature] = stats.chi2_contingency(cont_tab.values)[0:2]

        df_chisq_rank = pd.DataFrame(chisq_dict, index=["Chi-Squared", "p-value"]).transpose()
        df_chisq_rank.sort_values("Chi-Squared", ascending=False, inplace=True)
        df_chisq_rank["valid"] = df_chisq_rank["p-value"] <= 0.05
        self._rank["chisq"] = df_chisq_rank

    def print_top(self, n):
        print(self._rank.index[0:8])

    def get_top(self, criteria="chisq", n_top=10):
        input_features = list(self._rank[criteria].index[0:n_top])
        input_features.append("Response")
        return self.training[input_features], self.unseen[input_features]

    # expectation: will boost performance of models as it tries to maximize class seperability eventhough data is not \
    # perfectly normal distributed, only taking the lda instead of the original data
    def lda_80(self,  columns, variation=.8): # works
        # which variables to select?
        # too complicated to use ...

        y_train = self.training['Response'].copy()
        x_train = self.training[columns].copy()
        x_unseen = self.unseen[columns].copy()

        scaler = MinMaxScaler(feature_range=(0, 1), copy=False)

        fitted_scaler = scaler.fit(x_train)
        x_train = fitted_scaler.transform(x_train)
        x_unseen = fitted_scaler.transform(x_unseen)

        _lda = LinearDiscriminantAnalysis(n_components=None)
        _lda.fit(x_train, y_train)
        self._var_ratios = _lda.explained_variance_ratio_

        n_components = self._select_n_components(variation)

        lda = LinearDiscriminantAnalysis(n_components=n_components)
        fitted_LDA = lda.fit(x_train, y_train)

        x_train_lda = fitted_LDA.transform(x_train)
        x_unseen_lda = fitted_LDA.transform(x_unseen)

        lds = []
        n = 1
        for i in range(n_components):
            lds.append("LD" + str(n))
            n += 1

        x_train_lda = pddf(x_train_lda, columns=lds)
        x_unseen_lda = pddf(x_unseen_lda, columns=lds)

        self.training = pd.concat([self.training.copy().reset_index(drop=True), x_train_lda.reset_index(drop=True)], axis=1)
        self.unseen = pd.concat([self.unseen.copy().reset_index(drop=True), x_unseen_lda.reset_index(drop=True)], axis=1)

    def _select_n_components(self, variation): # pareto principle of 80%
        total_variance = 0.0
        n_components = 0

        for explained_variance in self._var_ratios:
            total_variance += explained_variance
            n_components += 1
            if total_variance >= variation:
                break

        return n_components



    # expectations: will improve models due to less dimensions will be worse than LDA because it does not take the \
    # label into account; only taking the pcas instead of the original data (only for cont data types we need to filter)

    def pca_80(self, columns, variation=.8): # works

        x_train = self.training[columns].copy()
        x_unseen = self.unseen[columns].copy()

        scaler = MinMaxScaler(feature_range=(0, 1), copy=False)

        fitted_scaler = scaler.fit(x_train)
        x_train = fitted_scaler.transform(x_train)
        x_unseen = fitted_scaler.transform(x_unseen)

        _pca = PCA(n_components=None)
        _pca.fit(x_train)
        self._var_ratios = _pca.explained_variance_ratio_

        n_components = self._select_n_components(variation)

        pca = PCA(n_components=n_components)
        fitted_pca = pca.fit(x_train)

        x_train_pca = fitted_pca.transform(x_train)
        x_test_pca = fitted_pca.transform(x_unseen)

        pcs = []
        n = 1
        for i in range(n_components):
            pcs.append("PC" + str(n))
            n += 1

        x_train_pca = pddf(x_train_pca, columns=pcs)
        x_test_pca = pddf(x_test_pca, columns=pcs)


        self.training = pd.concat([self.training.copy().reset_index(drop=True), x_train_pca.reset_index(drop=True)], axis=1)
        self.unseen = pd.concat([self.unseen.copy().reset_index(drop=True), x_test_pca.reset_index(drop=True)], axis=1)



    def cluster_cat(self, columns):
        '''creates optimal number of clusters for cat data for k modes clustering on cat data'''
        x_train = self.training.copy()[columns]
        x_unseen = self.unseen.copy()[columns]

        n_cluster =[1,2,3,4,5]

        best_test_value, best_n_clust = 0, None
        # using chisq to determine the optimal number of centroids

        for n_c in n_cluster:

            km = KModes(n_clusters=n_c, init='Huang', n_init=10)

            fitted_km = km.fit(x_train)
            labels_train = pddf(fitted_km.predict(x_train), columns=['Kmode'], index=x_train.index)

            response = pddf(self.training['Response'], columns=['Response'], index=x_train.index)
            to_crosstab = pd.concat([response,labels_train], axis=1)
            cont_tab_2 = pd.crosstab(to_crosstab['Kmode'], to_crosstab['Response'], margins=False)
            chi_test_value = stats.chi2_contingency(cont_tab_2)[0]

            if chi_test_value > best_test_value:
                best_test_value, best_n_clust = chi_test_value, n_c

        km = KModes(n_clusters=best_n_clust, init='Huang', n_init=10)
        fitted_km = km.fit(x_train)

        lables_train = pddf(fitted_km.predict(x_train), columns=['Kmode'])
        lables_unseen = pddf(fitted_km.predict(x_unseen), columns=['Kmode'])

        self.training = pd.concat([self.training.copy().reset_index(drop=True), lables_train.reset_index(drop=True)], axis=1)
        self.unseen = pd.concat([self.unseen.copy().reset_index(drop=True), lables_unseen.reset_index(drop=True)], axis=1)









    #def gen_cluster_lables(self, x_train, x_test): # adding cluster lables
    #'''Generates lables for sociodemographic and lable for firmographic data '''
    # label for sociodemographic data with k Prototype


    # generate cluster labels only if label are able to discretize the data regarding the dependent variable

    # label for firmographic with EM clustering



# import sys
# import numpy as np
# import pandas as pd
# from scipy import stats
# from sklearn.preprocessing import MinMaxScaler
# from sklearn.preprocessing import OneHotEncoder
# from sklearn.preprocessing import KBinsDiscretizer
#
#
# class FeatureEngineer:
#     def __init__(self, training, unseen):
#         self._rank = {}
#         self.training = training
#         self.unseen = unseen
#
#         # self._extract_business_features()
#         # self._merge_categories()
#         # self._generate_dummies()
#
#     def _extract_business_features(self):
#         self.dict_bt = {"BT_MntIncome": lambda df: df["Mnt"].divide(df["Income"], fill_value=0).multiply(100),
#                         "BT_MntFrq": lambda df: df["Mnt"].divide(df["Frq"], fill_value=0).multiply(100)}
#
#         for key, value in self.dict_bt.items():
#             self.training[key] = value(self.training)
#             self.unseen[key] = value(self.unseen)
#
#     def _merge_categories(self):
#         self.dict_merge_cat = {"Marital_Status": lambda x: 2 if x == "Widow" else (1 if x == "Divorced" else 0),
#                         "Education": lambda x: 1 if x == "Master" else 0,
#                         "Recomendation": lambda x: 2 if x == 6 else (1 if x == 5 else 0)}
#
#         for key, value in self.dict_merge_cat.items():
#             self.training["MC_"+key] = self.training[key].apply(value).astype('category')
#             self.unseen["MC_" + key] = self.unseen[key].apply(value).astype('category')
#
#     def _generate_dummies(self):
#         features_to_enconde = ['MC_Marital_Status', 'MC_Education', 'MC_Recomendation']
#         columns = ["DT_MS_Divorced", "DT_MS_Widow", "DT_E_Master", "DT_R_5", "DT_R_6"]
#         idxs = [1, 2, 4, 6, 7]
#         # encode categorical features from training data as a one-hot numeric array.
#         enc = OneHotEncoder(handle_unknown='ignore')
#         Xtr_enc = enc.fit_transform(self.training[features_to_enconde]).toarray()
#         # update training data
#         df_temp = pd.DataFrame(Xtr_enc[:, idxs], index=self.training.index, columns=columns)
#         self.training = pd.concat([self.training, df_temp], axis=1)
#         for c in columns:
#             self.training[c] = self.training[c].astype('category')
#         # use the same encoder to transform unseen data
#         Xun_enc = enc.transform(self.unseen[features_to_enconde]).toarray()
#         # update unseen data
#         df_temp = pd.DataFrame(Xun_enc[:, idxs], index=self.unseen.index, columns=columns)
#         self.unseen = pd.concat([self.unseen, df_temp], axis=1)
#         for c in columns:
#             self.unseen[c] = self.unseen[c].astype('category')
#
#     def box_cox_transformations(self, num_features, target):
#         # 1) perform feature scaling, using MinMaxScaler from sklearn
#         bx_cx_scaler = MinMaxScaler(feature_range=(0, 1), copy=False)
#         X_tr_01 = bx_cx_scaler.fit_transform(self.training[num_features].values)
#         X_un_01 = bx_cx_scaler.transform(self.unseen[num_features].values)
#         num_features_BxCx = ["BxCxT_" + s for s in num_features]
#         self.training = pd.concat([self.training.loc[:, self.training.columns != target],
#                                    pd.DataFrame(X_tr_01, index=self.training.index, columns=num_features_BxCx),
#                                    self.training[target]], axis=1)
#         self.unseen = pd.concat([self.unseen.loc[:, self.unseen.columns != target],
#                                    pd.DataFrame(X_un_01, index=self.unseen.index, columns=num_features_BxCx),
#                                    self.unseen[target]], axis=1)
#         # 2) define a set of transformations
#         self._bx_cx_trans_dict = {"x": lambda x: x, "log": np.log, "sqrt": np.sqrt,
#                       "exp": np.exp, "**1/4": lambda x: np.power(x, 0.25),
#                       "**2": lambda x: np.power(x, 2), "**4": lambda x: np.power(x, 4)}
#         # 3) perform power transformations on scaled features and select the best
#         self.best_bx_cx_dict = {}
#         for feature in num_features_BxCx:
#             best_test_value, best_trans_label, best_power_trans = 0, "", None
#             for trans_key, trans_value in self._bx_cx_trans_dict.items():
#                 # 3) 1) 1) apply transformation on training data
#                 feature_trans = np.round(trans_value(self.training[feature]), 4)
#                 if trans_key == "log":
#                     feature_trans.loc[np.isfinite(feature_trans) == False] = -50
#                 # 3) 1) 2) bin transformed feature (required to perform Chi-Squared test)
#                 bindisc = KBinsDiscretizer(n_bins=10, encode="ordinal", strategy="uniform")
#                 feature_bin = bindisc.fit_transform(feature_trans.values.reshape(-1, 1))
#                 feature_bin = pd.Series(feature_bin[:, 0], index=self.training.index)
#                 # 3) 1) 3) obtain contingency table
#                 cont_tab = pd.crosstab(feature_bin, self.training[target], margins=False)
#                 # 3) 1) 4) compute Chi-Squared test
#                 chi_test_value = stats.chi2_contingency(cont_tab)[0]
#                 # 3) 1) 5) choose the best so far Box-Cox transformation based on Chi-Squared test
#                 if chi_test_value > best_test_value:
#                     best_test_value, best_trans_label, best_power_trans = chi_test_value, trans_key, feature_trans
#             self.best_bx_cx_dict[feature] = (best_trans_label, best_power_trans)
#             # 3) 2) append transformed feature to the data frame
#             self.training[feature] = best_power_trans
#             # 3) 3) apply the best Box-Cox transformation, determined on training data, on unseen data
#             self.unseen[feature] = np.round(self._bx_cx_trans_dict[best_trans_label](self.unseen[feature]), 4)
#         self.box_cox_features = num_features_BxCx
#
#     def rank_features_chi_square(self, continuous_flist, categorical_flist):
#         chisq_dict = {}
#         if continuous_flist:
#             bindisc = KBinsDiscretizer(n_bins=10, encode='ordinal', strategy="uniform")
#             for feature in continuous_flist:
#                 feature_bin = bindisc.fit_transform(self.training[feature].values[:, np.newaxis])
#                 feature_bin = pd.Series(feature_bin[:, 0], index=self.training.index)
#                 cont_tab = pd.crosstab(feature_bin, self.training["DepVar"], margins=False)
#                 chisq_dict[feature] = stats.chi2_contingency(cont_tab.values)[0:2]
#         if categorical_flist:
#             for feature in categorical_flist:
#                 cont_tab = pd.crosstab(self.training[feature], self.training["DepVar"], margins=False)
#                 chisq_dict[feature] = stats.chi2_contingency(cont_tab.values)[0:2]
#
#         df_chisq_rank = pd.DataFrame(chisq_dict, index=["Chi-Squared", "p-value"]).transpose()
#         df_chisq_rank.sort_values("Chi-Squared", ascending=False, inplace=True)
#         df_chisq_rank["valid"] = df_chisq_rank["p-value"] <= 0.05
#         self._rank["chisq"] = df_chisq_rank
#
#     def print_top(self, n):
#         print(self._rank.index[0:8])
#
#     def get_top(self, criteria="chisq", n_top=10):
#         input_features = list(self._rank[criteria].index[0:n_top])
#         input_features.append("Response")
#         return self.training[input_features], self.unseen[input_features]