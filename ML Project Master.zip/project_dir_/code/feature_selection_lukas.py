
import sys
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from data_loader import Dataset
from data_preprocessing import Processor
from feature_engineering import FeatureEngineer
from single_model import *
from utils import *
from model import *
from sklearn.svm import SVC
import xgboost
from xgboost import XGBClassifier

from CIFO_COPYPASTED import RandomSearch, HillClimbing
from model import grid_search_MLP, assess_generalization_auprc
from CIFO_MODIFIED import *
from tunning.parameter_tuning import tuning_forest_params
from neural_net import *
from feature_selection import *
from ensemble_modeling import *
from MLens import *
SEED = 2

def main():
    #+++++++++++++++++ 1) load and prepare the data
    file_path = r"../ml_project1_data.xlsx"
    ds = Dataset(file_path)

    feature_sel = {}

    #+++++++++++++++++ 2) split into train and unseen
    for seed in [0,1,2,3,4]:
        DF_train, DF_unseen = train_test_split(ds.rm_df.copy(), test_size=0.2, stratify=ds.rm_df["Response"], random_state=seed)


        #+++++++++++++++++ 3) preprocess, based on train
        pr = Processor(DF_train, DF_unseen)

        #+++++++++++++++++ 4) feature engineering
        fe = FeatureEngineer(pr.training, pr.unseen)
        do_feature_engineering(fe)

        #+++++++++++++++++ X, y split
        y_test = fe.unseen['Response']
        y_train = fe.training['Response']
        y_train_validate = y_train.copy()
        X_test = fe.unseen.loc[:, fe.unseen.columns != 'Response']
        X_train = fe.training.loc[:, fe.training.columns != 'Response']
        X_train_validate = X_train.copy()
        X_train, y_train = pr.add_syntetic_data_SMOT(X_train, y_train, ratio=0.3)

        X_test.sort_index(axis=1, inplace=True)
        X_train.sort_index(axis=1, inplace=True)

        X_train_validate.sort_index(axis=1, inplace=True)


        rfc_lst = []

        for i in range(1, 51, 1):

            rfc = randomForest(X_train, y_train, X_test, y_test, X_train_validate, y_train_validate, seed = 0, print_score=True, validate = True, feature_importance=False, select_features=i)
            rfc.append(str(i))
            rfc_lst.append(rfc)

        feature_sel[seed] = rfc_lst

    dlist = [[key] + i for key, value in feature_sel.items() for i in value]
    beta = pd.DataFrame(dlist, columns=['seed', 'test_accuracy', 'test_precision_macro', 'test_recall_macro',
                                        'test_f1_weighted', 'test_roc_auc', 'normalized_profit', 'n_features'])

    beta.to_excel("n_features.xlsx")

if __name__ == "__main__":
    main()