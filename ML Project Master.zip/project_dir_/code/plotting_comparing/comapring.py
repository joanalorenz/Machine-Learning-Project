#### ML PROJECT
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import precision_recall_fscore_support
from sklearn.metrics import mean_squared_error as mse
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_validate
from sklearn.model_selection import train_test_split
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.svm import LinearSVC
from sklearn.ensemble import VotingClassifier
from sklearn.feature_selection import RFECV

# 1 model model summary




# correlation


correlation = initial_data.corr()

mask = np.zeros_like(correlation, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

f, ax = plt.subplots(figsize=(20, 20))

cmap = sns.diverging_palette(180, 20, as_cmap=True)
sns.heatmap(correlation, mask=mask, cmap=cmap, vmax=1, vmin=-1, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5}, annot=True)

plt.show()

X_corr = initial_data[['smoothness_mean', 'radius_se', 'texture_se', 'smoothness_se', 'symmetry_se',
                       'fractal_dimension_se', 'texture_worst', 'symmetry_worst', 'fractal_dimension_worst']]
y_corr = initial_data['diagnosis']

# check correlation with Y

# Voting

models = [LogisticRegression(),
          DecisionTreeClassifier(),
          SVC(probability=True),
          LinearDiscriminantAnalysis(),
          QuadraticDiscriminantAnalysis(),
          RandomForestClassifier(),
          KNeighborsClassifier(),
          GaussianNB()]

scoring = ['accuracy', 'precision_macro', 'recall_macro', 'f1_weighted', 'roc_auc']

for model in models:
    scores = cross_validate(model, X_train, y_train, scoring=scoring, cv=20)
    # print(model, scores['fit_time'].mean(), scores['score_time'].mean(), scores['test_accuracy'].mean(),
    # scores['test_precision_macro'].mean(), scores['test_recall_macro'].mean(),
    # scores['test_f1_weighted'].mean(), scores['test_roc_auc'].mean())

models_ens = list(zip(['LR', 'DT', 'SVM', 'LDA', 'QDA', 'RF', 'KNN', 'NB'], models))

# hard
model_ens = VotingClassifier(estimators=models_ens, voting='hard')
model_ens.fit(X_train, y_train)
pred = model_ens.predict(X_test)
# prob = model_ens.predict_proba(X_test)[:,1]

acc_hard = accuracy_score(y_test, pred)
prec_hard = precision_score(y_test, pred)
recall_hard = recall_score(y_test, pred)
f1_hard = f1_score(y_test, pred)
roc_auc_hard = 'not applicable'

# soft
model_ens = VotingClassifier(estimators=models_ens, voting='soft')
model_ens.fit(X_train, y_train)
pred = model_ens.predict(X_test)
prob = model_ens.predict_proba(X_test)[:, 1]

acc_soft = accuracy_score(y_test, pred)
prec_soft = precision_score(y_test, pred)
recall_soft = recall_score(y_test, pred)
f1_soft = f1_score(y_test, pred)
roc_auc_soft = roc_auc_score(y_test, prob)

# voting comparison
models_ensembling = pd.DataFrame({
    'Model': ['Ensebling_hard', 'Ensembling_soft'],
    'Accuracy': [acc_hard, acc_soft],
    'Precision': [prec_hard, prec_soft],
    'Recall': [recall_hard, recall_soft],
    'F1_score': [f1_hard, f1_soft],
    'AUC_ROC': [roc_auc_hard, roc_auc_soft],
}, columns=['Model', 'Accuracy', 'Precision', 'Recall', 'F1_score', 'AUC_ROC'])

models_ensembling.sort_values(by='Accuracy', ascending=False)

# Feature Reduction

# 1
lsvc = LinearSVC(C=0.05, penalty="l1", dual=False).fit(X, y)
model = SelectFromModel(lsvc, prefit=True)
X_svc = model.transform(X)
X_svc.shape  # reduction from 30 to 10 features

# 2

lsvc = LinearSVC(C=0.05, penalty="l1", dual=False)
model = RFECV(estimator=lsvc, step=1, cv=20).fit(X, y)
X_rfecv = model.transform(X)
X_rfecv.shape  # reduction from 30

# Tree based feature selection
lsvc = LinearSVC(C=0.05, penalty="l1", dual=False).fit(X, y)
etc = ExtraTreesClassifier()
etc.fit(X, y)

model = SelectFromModel(etc, prefit=True)
X_etc = model.transform(X)
X_etc.shape

