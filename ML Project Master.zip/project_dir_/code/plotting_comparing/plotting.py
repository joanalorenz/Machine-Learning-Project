import numpy as np

def compare_scores(list_of_scores, list_of_names, metrics_name):
    import matplotlib.pyplot as plt

    global ax1
    font_size = 15
    title_size = 18
    ax1 = list_of_scores.plot.bar(legend=False, title='Models accuracy',
                                  figsize=(18, 5),
                                  color='sandybrown')
    ax1.title.set_size(fontsize=title_size)

    plt.xticks(np.arange(len(list_of_names)), list_of_names)
    plt.show()
