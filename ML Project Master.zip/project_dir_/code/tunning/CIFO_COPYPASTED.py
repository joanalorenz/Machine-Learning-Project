import numpy as np
import pandas as pd
from functools import reduce


### PROBLEM

class Problem:
    def __init__(self, search_space, fitness_function, minimization):
        self.search_space = search_space
        self.fitness_function = fitness_function
        self.minimization = minimization
        self.dimensionality = len(search_space)


    def evaluate(self, solution):
        pass


    def _validate(self, solution):
        pass


    def sample_search_space(self, random_state):
        pass

### SOLUTION


class Solution:
    _id = 0

    def __init__(self, representation):
        self._solution_id = Solution._id
        Solution._id += 1
        self.representation = representation

    def print_(self, inline=True, show_list=True):
        if show_list:
            if inline:
                print(*self.representation, sep=" | ")
            else:
                print(*self.representation, sep="\n")
        print("Solution ID: %d\nDimensionality: %d\nProfit: %.2f €\nIs admissible?\tR: %s" %
              (self._solution_id, self.dimensionality, self.fitness, self.valid))

### ALGORITHMS

class SearchAlgorithm:
    def __init__(self, problem_instance):
        self.problem_instance = problem_instance


    def initialize(self):
        pass


    def search(self, n_iterations, report=False):
        pass


    def _get_best(self, candidate_a, candidate_b):
        if self.problem_instance.minimization:
            if candidate_a.fitness > candidate_b.fitness:
                return candidate_b
            else:
                return candidate_a
        else:
            if candidate_a.fitness < candidate_b.fitness:
                return candidate_b
            else:
                return candidate_a


    def verbose_reporter(self):
        print("Best solution found:")
        self.best_solution.print_()


    def _verbose_reporter_inner(self, solution, iteration):
        print("> > > Current best solution at iteration %d:" % iteration)
        solution.print_()
        print()

class RandomSearch(SearchAlgorithm):
    def __init__(self, problem_instance, random_state):
        SearchAlgorithm.__init__(self, problem_instance)
        self._random_state = random_state

    def initialize(self):
        self.best_solution = self._generate_random_valid_solution()


    def search(self, n_iterations, report=False):

        i = self.best_solution
        for iteration in range(n_iterations):
            j = self._generate_random_valid_solution()
            i = self._get_best(i, j)

            if report:
                self._verbose_reporter_inner(i, iteration)

        self.best_solution = i

    def _generate_random_solution(self):
        return self.problem_instance.sample_search_space(self._random_state)

    def _generate_random_valid_solution(self):
        solution = self._generate_random_solution()
        self.problem_instance.evaluate(solution)


        while not solution.valid:
            solution = self._generate_random_solution()
            self.problem_instance.evaluate(solution)

        return solution


class HillClimbing(RandomSearch):
    def __init__(self, problem_instance, random_state,
                 neighborhood_size, neighborhood_function):
        RandomSearch.__init__(self, problem_instance, random_state)
        self.neighborhood_size = neighborhood_size
        self.neighborhood_function = neighborhood_function
        self.problem_instance = problem_instance
        # self.df = pd.DataFrame(columns=['test_accuracy','test_precision_macro','test_recall_macro','test_f1_weighted','test_roc_auc','profit'])
        self.df = pd.DataFrame(columns=['profit','params'])
    #
    def initialize(self):
        self.best_solution = self._generate_random_valid_solution()
        # print(self.problem_instance.params)
        # print(self.problem_instance.add_to_df(self.problem_instance.params))
        # self.df.loc[len(self.df)] = self.problem_instance.add_to_df(self.problem_instance.params)
        self.df.loc[len(self.df)] = self.best_solution.fitness,self.problem_instance.params

    def search(self, n_iterations, report=False):

        i = self.best_solution
        for iteration in range(n_iterations):
            print(iteration)
            j = self._explore_neighborhood(i)
            i = self._get_best(i, j)

            #self.problem_instance.add_to_df(self.problem_instance.params)

            if report:
                self._verbose_reporter_inner(i, iteration)

        self.best_solution = i
        # self.df.loc[len(self.df)] = self.problem_instance.add_to_df(self.problem_instance.params)
        self.df.loc[len(self.df)] = self.best_solution.fitness,self.problem_instance.params
        print('Dataframe: ',self.df)

    def _explore_neighborhood(self, solution):
        best_neighbor = self._choose_random_neighbor(solution)
        for neighbor in range(self.neighborhood_size - 1):
            candidate_neighbor = self._choose_random_neighbor(solution)
            best_neighbor = self._get_best(best_neighbor, candidate_neighbor)
        return best_neighbor

    def _choose_random_neighbor(self, solution):
        params, params_list = self.neighborhood_function(self.problem_instance.params, solution.representation, self.problem_instance.search_space,
                                   self._random_state)
        neighbor = Solution(params_list)
        #print('PARAMS', params)
        self.problem_instance.evaluate2(neighbor, params)
        return neighbor

    def _generate_random_solution(self):
        # print(self.problem_instance.params)
        return self.problem_instance.sample_search_space(self._random_state)

    def _generate_random_valid_solution(self):
        solution = self._generate_random_solution()
        self.problem_instance.evaluate(solution)

        while not solution.valid:
            solution = self._generate_random_solution()
            self.problem_instance.evaluate(solution)

        return solution

class GeneticAlgorithm(RandomSearch):
    def __init__(self, problem_instance, random_state, population_size,
                 selection, crossover, p_c, mutation, p_m, search_space):
        RandomSearch.__init__(self, problem_instance, random_state)
        self.population_size = population_size
        self.selection = selection
        self.crossover = crossover
        self.p_c = p_c
        self.mutation = mutation
        self.p_m = p_m
        self.search_space = search_space

    def initialize(self):
        self.population = self._generate_random_valid_chromosomes()
        self.best_solution = self._get_elite(self.population)

    def search(self, n_iterations, report=False, log=False, dplot=None):
        if log:
            log_event = [self.problem_instance.__class__, id(self._random_state), __name__]
            logger = logging.getLogger(','.join(list(map(str, log_event))))

        if dplot is not None:
            dplot.background_plot(self.problem_instance.search_space, self.problem_instance.fitness_function)

            def _iterative_plot():
                points = np.array([chromosome.representation for chromosome in self.population])
                points = np.insert(points, points.shape[0], values=self.best_solution.representation, axis=0)
                points = np.vstack((points[:, 0], points[:, 1]))
                z = np.array([chromosome.fitness for chromosome in self.population])
                z = np.insert(z, z.shape[0], values=self.best_solution.fitness)
                dplot.iterative_plot(points, z, self.best_solution.fitness)

        for iteration in range(n_iterations):
            offsprings = []

            while len(offsprings) < len(self.population):
                off1, off2 = p1, p2 = [
                    self.selection(self.population, self.problem_instance.minimization, self._random_state) for _ in range(2)]

                if self._random_state.uniform() < self.p_c:
                    off1, off2 = self._crossover(p1, p2)

                if self._random_state.uniform() < self.p_m:
                    off1 = self._mutation(off1)
                    off2 = self._mutation(off2)

                if not (hasattr(off1, 'fitness') and hasattr(off2, 'fitness')):
                    self.problem_instance.evaluate(off1)
                    self.problem_instance.evaluate(off2)
                offsprings.extend([off1, off2])

            while len(offsprings) > len(self.population):
                offsprings.pop()

            elite_offspring = self._get_elite(offsprings)
            self.best_solution = self._get_best(self.best_solution, elite_offspring)

            if report:
                self._verbose_reporter_inner(self.best_solution, iteration)

            if log:
                log_event = [iteration, self.best_solution.fitness, self.best_solution.validation_fitness if hasattr(off2, 'validation_fitness') else None,
                             self.population_size, self.selection.__name__, self.crossover.__name__, self.p_c,
                             self.mutation.__name__, None, None, self.p_m, self._phenotypic_diversity_shift(offsprings)]
                logger.info(','.join(list(map(str, log_event))))

            # replacement
            if self.best_solution == elite_offspring:
                self.population = offsprings
            else:
                self.population = offsprings
                index = self._random_state.randint(self.population_size)
                self.population[index] = self.best_solution

            if dplot is not None:
                _iterative_plot()

    def _crossover(self, p1, p2):
        off1, off2 = self.crossover(p1.representation, p2.representation, self._random_state)
        off1, off2 = Solution(off1), Solution(off2)
        return off1, off2

    def _mutation(self, chromosome):
        mutant = self.mutation(chromosome.representation, self._random_state, self.search_space)
        mutant = Solution(mutant)
        return mutant

    def _get_elite(self, population):
        elite = reduce(self._get_best, population)
        return elite

    def _generate_random_valid_chromosomes(self):
        chromosomes = np.array([self._generate_random_valid_solution()
                              for _ in range(self.population_size)])
        return chromosomes

