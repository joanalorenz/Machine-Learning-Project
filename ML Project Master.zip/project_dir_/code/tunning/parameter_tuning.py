import numpy as np

def tuning_forest_params():

    ### define parameters

    max_depth_space = np.arange(1,100,1)
    min_samples_split_space = np.arange(0.01, 1 ,0.01)
    n_estimators_space = np.arange(100,5000,50)
    min_weight_fraction_leaf_space = np.arange(0, 0.5, 0.01)
    # max_features_space =  np.arange(0.05, 1, 0.01)
    max_leaf_nodes_space =  np.arange(2,200,1)
    # min_impurity_decrease_space = np.arange(0.01, 0.3, 0.01)

    ### define_list
    search_space = [
        max_depth_space,
        min_samples_split_space,
        n_estimators_space,
        min_weight_fraction_leaf_space,
        # max_features_space,
        max_leaf_nodes_space,
        # min_impurity_decrease_space
    ]

    param_list_names = [
        'max_depth',
        'min_samples_split',
        'n_estimators',
        'min_weight_fraction_leaf',
        # 'max_features',
        'max_leaf_nodes',
        # 'min_impurity_decrease',
    ]

    dict_param = {
        'max_depth': max_depth_space,
        'min_samples_split': min_samples_split_space,
        'n_estimators': n_estimators_space,
        'min_weight_fraction_leaf': min_weight_fraction_leaf_space,
        # 'max_features': max_features_space,
        'max_leaf_nodes': max_leaf_nodes_space,
        # 'min_impurity_decrease': min_impurity_decrease_space,
    }

    return search_space, dict_param, param_list_names
