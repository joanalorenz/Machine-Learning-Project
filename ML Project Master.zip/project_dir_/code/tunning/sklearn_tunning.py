################ Sklearn Parameter Optimization ############################################################
from utils import profitFitness
from sklearn.metrics import confusion_matrix
from utils import roi_gridcv
def grid_tuner(model_instance, param_dict, cv, X_train, y_train,X_test,y_test):
    from utils import ROI
    from sklearn.model_selection import GridSearchCV
    from sklearn.metrics import f1_score
    from sklearn.metrics import make_scorer
    # prepare a range of alpha values to test
    # param_grid = {'max_depth': [1,5,10, 20],
    #               'min_samples_split': [2, 25,50,101],
    #               'min_samples_leaf': [1, 25,51,110]
    #               }
    from utils import roi_gridcv, profit_share
    grid = GridSearchCV(estimator=model_instance, param_grid=param_dict, cv=cv, scoring=make_scorer(profit_share), n_jobs=-1)
    grid.fit(X_train, y_train)
    print('Model: ',model_instance)
    print('Best parameters: ',grid.best_params_)
    grid.best_estimator_.fit(X_train, y_train)  # using the train data to train the rfc
    X_test = X_test.to_numeric()

    y_pred = grid.best_estimator_.predict(X_test)
    print('Final F1 score: ',grid.best_score_)
    print('Final test profit: ', profitFitness(y_test, y_pred))
    print('-------------------------------------')

    # print(f)
    return grid.best_estimator_, grid.best_params_, grid.best_score_, profitFitness(y_test, y_pred)
    # print(grid.best_estimator_)


#print('##################################################################################')
#
# def grid_tunner(model_instance, param_dict, X_train, y_train):
#     from sklearn.model_selection import RandomizedSearchCV
#     from scipy.stats import randint as sp_randint
#     param_grid = {'max_depth': sp_randint(1, 50),
#                     'min_samples_split': sp_randint(2, 100),
#                   'min_samples_leaf': sp_randint(1, 110)
#                   }
#     # create and fit a ridge regression model, testing random alpha values
#     model = DecisionTreeClassifier()
#     rsearch = RandomizedSearchCV(estimator=model_instance, param_distributions=param_grid, n_iter=300, n_jobs = -1)
#     rsearch.fit(X_train, y_train)
#     print(rsearch)
#     # summarize the results of the random parameter search
#     print(rsearch.best_score_)
#     print(rsearch.best_estimator_)
#
#
# ##################################
# def grid_tunner(model_instance, param_dict, X_train, y_train):
#     from sklearn.model_selection import GridSearchCV
#     # prepare a range of alpha values to test
#     # param_grid = {'max_depth': [1,5,10, 20],
#     #               'min_samples_split': [2, 25,50,101],
#     #               'min_samples_leaf': [1, 25,51,110]
#     #               }
#
#     # create and fit a ridge regression model, testing each alpha
#     grid = GridSearchCV(estimator=model_instance, param_grid=param_dict)
#     grid.fit(X_train, y_train)
#     print(grid.best_score_)
#     print(grid.best_estimator_)


def profit_share(y_test, y_pred):
    cm = confusion_matrix(y_test, y_pred)
    tn, fp, fn, tp = cm.ravel()
    profit_s = (tn * 0 + fp * (-3) + fn * 0 + tp * 8)/((y_test == 1).sum()*8)
    # print(profit_s)
    return profit_s