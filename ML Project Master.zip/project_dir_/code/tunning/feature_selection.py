# ## univariat selection
# from single_model import *
#
#
#
# class Feature_Selector():
#
#     def __init__(self, X_train, X_test, y_train, seed):
#         self.X_train = X_train
#         self.X_test = X_test
#         self.y_train = y_train
#         self.seed=seed
#         self.do_RFE_selection()
#
#     def do_generic_selection(self, X_train, y_train, X_test):
#         from sklearn.feature_selection import GenericUnivariateSelect, chi2
#
#         transformer =  GenericUnivariateSelect(chi2, 'percentile', param=0.7)
#         X_train_new = transformer.fit_transform(X_train, y_train)
#         X_test_new = transformer.transform(X_test)
#         return X_train_new, X_test_new
#
#     def get_AVG_feature_importance(self, X_train, y_train, X_test, y_test, print_res = False):
#         a = np.array(randomForest(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
#         b = np.array(adaBoost(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
#         c = np.array(gradBoost(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
#         d = np.array(extraTrees(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
#         names = list(X_train.columns.values)
#         avg_importance = np.average(np.vstack((a, b, c, d)), axis=0).T
#         feature_importance_df = pd.DataFrame(avg_importance, index=names, columns=['Importance'])
#         avg_importance_sorted = feature_importance_df.sort_values(['Importance'], ascending = False)
#         if print_res:
#             print(avg_importance_sorted)
#             return
#         return avg_importance_sorted
#
#     def do_RFE_selection(self):
#         from sklearn.ensemble import RandomForestClassifier
#         from sklearn.feature_selection import RFE
#
#         classifier = RandomForestClassifier(
#             n_estimators=500,
#             random_state=self.seed,
#             criterion="entropy",
#             max_depth=20,
#             min_samples_split=2
#         )
#
#         selector = RFE(classifier, 34, step=1)
#         selector = selector.fit(self.X_train, self.y_train)
#         features = selector.support_
#
#         self.X_train = self.X_train.copy().T[features].T
#         self.X_test = self.X_test.copy().T[features].T
#
#
#
# def get_AVG_feature_importance(X_train, y_train, X_test, y_test, print_res = False):
#     a = np.array(randomForest(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
#     b = np.array(adaBoost(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
#     c = np.array(gradBoost(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
#     d = np.array(extraTrees(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
#     names = list(X_train.columns.values)
#     print(a.shape,b.shape,c.shape,d.shape)
#     avg_importance = np.average(np.vstack((a, b, c, d)), axis=0).T
#     feature_importance_df = pd.DataFrame(avg_importance, index=names, columns=['Importance'])
#     avg_importance_sorted = feature_importance_df.sort_values(['Importance'], ascending = False)
#     if print_res:
#         print(avg_importance_sorted)
#         return
#     return avg_importance_sorted
#
#
#
# def do_RFE_selection(estimator, X, y, select_features):
#     from sklearn.feature_selection import RFE
#     selector = RFE(estimator, select_features, step=1)
#     selector = selector.fit(X, y)
#
#     return selector.support_
# # # Recursive Feature Elimination
# # from sklearn import datasets
# # from sklearn.feature_selection import RFE
# # from sklearn.linear_model import LogisticRegression
# #
# # # load the iris datasets
# # dataset = datasets.load_iris()
# # # create a base classifier used to evaluate a subset of attributes
# # model = LogisticRegression()
# # # create the RFE model and select 3 attributes
# # rfe = RFE(model, 3)
# # rfe = rfe.fit(dataset.data, dataset.target)
# # # summarize the selection of the attributes
# # print(rfe.support_)
# # print(rfe.ranking_)
# #
# #
# # # Feature Importance
# # from sklearn import datasets
# # from sklearn import metrics
# # from sklearn.ensemble import ExtraTreesClassifier
# #
# # # load the iris datasets
# # dataset = datasets.load_iris()
# # # fit an Extra Trees model to the data
# # model = ExtraTreesClassifier()
# # model.fit(dataset.data, dataset.target)
# # # display the relative importance of each attribute
# # print(model.feature_importances_)
#
#
#
# '''         ####  NOTE OF HOW FEATURE IMPORTNACE IS BEING CALCULATED - sklearn  ####
#
# In scikit-learn, we implement the importance as described in [1] (often cited, but unfortunately rarely read...).
# It is sometimes called "gini importance" or "mean decrease impurity" and is defined as the total decrease in node
# impurity (weighted by the probability of reaching that node (which is approximated by the proportion of samples reaching
# that node)) averaged over all trees of the ensemble.
#
# In the literature or in some other packages, you can also find feature importances implemented as the "mean decrease accuracy".
# Basically, the idea is to measure the decrease in accuracy on OOB data when you randomly permute the values for that feature.
# If the decrease is low, then the feature is not important, and vice-versa.
# '''


#FROM LUKAS::::::::::::::::::::


## univariat selection
from single_model import *



class Feature_Selector():

    def __init__(self, X_train, X_test, y_train, seed, X_train_validate, y_train_validate):
        self.X_train = X_train
        self.X_test = X_test
        self.y_train = y_train
        self.X_train_validate = X_train_validate
        self.y_train_validate = y_train_validate
        self.seed=seed


    def do_generic_selection(self, X_train, y_train, X_test):
        from sklearn.feature_selection import GenericUnivariateSelect, chi2

        transformer =  GenericUnivariateSelect(chi2, 'percentile', param=0.7)
        X_train_new = transformer.fit_transform(X_train, y_train)
        X_test_new = transformer.transform(X_test)
        return X_train_new, X_test_new

    def get_AVG_feature_importance(self, X_train, y_train, X_test, y_test, print_res = False):
        a = np.array(randomForest(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
        b = np.array(adaBoost(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
        c = np.array(gradBoost(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
        d = np.array(extraTrees(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
        names = list(X_train.columns.values)
        avg_importance = np.average(np.vstack((a, b, c, d)), axis=0).T
        feature_importance_df = pd.DataFrame(avg_importance, index=names, columns=['Importance'])
        avg_importance_sorted = feature_importance_df.sort_values(['Importance'], ascending = False)
        if print_res:
            print(avg_importance_sorted)
            return
        return avg_importance_sorted

    def select_features(self):

        self.X_test= self.X_test[['Dt_Customer',
                             'Income',
                             #'Kmode',
                             'LD1',
                             'MntMeatProducts',
                             #'PC1',
                             'PC2',
                             'PC3',
                             'PC6',
                             'Recency',
                             #'Web_conversion',
                             #'avg_no_cat_per_month',
                             'avg_no_store_per_month',
                             'ever_accep',
                             'mnt_total',
                             'response_rate',
                             'total_response ']]

        self.X_train=self.X_train[['Dt_Customer',
                                     'Income',
                                     #'Kmode',
                                     'LD1',
                                     'MntMeatProducts',
                                     #'PC1',
                                     'PC2',
                                     'PC3',
                                     'PC6',
                                     'Recency',
                                     #'Web_conversion',
                                     #'avg_no_cat_per_month',
                                     'avg_no_store_per_month',
                                     'ever_accep',
                                     'mnt_total',
                                     'response_rate',
                                     'total_response ']]

        self.X_train_validate=self.X_train_validate[['Dt_Customer',
                                                     'Income',
                                                     #'Kmode',
                                                     'LD1',
                                                     'MntMeatProducts',
                                                     #'PC1',
                                                     'PC2',
                                                     'PC3',
                                                     'PC6',
                                                     'Recency',
                                                     #'Web_conversion',
                                                     #'avg_no_cat_per_month',
                                                     'avg_no_store_per_month',
                                                     'ever_accep',
                                                     'mnt_total',
                                                     'response_rate',
                                                     'total_response ']]





    def do_RFE_selection(self):
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.feature_selection import RFE

        classifier = RandomForestClassifier(
            n_estimators=500,
            random_state=self.seed,
            criterion="entropy",
            max_depth=20,
            min_samples_split=2
        )

        selector = RFE(classifier, 13, step=1)
        selector = selector.fit(self.X_train, self.y_train)
        features = selector.support_

        self.X_train = self.X_train.copy().T[features].T
        self.X_test = self.X_test.copy().T[features].T



def get_AVG_feature_importance(X_train, y_train, X_test, y_test, print_res = False):
    a = np.array(randomForest(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
    b = np.array(adaBoost(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
    c = np.array(gradBoost(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
    d = np.array(extraTrees(X_train, y_train, X_test, y_test, seed=0, print_score=False, validate=False, feature_importance=True))
    names = list(X_train.columns.values)
    print(a.shape,b.shape,c.shape,d.shape)
    avg_importance = np.average(np.vstack((a, b, c, d)), axis=0).T
    feature_importance_df = pd.DataFrame(avg_importance, index=names, columns=['Importance'])
    avg_importance_sorted = feature_importance_df.sort_values(['Importance'], ascending = False)
    if print_res:
        print(avg_importance_sorted)
        return
    return avg_importance_sorted



def do_RFE_selection(estimator, X, y, select_features):
    from sklearn.feature_selection import RFE
    selector = RFE(estimator, select_features, step=1)
    selector = selector.fit(X, y)

    return selector.support_
# # Recursive Feature Elimination
# from sklearn import datasets
# from sklearn.feature_selection import RFE
# from sklearn.linear_model import LogisticRegression
#
# # load the iris datasets
# dataset = datasets.load_iris()
# # create a base classifier used to evaluate a subset of attributes
# model = LogisticRegression()
# # create the RFE model and select 3 attributes
# rfe = RFE(model, 3)
# rfe = rfe.fit(dataset.data, dataset.target)
# # summarize the selection of the attributes
# print(rfe.support_)
# print(rfe.ranking_)
#
#
# # Feature Importance
# from sklearn import datasets
# from sklearn import metrics
# from sklearn.ensemble import ExtraTreesClassifier
#
# # load the iris datasets
# dataset = datasets.load_iris()
# # fit an Extra Trees model to the data
# model = ExtraTreesClassifier()
# model.fit(dataset.data, dataset.target)
# # display the relative importance of each attribute
# print(model.feature_importances_)



'''         ####  NOTE OF HOW FEATURE IMPORTNACE IS BEING CALCULATED - sklearn  ####

In scikit-learn, we implement the importance as described in [1] (often cited, but unfortunately rarely read...). 
It is sometimes called "gini importance" or "mean decrease impurity" and is defined as the total decrease in node 
impurity (weighted by the probability of reaching that node (which is approximated by the proportion of samples reaching 
that node)) averaged over all trees of the ensemble.

In the literature or in some other packages, you can also find feature importances implemented as the "mean decrease accuracy". 
Basically, the idea is to measure the decrease in accuracy on OOB data when you randomly permute the values for that feature. 
If the decrease is low, then the feature is not important, and vice-versa. 
'''