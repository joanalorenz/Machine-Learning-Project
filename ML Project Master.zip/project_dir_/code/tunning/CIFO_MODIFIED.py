import numpy as np
from functools import reduce
from CIFO_COPYPASTED import *
from sklearn.metrics import confusion_matrix
import random
from utils import do_validation,do_validation2
import pandas as pd

### Problem instance for single model tuning

class ModelTuner(Problem): # should be suitable for each tree based algorithm only difference will be different set of parameters ergo search space!!
    def __init__(self, search_space, list_of_param_names, fitness_function, model, X_train, y_train, X_test, y_test, minimization = False, params=None, seed = 0):
        Problem.__init__(self, search_space, fitness_function, minimization)
        # self.df = pd.DataFrame(columns =['test_accuracy','test_precision_macro','test_recall_macro','test_f1_weighted','test_roc_auc'])
        self.df = self.df = pd.DataFrame(columns=['profit'])
        self.search_space = search_space
        self.X_train = X_train
        self.y_train = y_train
        self.y_test = y_test
        self.X_test = X_test
        self.seed = seed
        params['random_state'] = seed
        self.params = params
        self.list_of_param_names = list_of_param_names
        self.model_instance = model
        self.model = model(**params)

    def train(self, params):
        self.params = params
        self.model = self.model_instance(**self.params)
        self.model.fit(self.X_train, self.y_train)

    def add_to_df(self, params):
        self.train(params)
        self.prediction = self.model.predict(self.X_test)
        return do_validation(self.model, self.X_train, self.y_train)
        #self.df.loc[len(self.df)] = do_validation(self.model, self.X_train, self.y_train)
        #self.df.loc

    def evaluate(self, solution):
        self.train(self.params)
        self.prediction = self.model.predict(self.X_test)
        # do_validation(self.model, self.X_train, self.y_train)


        # self.df.loc[len(self.df)] = do_validation(self.model, self.X_train, self.y_train)

        solution.dimensionality, solution.valid = self._validate(solution.representation)
        if solution.valid:
            solution.fitness = self.fitness_function(self.y_test, self.prediction)
        else:
            if self.minimization:
                solution.fitness = np.iinfo(np.int32).max
            else:
                solution.fitness = 0



    def evaluate2(self, solution, params):
        self.train(params)
        self.prediction = self.model.predict(self.X_test)
        # do_validation(self.model, self.X_train, self.y_train)
        # self.df.loc[len(self.df)] = do_validation(self.model, self.X_train, self.y_train)

        solution.dimensionality, solution.valid = self._validate(solution.representation)
        if solution.valid:
            solution.fitness = self.fitness_function(self.y_test, self.prediction)
        else:
            if self.minimization:
                solution.fitness = np.iinfo(np.int32).max
            else:
                solution.fitness = 0



    def _validate(self, items):
        dimensionality = len(items)

        # Tutaj dodaj czesc sprawdzanai czy parametry to np integery czy stringi to stringi i tak dalej to jest
        # #specificzne dla kazdego instance problem wiec nie powinno byc problemm z indntyfikowaniem
        # ktore parametry powinny byc validowane

        return dimensionality, True


    def sample_search_space(self, random_state):
        self.params, params_list = generate_solution(self.search_space, self.list_of_param_names) # tez i zmiany
        return Solution(params_list)


### CIFO utils


def get_random_state(seed):
    return np.random.RandomState(seed)

def getNieghbor(dict_param, param_list, search_space, random_state):
    # print(dict_param)
    nr=0
    for i in dict_param:
        rand = random.random()
        if rand > 0.5:
            new_param = random.choice(search_space[nr])
            dict_param[i] = new_param
            param_list[nr] = new_param
        nr+=1
    return dict_param, param_list

# def create_searchSpace():
#     max_depth_space = np.arange(1,100,1)
#     min_samples_split_space = np.arange(2,200,5)
#     min_samples_leaf_space = np.arange(1, 100, 1)
#     # min_weight_fraction_leaf_space = np.arange(0, 0.5, 0.01)
#     # max_features =  np.arange(0.05, 1, 0.01)
#     # max_leaf_nodes =  np.arange(2,200,1)
#     # min_impurity_decrease = np.arange(0.01, 0.3, 0.01)
#     search_space = [max_depth_space, min_samples_split_space, min_samples_leaf_space
#         # , min_weight_fraction_leaf_space,
#         #                            max_features, max_leaf_nodes, min_impurity_decrease
#     ]
#     return search_space
#
# def create_searchSpace_rf():
#     max_depth_space = np.arange(1,100,1)
#     min_samples_split_space = np.arange(0.01, 1 ,0.01)
#     n_estimators_space = np.arange(100,5000,50)
#     # min_weight_fraction_leaf_space = np.arange(0, 0.5, 0.01)
#     # max_features =  np.arange(0.05, 1, 0.01)
#     # max_leaf_nodes =  np.arange(2,200,1)
#     # min_impurity_decrease = np.arange(0.01, 0.3, 0.01)
#     search_space = [max_depth_space, min_samples_split_space, n_estimators_space
#         # , min_weight_fraction_leaf_space,
#         #                            max_features, max_leaf_nodes, min_impurity_decrease
#     ]
#     return search_space


## Fitness function:
def logLossFitness(y_test, y_pred):
    score = log_loss( y_test, y_pred)
    return score

def accFitness(y_test, y_pred):
    score = accuracy_score( y_test, y_pred)
    return score

def profitFitness(y_test, y_pred):
    cm = confusion_matrix(y_test, y_pred)
    score = cm[0][0] * 0 + cm[1][1] * 8 + cm[1][0] * (0) + cm[0][1] * (-11)
    return score

# It return list of parameters - random valid solution

def generate_solution(search_space, list_of_param_names): # iteruj przez wiersze search spejsu i stworz dictionaryi liste !
    import random
    params = {}
    param_list = []
    for i in range(len(search_space)):
        new_param = random.choice(search_space[i])
        params.update({list_of_param_names[i]: new_param})
        param_list.append(new_param)
    return params, param_list


def one_point_crossover(p1_r, p2_r, random_state):
    len_ = len(p1_r)
    point = random_state.randint(len_)
    off1_r = np.concatenate((p1_r[0:point], p2_r[point:len_]))
    off2_r = np.concatenate((p2_r[0:point], p1_r[point:len_]))
    return off1_r, off2_r

def random_point_mutation(point, random_state, search_space):
    import random
    positions = random.sample(range(0, len(point)),1)
    for p in positions:
        new_param = random.choice(search_space[p])
        point[p] = new_param
    return point

from functools import reduce

def tournament_selection(population, minimization, random_state):
    tournament_pool_size = int(len(population) * 0.3)
    tournament_pool = random_state.choice(population, size=tournament_pool_size, replace=False)

    if minimization:
        return reduce(lambda x, y: x if x.fitness <= y.fitness else y, tournament_pool)
    else:
        return reduce(lambda x, y: x if x.fitness >= y.fitness else y, tournament_pool)

