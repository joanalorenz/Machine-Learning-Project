#
# from utils import *
# from CIFO_COPYPASTED import *
#
# class Problem:
#     def __init__(self, search_space, fitness_function, minimization):
#         self.search_space = search_space
#         self.fitness_function = fitness_function
#         self.minimization = minimization
#         self.dimensionality = len(search_space)
#
#
#     def evaluate(self, solution):
#         pass
#
#
#     def _validate(self, solution):
#         pass
#
#
#     def sample_search_space(self, random_state):
#         pass
#
#
# class Model():
#     def __init__(self, model, X_train, y_train, seed=0, params=None, verbose = False):
#
#         self.X_train = X_train
#         self.y_train = y_train
#
#         self.seed = seed
#
#         params['random_state'] = seed
#         self.params = params # dictionary with parameters for given model
#         self.verbose = verbose
#
#         self.model = model(**params)
#
#     def train(self):
#         print(np.sum(self.X_train.isnull(),axis=0))
#         self.model.fit(self.X_train, self.y_train)
#
#     def predict(self, x):
#         return self.model.predict(x)
#
#     def fit(self, x, y):
#         return self.model.fit(x, y)
#
#     def feature_importances(self, x, y):
#         print(self.model.fit(x, y).feature_importances_)
#
# # Problem instance
#
# # search speace to kazd mozliwa kombinacja parametró
# # for tree with 3 parameters :
#
# ## Search space
#
#
#
#
# class ModelTuner(Problem): # should be suitable for each tree based algorithm only difference will be different set of parameters ergo search space!!
#     def __init__(self, search_space, fitness_function, model, X_train, y_train, X_test, y_test, minimization = False, params=None, seed = 0):
#         Problem.__init__(self, search_space, fitness_function, minimization)
#         self.search_space = search_space
#         self.X_train = X_train
#         self.y_train = y_train
#         self.y_test = y_test
#         self.X_test = X_test
#         self.seed = seed
#         params['random_state'] = seed
#         self.params = params
#         self.model_instance = model
#         self.model = model(**params)
#
#     def train(self, params):
#         self.params = params
#         self.model = self.model_instance(**self.params)
#         self.model.fit(self.X_train, self.y_train)
#
#     # def evaluate2(self, solution):
#     #     # print(solution.representation)
#     #     # moze podac tutaj ideksy do
#     #     items = self.search_space[solution.representation]
#     #     solution.dimensionality, solution.valid = self._validate(items)
#     #
#     #     if solution.valid:
#     #         solution.fitness = self.fitness_function(items)
#     #     else:
#     #         if self.minimization:
#     #             solution.fitness = np.iinfo(np.int32).max
#     #         else:
#     #             solution.fitness = 0
#
#     def evaluate(self, solution):
#         self.train(self.params)
#         self.prediction = self.model.predict(self.X_test)
#
#         solution.dimensionality, solution.valid = self._validate(solution.representation)
#         if solution.valid:
#             solution.fitness = self.fitness_function(self.y_test, self.prediction)
#         else:
#             if self.minimization:
#                 solution.fitness = np.iinfo(np.int32).max
#             else:
#                 solution.fitness = 0
#
#     def evaluate2(self, solution, params):
#         self.train(params)
#         self.prediction = self.model.predict(self.X_test)
#
#         solution.dimensionality, solution.valid = self._validate(solution.representation)
#         if solution.valid:
#             solution.fitness = self.fitness_function(self.y_test, self.prediction)
#         else:
#             if self.minimization:
#                 solution.fitness = np.iinfo(np.int32).max
#             else:
#                 solution.fitness = 0
#
#
#     def _validate(self, items):
#         dimensionality = len(items)
#
#         # Tutaj dodaj czesc sprawdzanai czy parametry to np integery czy stringi to stringi i tak dalej to jest
#         # #specificzne dla kazdego instance problem wiec nie powinno byc problemm z indntyfikowaniem
#         # ktore parametry powinny byc validowane
#
#         return dimensionality, True
#
#
#     def sample_search_space(self, random_state):
#         self.params, params_list = generate_solution_rf()
#         # print(self.params)
#         return Solution(params_list)
#
